/*************************************************************************/ /*!
@File           rcargx_version.h
@Title          Renesas graphics package version information
@Copyright      (C) 2016-2024 Renesas Electronics Corporation. All rights reserved.
@License        Strictly Confidential.
*/ /**************************************************************************/

#ifndef _RCARGX_VERSION_H_
#define _RCARGX_VERSION_H_

#define RCARGX_VERSION_MAJOR		4
#define RCARGX_VERSION_MINOR		3
#define RCARGX_VERSION_RELEASE		1

#define RCARGX_COPYRIGHT_TXT			"Copyright (c) 2016-2024 Renesas Electronics Corporation. All rights reserved."

#define RCARGX_VERSION(a,b,c)			(((a) << 16) + ((b) << 8) + (c))
#define RCARGX_VERSION_CODE			(RCARGX_VERSION(RCARGX_VERSION_MAJOR, RCARGX_VERSION_MINOR, RCARGX_VERSION_RELEASE))

#define RCARGX_STRING(v)			#v
#define RCARGX_VERSION_STRING(a,b,c)		"renesas package version " RCARGX_STRING(a) "." RCARGX_STRING(b) "." RCARGX_STRING(c)
#define RCARGX_VERSION_CODE_STRING		(RCARGX_VERSION_STRING(RCARGX_VERSION_MAJOR, RCARGX_VERSION_MINOR, RCARGX_VERSION_RELEASE))

#define RCARGX_VERSION_UNPACK_MAJOR(v)		(((v) >> 16) & 0xFF)
#define RCARGX_VERSION_UNPACK_MINOR(v)		(((v) >> 8) & 0xFF)
#define RCARGX_VERSION_UNPACK_RELEASE(v)	(((v) >> 0) & 0xFF)

#endif /* _RCARGX_VERSION_H_ */
