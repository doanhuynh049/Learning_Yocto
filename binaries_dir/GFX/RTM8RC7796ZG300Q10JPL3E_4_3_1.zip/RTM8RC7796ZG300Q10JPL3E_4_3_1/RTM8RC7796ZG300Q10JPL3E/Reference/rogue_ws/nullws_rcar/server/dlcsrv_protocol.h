/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server/Client protocols
 *
 *	Server side
 */

#ifndef __DLCSRV_PROTOCOLS_H
#define __DLCSRV_PROTOCOLS_H

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm/drm.h>

#include "dlc_status.h"

#define SOCKET_PATH	"/run/DLCSRV.sock"
#define DLCSVR_NAME	"dlcsrv_REL"

#define DLCSRV_MAX_BUFFERS	4

#define DLC_VER_MAJOR	0x52454c01
#define DLC_VER_MINOR	0x00000007

typedef enum DLC_COMMANDS_TAG
{
	DLC_CMD_NOP			= 0,

	/* connector commands */
	DLC_CMD_GET_DPMS_MODE,
	DLC_CMD_SET_DPMS_MODE,

	/* buffer memory commands */
	DLC_CMD_ALLOC_BUFFER,
	DLC_CMD_FREE_BUFFER,

	/* crtc commands */
	DLC_CMD_ACQUIRE_DESKTOP,
	DLC_CMD_RELEASE_DESKTOP,
	DLC_CMD_GET_MODE,
	DLC_CMD_SET_MODE,
	DLC_CMD_PAGE_FLIP,

	/* plane commands */
	DLC_CMD_ACQUIRE_PLANE,
	DLC_CMD_RELEASE_PLANE,
	DLC_CMD_GET_PLANE_PROPERTY,
	DLC_CMD_SET_PLANE_PROPERTY,
	DLC_CMD_GET_PLANE_INFO,
	DLC_CMD_SET_PLANE,

	/* pvr dc module commands */
	DLC_CMD_ACQUIRE_DEVICE_DC,
	DLC_CMD_RELEASE_DEVICE_DC,
	DLC_CMD_SET_PLANE_DC,
	DLC_CMD_PAGE_FLIP_DC,

	/* DRM-Master commands */
	DLC_CMD_DRM_SET_MASTER,
	DLC_CMD_DRM_DROP_MASTER,
	DLC_CMD_DRM_AUTH_MAGIC,

	/* close socket */
	DLC_CMD_DISCONNECT,

	/* shutdown server */
	DLC_CMD_TERMINATE		= 0xFFFFFFFF,

} DLC_COMMANDS;

/********************************************************************************/

typedef struct DLC_CMD_HEADER_TAG
{
	DLC_COMMANDS	cmd;
	unsigned int	len;

	unsigned int	major_v;
	unsigned int	minor_v;

	pid_t		pid;

} DLC_CMD_HEADER;

typedef struct DLC_RESP_HEADER_TAG
{
	DLC_COMMANDS	cmd;
	DLC_STATUS	status;

} DLC_RESP_HEADER;

/********************************************************************************/

/*
	DLC_CMD_GET_DPMS_MODE
	DLC_CMD_SET_DPMS_MODE
 */
typedef struct DLC_MSG_GET_DPMS_MODE_TAG
{
	DLC_CMD_HEADER	hdr;

	int		connector_index;

} DLC_MSG_GET_DPMS_MODE;

typedef struct DLC_MSG_SET_DPMS_MODE_TAG
{
	DLC_CMD_HEADER	hdr;

	int		connector_index;
	unsigned int	dpms_mode;

} DLC_MSG_SET_DPMS_MODE;

typedef struct DLC_RESP_DPMS_MODE_TAG
{
	DLC_RESP_HEADER	hdr;

	unsigned int	dpms_mode;

} DLC_RESP_DPMS_MODE;

/********************************************************************************/

/*
	DLC_CMD_ALLOC_BUFFER
	DLC_CMD_FREE_BUFFER
*/
typedef struct DLC_MSG_ALLOC_BUFFER_TAG
{
	DLC_CMD_HEADER	hdr;

	unsigned int	flink_name;

	unsigned int	width;
	unsigned int	height;
	unsigned int	format;
	unsigned int	pitch;

} DLC_MSG_ALLOC_BUFFER;

typedef struct DLC_RESP_ALLOC_BUFFER_TAG
{
	DLC_RESP_HEADER	hdr;

	unsigned int	gem_handle;
	unsigned int	fb_id;

} DLC_RESP_ALLOC_BUFFER;

typedef struct DLC_MSG_FREE_BUFFER_TAG
{
	DLC_CMD_HEADER	hdr;

	unsigned int	gem_handle;
	unsigned int	fb_id;

} DLC_MSG_FREE_BUFFER;

typedef struct DLC_RESP_FREE_BUFFER_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_FREE_BUFFER;

/********************************************************************************/

/*
	DLC_CMD_ACQUIRE_DESKTOP
 */
typedef struct DLC_MSG_ACQUIRE_DESKTOP_TAG
{
	DLC_CMD_HEADER	hdr;

	int		crtc_index;
	int		buffers;

} DLC_MSG_ACQUIRE_DESKTOP;

typedef struct DLC_RESP_ACQUIRE_DESKTOP_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_ACQUIRE_DESKTOP;

/*
	DLC_CMD_RELEASE_DESKTOP
 */
typedef struct DLC_MSG_RELEASE_DESKTOP_TAG
{
	DLC_CMD_HEADER	hdr;

	int		crtc_index;

} DLC_MSG_RELEASE_DESKTOP;

typedef struct DLC_RESP_RELEASE_DESKTOP_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_RELEASE_DESKTOP;

/*
	DLC_CMD_GET_MODE
	DLC_CMD_SET_MODE
*/
typedef struct DLC_MSG_GET_CRTC_MODE_TAG
{
	DLC_CMD_HEADER	hdr;

	int	crtc_index;

} DLC_MSG_GET_CRTC_MODE;

typedef struct DLC_MSG_SET_CRTC_MODE_TAG
{
	DLC_CMD_HEADER	hdr;

	int	crtc_index;
	int	connector_index;

	unsigned int	fb_id;

	unsigned int	hdisplay;
	unsigned int	vdisplay;

	unsigned int	src_x, src_y;

} DLC_MSG_SET_CRTC_MODE;

typedef struct DLC_RESP_CRTC_MODE_TAG
{
	DLC_RESP_HEADER	hdr;

	unsigned int	hdisplay;
	unsigned int	vdisplay;

} DLC_RESP_CRTC_MODE;

/*
	DLC_CMD_PAGE_FLIP
	DLC_CMD_PAGE_FLIP_DC
*/
typedef struct DLC_MSG_PAGE_FLIP_TAG
{
	DLC_CMD_HEADER	hdr;

	int	crtc_index;

	unsigned int	fb_id;
	unsigned int	dc_devid;

	unsigned int	interval;

} DLC_MSG_PAGE_FLIP;

typedef struct DLC_RESP_PAGE_FLIP_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_PAGE_FLIP;

/********************************************************************************/

/*
	DLC_CMD_ACQUIRE_PLANE
 */
typedef struct DLC_MSG_ACQUIRE_PLANE_TAG
{
	DLC_CMD_HEADER	hdr;

	int		crtc_index;
	int		buffers;

} DLC_MSG_ACQUIRE_PLANE;

typedef struct DLC_RESP_ACQUIRE_PLANE_TAG
{
	DLC_RESP_HEADER	hdr;

	int		plane_index;
	unsigned int	plane_id;

} DLC_RESP_ACQUIRE_PLANE;

/*
	DLC_CMD_RELEASE_PLANE
 */
typedef struct DLC_MSG_RELEASE_PLANE_TAG
{
	DLC_CMD_HEADER	hdr;

	int		plane_index;

} DLC_MSG_RELEASE_PLANE;

typedef struct DLC_RESP_RELEASE_PLANE_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_RELEASE_PLANE;

/*
	DLC_CMD_REGISTER_FLIP_CHAIN
 */
typedef struct DLC_MSG_REGISTER_FLIP_CHAIN_TAG
{
	DLC_CMD_HEADER	hdr;

	int		plane_index;
	int		buffers;
	unsigned int	fb_ids[DLCSRV_MAX_BUFFERS];

} DLC_MSG_REGISTER_FLIP_CHAIN;

typedef struct DLC_RESP_REGISTER_FLIP_CHAIN_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_REGISTER_FLIP_CHAIN;

/*
	DLC_CMD_DELETE_FLIP_CHAIN
 */
typedef struct DLC_MSG_DELETE_FLIP_CHAIN_TAG
{
	DLC_CMD_HEADER	hdr;

	int		plane_index;

} DLC_MSG_DELETE_FLIP_CHAIN;

typedef struct DLC_RESP_DELETE_FLIP_CHAIN_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_DELETE_FLIP_CHAIN;

/*
	DLC_CMD_GET_PLANE_PROPERTY
	DLC_CMD_SET_PLANE_PROPERTY
 */
typedef struct DLC_MSG_PLANE_PROPERTY_TAG
{
	DLC_CMD_HEADER	hdr;

#define DLC_PLANE_PROPERTY_ALPHA	1
#define DLC_PLANE_PROPERTY_COLORKEY	2
#define DLC_PLANE_PROPERTY_PRIORITY	3
#define DLC_PLANE_PROPERTY_CHANNEL	4
#define DLC_PLANE_PROPERTY_TYPE		5

	int		plane_index;
	unsigned int	property;
	unsigned int	value;

} DLC_MSG_PLANE_PROPERTY;

typedef struct DLC_RESP_PLANE_PROPERTY_TAG
{
	DLC_RESP_HEADER	hdr;

	unsigned int	property;
	unsigned int	value;

} DLC_RESP_PLANE_PROPERTY;

/*
	DLC_CMD_GET_PLANE_INFO
	DLC_CMD_SET_PLANE
	DLC_CMD_SET_PLANE_DC
 */
typedef struct DLC_MSG_PLANE_INFO_TAG
{
	DLC_CMD_HEADER	hdr;

	int		connector_index;
	int		plane_index;
	int		crtc_index;
	unsigned int	fb_id;

	/* layer params */
	struct {
		unsigned int x, y;
		unsigned int w, h;
	} disp;

	/* source params */
	struct {
		unsigned int x, y;
		unsigned int w, h;
	} src;

	unsigned int	interval;
	unsigned int	dc_devid;

} DLC_MSG_PLANE_INFO;

typedef struct DLC_RESP_PLANE_INFO_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_PLANE_INFO;

/*
	DLC_CMD_ACQUIRE_DEVICE_DC
	DLC_CMD_RELEASE_DEVICE_DC
 */
typedef struct DLC_MSG_ACQUIRE_DEVICE_DC_TAG
{
	DLC_CMD_HEADER	hdr;

	unsigned int	plane_index;
	unsigned int	crtc_index;
	unsigned int	width;
	unsigned int	height;
	unsigned int	stride;
	unsigned int	format;
	unsigned int	buffers;

	unsigned long long	vaddr[DLCSRV_MAX_BUFFERS];

} DLC_MSG_ACQUIRE_DEVICE_DC;

typedef struct DLC_RESP_ACQUIRE_DEVICE_DC_TAG
{
	DLC_RESP_HEADER	hdr;

	unsigned int	dc_devid;

} DLC_RESP_ACQUIRE_DEVICE_DC;

typedef struct DLC_MSG_RELEASE_DEVICE_DC_TAG
{
	DLC_CMD_HEADER	hdr;

	unsigned int	plane_index;
	unsigned int	crtc_index;

} DLC_MSG_RELEASE_DEVICE_DC;

typedef struct DLC_RESP_RELEASE_DEVICE_DC_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_RELEASE_DEVICE_DC;

/*
	DLC_CMD_DRM_SET_MASTER
	DLC_CMD_DRM_DROP_MASTER
 */
typedef struct DLC_MSG_DRM_MASTER_TAG
{
	DLC_CMD_HEADER	hdr;

} DLC_MSG_DRM_MASTER;

typedef struct DLC_RESP_DRM_MASTER_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_DRM_MASTER;

/*
	DLC_CMD_DRM_AUTH_MAGIC
 */
typedef struct DLC_MSG_DRM_AUTH_MAGIC_TAG
{
	DLC_CMD_HEADER	hdr;

	drm_magic_t	magic;

} DLC_MSG_DRM_AUTH_MAGIC;

typedef struct DLC_RESP_DRM_AUTH_MAGIC_TAG
{
	DLC_RESP_HEADER	hdr;

} DLC_RESP_DRM_AUTH_MAGIC;

#endif /* __DLCSRV_PROTOCOLS_H */

