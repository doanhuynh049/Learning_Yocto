/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server
 *
 *      libdrm access functions
 */
#include <string.h>
#include <errno.h>
#include <pthread.h>

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>

#include "dlcsrv_common.h"

extern int drmFd;
extern drmModeRes *mode_res;
extern drmModePlaneRes *plane_res;

extern pthread_mutex_t drm_mutex;

DLC_STATUS DLCSRV_SubGetDpmsId(int connector_index, unsigned int *dpms_id)
{
	drmModeConnector *connector;
	int i;
	DLC_STATUS eStatus = DLC_STS_OK;

	if (connector_index >= mode_res->count_connectors)
	{
		return DLC_STS_INVALID_CONNECTOR;
	}

	connector = drmModeGetConnector(drmFd, mode_res->connectors[connector_index]);
	if (!connector || !connector->count_props)
	{
		return DLC_STS_NOT_SUPPORTED;
	}

	for (i = 0; i < connector->count_props; i++)
	{
		drmModePropertyRes *conn_prop;

		conn_prop = drmModeGetProperty(drmFd, connector->props[i]);
		if (!conn_prop)
		{
			eStatus = DLC_STS_OUT_OF_MEMORY;
			break;
		}

		if (!strcmp(conn_prop->name, "DPMS"))
		{
			*dpms_id = connector->props[i];

			drmModeFreeProperty(conn_prop);
			break;
		}

		drmModeFreeProperty(conn_prop);
	}

	if (i >= connector->count_props)
	{
		eStatus = DLC_STS_NOT_SUPPORTED;
	}

	drmModeFreeConnector(connector);

	return eStatus;
}

DLC_STATUS DLCSRV_SubGetDpmsMode(unsigned int dpms_id, unsigned int *dpms_mode)
{
	drmModePropertyRes *conn_prop;
	DLC_STATUS eStatus = DLC_STS_OK;

	conn_prop = drmModeGetProperty(drmFd, dpms_id);
	if (!conn_prop)
	{
		return DLC_STS_NOT_SUPPORTED;
	}

	if (!strcmp(conn_prop->name, "DPMS"))
	{
		*dpms_mode = conn_prop->values[0];
	}
	else
	{
		eStatus = DLC_STS_INVALID_PARAMS;
	}

	drmModeFreeProperty(conn_prop);

	return eStatus;
}

DLC_STATUS DLCSRV_SubSetDpmsMode(int connector_index, unsigned int dpms_id, unsigned int dpms_mode)
{
	int conn_id;
	DLC_STATUS eStatus = DLC_STS_OK;

	if (connector_index >= mode_res->count_connectors)
	{
		return DLC_STS_INVALID_CONNECTOR;
	}

	conn_id = mode_res->connectors[connector_index];

	pthread_mutex_lock(&drm_mutex);
	if (DLCSRV_SetMaster() == DLCSRV_OK)
	{
		if (drmModeConnectorSetProperty(drmFd, conn_id, dpms_id, dpms_mode))
		{
			DLCSRV_LOG_ERR("property set error (connecotr=%d, prop_id = %d, value = %d): %s\n",
					conn_id, dpms_id, dpms_mode, strerror(errno));

			eStatus = DLC_STS_NOT_SUPPORTED;
		}
		DLCSRV_DropMaster();
	}
	else
	{
		eStatus = DLC_STS_NOT_A_MASTER;
	}
	pthread_mutex_unlock(&drm_mutex);

	return eStatus;
}

