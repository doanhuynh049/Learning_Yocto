/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server
 *
 *	libdrm access functions
 */

#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>


#include "dlcsrv_common.h"

int drmFd;
drmModeRes *mode_res = NULL;
drmModePlaneRes *plane_res = NULL;
drmModePlaneRes *plane_univ_res = NULL;
int dpms_id = 0;

static void **vbl_threads = NULL;

DLCSRV_DESKTOP_STATUS *desktop_stat = NULL;
DLCSRV_PLANE_STATUS *plane_stat = NULL;
static int setmaster_count = 0;

DLCSRV_RESULT DLCSRV_SetMaster(void)
{
	if (drmSetMaster(drmFd))
	{
		DLCSRV_LOG_WARN("other DRM-Master process is running\n");

		return DLCSRV_ERROR_SET_MASTER;
	}

	setmaster_count++;

	return DLCSRV_OK;
}

void DLCSRV_DropMaster(void)
{
	if (setmaster_count > 0)
	{
		setmaster_count--;
	}

	if (setmaster_count == 0)
	{
		drmDropMaster(drmFd);
	}
}

DLCSRV_RESULT DLCSRV_AuthMagic(drm_magic_t magic)
{
	DLCSRV_RESULT eResult = DLCSRV_OK;

	if (DLCSRV_SetMaster() == DLCSRV_OK)
	{
		if (drmAuthMagic(drmFd, magic))
		{
			eResult =  DLCSRV_ERROR_AUTH_MAGIC;
		}

		DLCSRV_DropMaster();
	}

	return eResult;
}

int DLCSRV_GetConnectorNum(void)
{
	if (!mode_res)
	{
		return 0;
	}

	return mode_res->count_connectors;
}

int DLCSRV_ConnectorIndexToId(int index)
{
	if (!mode_res || mode_res->count_connectors <= index)
	{
		return 0;
	}

	return mode_res->connectors[index];
}

int DLCSRV_GetEncoderNum(void)
{
	if (!mode_res)
	{
		return 0;
	}

	return mode_res->count_encoders;
}

int DLCSRV_EncoderIndexToId(int index)
{
	if (!mode_res || mode_res->count_encoders <= index)
	{
		return 0;
	}

	return mode_res->encoders[index];
}

int DLCSRV_GetCrtcNum(void)
{
	if (!mode_res)
	{
		return 0;
	}

	return mode_res->count_crtcs;
}

int DLCSRV_CrtcIndexToId(int index)
{
	if (!mode_res || mode_res->count_crtcs <= index)
	{
		return 0;
	}

	return mode_res->crtcs[index];
}

int DLCSRV_GetPlaneNum(void)
{
	if (!plane_res)
	{
		return 0;
	}

	return plane_res->count_planes;
}

int DLCSRV_PlaneIndexToId(int index)
{
	if (!plane_res || (int)plane_res->count_planes <= index)
	{
		return 0;
	}

	return plane_res->planes[index];
}

int DLCSRV_UniversalPlaneIndexToId(int index)
{
	if (!plane_univ_res || (int)plane_univ_res->count_planes <= index)
	{
		return 0;
	}

	return plane_univ_res->planes[index];
}

DLCSRV_RESULT DLCSRV_InitDRM(const char *devname, int server_mode)
{
	int i = 0;

	/*
	 * Initialize DRM resources.
	 */

	drmFd = drmOpen(devname, NULL);
	if (drmFd < 0)
	{
		goto err_drm_open;
	}

	mode_res = drmModeGetResources(drmFd);
	if (!mode_res)
	{
		goto err_drm_mode_res;
	}

	plane_res = drmModeGetPlaneResources(drmFd);
	if (!plane_res)
	{
		goto err_drm_plane_res;
	}

	DLCSRV_DropMaster();

	if (server_mode)
	{
		desktop_stat = (DLCSRV_DESKTOP_STATUS *)malloc(sizeof(DLCSRV_DESKTOP_STATUS) * mode_res->count_crtcs);
		if (!desktop_stat)
		{
			goto err_desktop_struct;
		}
		memset(desktop_stat, 0, sizeof(DLCSRV_DESKTOP_STATUS) * mode_res->count_crtcs);

		plane_stat = (DLCSRV_PLANE_STATUS *)malloc(sizeof(DLCSRV_PLANE_STATUS) * plane_res->count_planes);
		if (!plane_stat)
		{
			goto err_plane_struct;
		}
		memset(plane_stat, 0, sizeof(DLCSRV_PLANE_STATUS) * plane_res->count_planes);

#ifdef USE_DRMATOMIC
		if (DLCSRV_AcquireAtomic() != DLCSRV_OK)
		{
			goto err_init_atomic;
		}

		plane_univ_res = drmModeGetPlaneResources(drmFd);
		if (!plane_univ_res)
		{
			goto err_drm_plane_univ_res;
		}
#endif /* USE_DRMATOMIC */

		/*
		 * Start VBLANK interrupt threads.
		 */
		vbl_threads = (void *)malloc(sizeof(void *) * mode_res->count_crtcs);
		if (!vbl_threads)
		{
			DLCSRV_LOG_ERR("out of memory: exit\n");
			goto err_thread_memory;
		}

		for (i = 0; i < mode_res->count_crtcs; i++)
		{
			vbl_threads[i] = DLCSRV_StartVBlankThread(i);
			if (!vbl_threads[i])
			{
				goto err_start_thread;
			}
		}

		/*
		 * Acquire PVRScope contexts.
		 */
		DLCSRV_DRMLog_InitScope();

	}

	return DLCSRV_OK;

err_start_thread:
	i--;
	for ( ; i >= 0; i--)
	{
		DLCSRV_StopVBlankThread(vbl_threads[i]);
	}

err_thread_memory:
#ifdef USE_DRMATOMIC
	drmModeFreePlaneResources(plane_univ_res);

err_drm_plane_univ_res:
	DLCSRV_ReleaseAtomic();

err_init_atomic:
#endif /* USE_DRMATOMIC */
	if (plane_stat)
	{
		free(plane_stat);
	}

err_plane_struct:
	if (desktop_stat)
	{
		free(desktop_stat);
	}

err_desktop_struct:
	drmModeFreePlaneResources(plane_res);

err_drm_plane_res:
	drmModeFreeResources(mode_res);

err_drm_mode_res:
	drmClose(drmFd);

err_drm_open:
	return DLCSRV_ERROR_CANNOT_INITIALIZE;

}

void DLCSRV_KillAllVBlankThreads(void)
{
	int i;

	/*
	 * Stop VBLANK interrupt threads.
	 */
	if (vbl_threads)
	{
		for (i = 0; i < mode_res->count_crtcs; i++)
		{
			DLCSRV_StopVBlankThread(vbl_threads[i]);
		}

		free(vbl_threads);
		vbl_threads = NULL;
	}
}

void DLCSRV_DeinitDRM(void)
{
	DLCSRV_KillAllVBlankThreads();

	DLCSRV_DRMLog_DeinitScope();

#ifdef USE_DRMATOMIC
	DLCSRV_ReleaseAtomic();
#endif /* USE_DRMATOMIC */

	/*
	 * Release DRM resources.
	 */
	drmModeFreePlaneResources(plane_res);
	drmModeFreeResources(mode_res);

	plane_res = NULL;
	mode_res = NULL;

	if (plane_stat)
	{
		free(plane_stat);
		plane_stat = NULL;
	}

	if (desktop_stat)
	{
		free(desktop_stat);
		desktop_stat = NULL;
	}

	drmClose(drmFd);
}

