/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server
 */
#ifndef __DLCSRV_COMMON_H
#define __DLCSRV_COMMON_H

#include <syslog.h>
#include <stdbool.h>

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm/drm.h>

#define USE_DRMATOMIC


/* DRM server common setteings */

#ifndef DLC_UNREFERENCED_PARAMETER
#define DLC_UNREFERENCED_PARAMETER(param) ((void)(param))
#endif

#ifdef DLCSRV_DEBUG
#define DLCSRV_LOG_ERR(x...)	syslog(LOG_ERR, x)
#define DLCSRV_LOG_WARN(x...)	syslog(LOG_WARNING, x)
#define DLCSRV_LOG_INFO(x...)	syslog(LOG_INFO, x)
#define DLCSRV_LOG_DEBUG(x...)	syslog(LOG_DEBUG, x)
#else
#define DLCSRV_LOG_ERR(x...)	syslog(LOG_ERR, x)
#define DLCSRV_LOG_WARN(x...)	syslog(LOG_WARNING, x)
#define DLCSRV_LOG_INFO(x...)	syslog(LOG_INFO, x)
#define DLCSRV_LOG_DEBUG(x...)
#endif

#include "dlcsrv_protocol.h"

typedef enum DLCSRV_RESULT_TAG
{
	DLCSRV_OK = 0,

	DLCSRV_ERROR_INVALID_PARAMS,
	DLCSRV_ERROR_CANNOT_INITIALIZE,
	DLCSRV_ERROR_NOT_SUPPORTED,
	DLCSRV_ERROR_COMMAND_MISMATCH,
	DLCSRV_ERROR_OUT_OF_MEMORY,

	DLCSRV_ERROR_TIMEOUT,

	DLCSRV_ERROR_PLANE_BUSY,
	DLCSRV_ERROR_FLIPCHAIN_BUSY,
	DLCSRV_ERROR_PERMISSION_DENIED,
	DLCSRV_ERROR_SET_MASTER,

	DLCSRV_ERROR_AUTH_MAGIC,

} DLCSRV_RESULT;

/*******************************************************************************/

typedef struct DLCSRV_MSG_TERMINATE_TAG
{
	DLC_CMD_HEADER	hdr;

} DLCSRV_MSG_TERMINATE;

typedef struct DLCSRV_RESP_TERMINATE_TAG
{
	DLC_RESP_HEADER	hdr;

} DLCSRV_RESP_TERMINATE;

/*******************************************************************************/

typedef struct DLCSRV_BUFFER_TAG DLCSRV_BUFFER;

typedef struct DLCSRV_CLIENT_TAG
{
	int index;

	int client_fd;

	pthread_t thread;
	unsigned int command;
	unsigned int terminate;
	unsigned int killall;

	DLCSRV_BUFFER *buffers;

} DLCSRV_CLIENT;

typedef struct DLCSRV_RECT_TAG
{
	unsigned int x, y;
	unsigned int width, height;
} DLCSRV_RECT;

typedef enum DLCSRV_FLIP_STATUS_TAG
{
	DLCSRV_FLIP_IDLE	= 0,
	DLCSRV_FLIP_DONE,
	DLCSRV_FLIP_FLIPPED,
	DLCSRV_FLIP_PENDING,

} DLCSRV_FLIP_STATUS;


typedef struct DLCSRV_FLIP_QUEUE_TAG
{
	DLCSRV_FLIP_STATUS status;

	unsigned int interval;

	unsigned int fb_id;

} DLCSRV_FLIP_QUEUE;

typedef struct DLCSRV_FLIP_QUEUE_INDEX_TAG
{
	int insert;
	int remove;
	int current;

} DLCSRV_FLIP_QUEUE_INDEX;

#ifdef USE_DRMATOMIC
typedef struct DLCSRV_PROPEATY_ID_TAG
{
	unsigned int crtc_pid;
	unsigned int fb_pid;
	unsigned int zpos_pid;
	unsigned int crtc_x_pid;
	unsigned int crtc_y_pid;
	unsigned int crtc_w_pid;
	unsigned int crtc_h_pid;
	unsigned int src_x_pid;
	unsigned int src_y_pid;
	unsigned int src_w_pid;
	unsigned int src_h_pid;

} DLCSRV_PROPEATY_ID;
#endif /* USE_DRMATOMIC */

typedef struct DLCSRV_PLANE_STATUS_TAG
{
	unsigned int in_use;

	int client_fd;

	int crtc_index;

	unsigned int crtc_x, crtc_y;
	unsigned int crtc_w, crtc_h;
	unsigned int src_x, src_y;
	unsigned int src_w, src_h;

	int buffers;

	DLCSRV_FLIP_QUEUE_INDEX flip_index;
	DLCSRV_FLIP_QUEUE flip_queue[DLCSRV_MAX_BUFFERS];

#ifdef USE_DRMATOMIC
	DLCSRV_PROPEATY_ID property_id;
#endif /* USE_DRMATOMIC */

} DLCSRV_PLANE_STATUS;

typedef struct DLCSRV_DESKTOP_STATUS_TAG
{
	DLCSRV_PLANE_STATUS plane;

	int plane_index;
	unsigned int plane_id;

	unsigned int old_fb_id;

} DLCSRV_DESKTOP_STATUS;

typedef struct DLCSRV_BUFFER_TAG
{
	unsigned int gem_handle;
	unsigned int fb_id;

	DLCSRV_BUFFER *next;

} DLCSRV_BUFFER;

/* dlcsrv_main.c */
void CloseConnection(int index);
void CloseAllClient(void);

/* dlcsrv_drmio.c */
DLCSRV_RESULT DLCSRV_SetMaster(void);
void DLCSRV_DropMaster(void);
DLCSRV_RESULT DLCSRV_AuthMagic(drm_magic_t magic);
int DLCSRV_GetConnectorNum(void);
int DLCSRV_ConnectorIndexToId(int index);
int DLCSRV_GetEncoderNum(void);
int DLCSRV_EncoderIndexToId(int index);
int DLCSRV_GetCrtcNum(void);
int DLCSRV_CrtcIndexToId(int index);
int DLCSRV_GetPlaneNum(void);
int DLCSRV_PlaneIndexToId(int index);
int DLCSRV_UniversalPlaneIndexToId(int index);
DLCSRV_RESULT DLCSRV_InitDRM(const char *devname, int server_mode);
void DLCSRV_KillAllVBlankThreads(void);
void DLCSRV_DeinitDRM(void);

/* dlcsrv_command.c */
DLCSRV_RESULT DLCSRV_RespPageFlipComplete(int client_fd);
DLCSRV_RESULT DLCSRV_RespDrmModeSetPlaneComplete(int client_fd);
DLCSRV_RESULT DLCSRV_CmdServerTerminate(int client_fd);
DLC_COMMANDS DLCSRV_CheckCommand(int client_fd);
DLCSRV_RESULT DLCSRV_RemoteServerTerminate(int socket_fd);
void *DLCSRV_CommandThread(void *arg);

/* dlcsrv_event.c */
void *DLCSRV_StartVBlankThread(int crtc_index);
void DLCSRV_StopVBlankThread(void *arg);
void DLCSRV_WaitVBlank(int crtc_index, unsigned int sequence);

#ifdef USE_DRMATOMIC
/* dlcsrv_atomic.c */
DLC_STATUS DLCSRV_AtomicCommit(int crtc_index,
				drmModeAtomicReqPtr atomic_req,
				void *user_data);
DLC_STATUS DLCSRV_AtomicAddProperties(unsigned int plane_id,
					unsigned int fb_id,
					DLCSRV_PLANE_STATUS *plane,
					drmModeAtomicReqPtr req,
					void *user_data);
DLC_STATUS DLCSRV_GetPropertyID(drmModeObjectPropertiesPtr obj_props,
					const char *prop_name,
					unsigned int *prop_id);
DLC_STATUS DLCSRV_GetPlaneProperties(unsigned int plane_id, DLCSRV_PROPEATY_ID *prop_id);
DLCSRV_RESULT DLCSRV_AcquireAtomic(void);
void DLCSRV_ReleaseAtomic(void);
#endif /* USE_DRMATOMIC */

/* dlcsrv_buffer.c */
DLC_STATUS DLCSRV_SubAllocBuffer(DLCSRV_CLIENT *client,
					unsigned int flink_name,
					unsigned int width,
					unsigned int height,
					unsigned int format,
					unsigned int pitch,
					unsigned int *gem_handle,
					unsigned int *fb_id);
DLC_STATUS DLCSRV_SubFreeBuffer(DLCSRV_CLIENT *client, unsigned int gem_handle, unsigned int fb_id);
DLC_STATUS DLCSRV_SubFreeBufferAll(DLCSRV_CLIENT *client);


/* dlcsrv_conn.c */
DLC_STATUS DLCSRV_SubGetDpmsId(int conn_index, unsigned int *dpms_id);
DLC_STATUS DLCSRV_SubGetDpmsMode(unsigned int dpms_id, unsigned int *dpms_mode);
DLC_STATUS DLCSRV_SubSetDpmsMode(int conn_index, unsigned int dpms_id, unsigned int dpms_mode);

/* dlcsrv_crtc.c */
DLC_STATUS DLCSRV_SubAcquireDesktop(int crtc_index, int buffers);
DLC_STATUS DLCSRV_SubReleaseDesktop(int crtc_index);
DLC_STATUS DLCSRV_SubDisableDesktop(int crtc_index);
DLC_STATUS DLCSRV_SubGetMode(int crtc_index, unsigned int *width, unsigned int *height);
DLC_STATUS DLCSRV_SubSetMode(int crtc_index, int conn_index,
				unsigned int fb_id,
				unsigned int width, unsigned int height,
				unsigned int src_x, unsigned int src_y);
DLC_STATUS DLCSRV_PageFlip(int crtc_index, unsigned int fb_id);
DLC_STATUS DLCSRV_SubPageFlip(int crtc_index, unsigned int fb_id);
DLC_STATUS DLCSRV_SubAddSetDesktopQueue(int client_fd, int crtc_index, unsigned int fb_id,
					unsigned int vinterval);

/* dlcsrv_plane.c */
DLC_STATUS DLCSRV_SubAcquirePlane(int crtc_index, int buffers, int *plane_index, unsigned int *plane_id);
DLC_STATUS DLCSRV_SubReleasePlane(int plane_index);
DLC_STATUS DLCSRV_SubGetUniversalPlaneProperty(int plane_index, int property, unsigned int *value);
DLC_STATUS DLCSRV_SubGetPlaneProperty(int plane_index, int property, unsigned int *value);
DLC_STATUS DLCSRV_SubSetPlaneProperty(int plane_index, int property, unsigned int value);
DLC_STATUS DLCSRV_SetPlane(unsigned int plane_id, int crtc_index, unsigned int fb_id,
				unsigned int crtc_x, unsigned int crtc_y,
				unsigned int crtc_w, unsigned int crtc_h,
				unsigned int src_x, unsigned int src_y,
				unsigned int src_w, unsigned int src_h);
DLC_STATUS DLCSRV_SubSetPlane(int plane_index, int crtc_index, unsigned int fb_id,
				unsigned int crtc_x, unsigned int crtc_y,
				unsigned int crtc_w, unsigned int crtc_h,
				unsigned int src_x, unsigned int src_y,
				unsigned int src_w, unsigned int src_h);
DLC_STATUS DLCSRV_SubDisablePlane(int plane_index);
DLC_STATUS DLCSRV_SubAddSetPlaneQueue(int client_fd, int plane_index,
					unsigned int fb_id,
					unsigned int crtc_x, unsigned int crtc_y,
					unsigned int crtc_w, unsigned int crtc_h,
					unsigned int src_x, unsigned int src_y,
					unsigned int src_w, unsigned int src_h,
					unsigned int vinterval);

/* dlcsrv_log.c */
void DLCSRV_DRMLog_InitScope(void);
void DLCSRV_DRMLog_DeinitScope(void);
void DLCSRV_DRMLog_StartContext(unsigned int crtc_index);
void DLCSRV_DRMLog_StopContext(unsigned int crtc_index);
void DLCSRV_DRMLog_TimingBegin(unsigned int crtc_index, const char *title, unsigned int plane_id, unsigned int fb_id, bool update_frame);
void DLCSRV_DRMLog_TimingEnd(unsigned int crtc_index);
void DLCSRV_DRMLog_TimingVSYNC(unsigned int crtc_index);


#endif /* __DLCSRV_COMMON_H */

