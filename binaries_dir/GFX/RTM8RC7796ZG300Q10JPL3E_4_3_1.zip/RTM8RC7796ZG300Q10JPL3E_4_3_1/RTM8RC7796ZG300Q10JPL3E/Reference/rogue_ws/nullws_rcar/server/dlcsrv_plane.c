/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server
 *
 *      libdrm access functions
 */

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>

#include "dlcsrv_common.h"

extern int drmFd;
extern drmModePlaneRes *plane_res;

extern DLCSRV_DESKTOP_STATUS *desktop_stat;
extern DLCSRV_PLANE_STATUS *plane_stat;

extern pthread_mutex_t drm_mutex;

DLC_STATUS DLCSRV_SubAcquirePlane(int crtc_index, int buffers, int *plane_index, unsigned int *plane_id)
{
	int search_count;
	int i;
	drmModePlane *mode_plane;
	int found = 0;
#ifdef USE_DRMATOMIC
	DLCSRV_PROPEATY_ID property_id;
#endif /* USE_DRMATOMIC */

	DLC_STATUS eStatus = DLC_STS_OK;

	if (buffers > DLCSRV_MAX_BUFFERS)
	{
		return DLC_STS_TOO_MANY_BUFFERS;
	}

	pthread_mutex_lock(&drm_mutex);

	/* search free plane */
	for (search_count= 0; search_count <= 1; search_count++)
	{
		/*
		 * search_count == 0: search a plane from current channel
		 *                 1: search a plane from all channle
		 */
		for (i = 0; i < (int)plane_res->count_planes; i++)
		{
			DLCSRV_PLANE_STATUS *plane = &plane_stat[i];

			mode_plane = drmModeGetPlane(drmFd, plane_res->planes[i]);
			if (!mode_plane)
			{
				if (errno == ENOMEM)
				{
					eStatus = DLC_STS_OUT_OF_MEMORY;
				}
				else
				{
					eStatus = DLC_STS_INVALID_PARAMS;
				}
				break;
			}
			if ((mode_plane->possible_crtcs & (1 << crtc_index)) && !mode_plane->fb_id)
			{
				if (plane->in_use)
				{
					continue;
				}

				if (search_count == 0)
				{
					unsigned int value;

					DLCSRV_SubGetPlaneProperty(i, DLC_PLANE_PROPERTY_CHANNEL, &value);
					if (value != (unsigned int)crtc_index)
					{
						continue;
					}
				}

#ifdef USE_DRMATOMIC
				if (DLCSRV_SetMaster() == DLCSRV_OK)
				{
					eStatus = DLCSRV_GetPlaneProperties(plane_res->planes[i], &property_id);
					DLCSRV_DropMaster();

					if  (eStatus != DLC_STS_OK)
					{
						continue;
					}
				}
#endif /* USE_DRMATOMIC */

				found++;
			}
			drmModeFreePlane(mode_plane);

			if (found)
			{
				plane->in_use = 1;
				plane->crtc_index = crtc_index;
				plane->flip_index.insert = 0;
				plane->flip_index.remove = 0;
				plane->flip_index.current = 0;

				plane->buffers = buffers;
#ifdef USE_DRMATOMIC
				plane->property_id = property_id;
#endif /* USE_DRMATOMIC */

				*plane_index = i;
				*plane_id = plane_res->planes[i];

				DLCSRV_DRMLog_StartContext(plane->crtc_index);

				break;
			}
		}
		if (found)
		{
			break;
		}
	}

	pthread_mutex_unlock(&drm_mutex);

	if (!found)
	{
		eStatus = DLC_STS_PLANE_NOT_FOUND;
	}

	return eStatus;
}

DLC_STATUS DLCSRV_SubReleasePlane(int plane_index)
{
	DLCSRV_PLANE_STATUS *plane;

	if (plane_index >= (int)plane_res->count_planes)
	{
		return DLC_STS_INVALID_PLANE;
	}

	DLCSRV_SubDisablePlane(plane_index);

	plane = &plane_stat[plane_index];

	pthread_mutex_lock(&drm_mutex);
	plane->in_use = 0;
	pthread_mutex_unlock(&drm_mutex);

	DLCSRV_DRMLog_StopContext(plane->crtc_index);

	return DLC_STS_OK;
}

static DLC_STATUS GetPlaneProperty(unsigned int plane_id, int property, unsigned int *value)
{
	drmModeObjectProperties *obj_props;
	char *prop_name;
	unsigned int prop_index;
	int found = 0;

	switch (property)
	{
	case DLC_PLANE_PROPERTY_ALPHA:
		prop_name = "alpha";
		break;
	case DLC_PLANE_PROPERTY_COLORKEY:
		prop_name = "colorkey";
		break;
	case DLC_PLANE_PROPERTY_PRIORITY:
		prop_name = "zpos";
		break;
	case DLC_PLANE_PROPERTY_CHANNEL:
		prop_name = "channel";
		break;
	case DLC_PLANE_PROPERTY_TYPE:
		prop_name = "type";
		break;
	default:
		return DLC_STS_INVALID_PARAMS;
	}

	obj_props = drmModeObjectGetProperties(drmFd, plane_id, DRM_MODE_OBJECT_PLANE);
	for (prop_index = 0; prop_index < obj_props->count_props; prop_index++)
	{
		drmModePropertyRes *plane_prop;

		plane_prop = drmModeGetProperty(drmFd, obj_props->props[prop_index]);
		if (!strcmp(plane_prop->name, prop_name))
		{
			*value = obj_props->prop_values[prop_index];
			found = 1;
		}
		drmModeFreeProperty(plane_prop);

		if (found)
		{
			break;
		}
	}
	drmModeFreeObjectProperties(obj_props);

	if (!found)
	{
		return DLC_STS_NOT_SUPPORTED;
	}

	return DLC_STS_OK;
}

DLC_STATUS DLCSRV_SubGetUniversalPlaneProperty(int plane_index, int property, unsigned int *value)
{
	unsigned int plane_id;

	plane_id = DLCSRV_UniversalPlaneIndexToId(plane_index);
	if (!plane_id)
	{
		return DLC_STS_INVALID_PLANE;
	}

	return GetPlaneProperty(plane_id, property, value);
}

DLC_STATUS DLCSRV_SubGetPlaneProperty(int plane_index, int property, unsigned int *value)
{
	unsigned int plane_id;

	plane_id = DLCSRV_PlaneIndexToId(plane_index);
	if (!plane_id)
	{
		return DLC_STS_INVALID_PLANE;
	}

	return GetPlaneProperty(plane_id, property, value);
}

DLC_STATUS DLCSRV_SubSetPlaneProperty(int plane_index, int property, unsigned int value)
{
	unsigned int plane_id;
	drmModeObjectProperties *obj_props;
	char *prop_name;
	unsigned int prop_index;
	int found = 0;
	DLC_STATUS eStatus = DLC_STS_OK;

	plane_id = DLCSRV_PlaneIndexToId(plane_index);
	if (!plane_id)
	{
		return DLC_STS_INVALID_PLANE;
	}

	switch (property)
	{
	case DLC_PLANE_PROPERTY_ALPHA:
		prop_name = "alpha";
		break;
	case DLC_PLANE_PROPERTY_COLORKEY:
		prop_name = "colorkey";
		break;
	case DLC_PLANE_PROPERTY_PRIORITY:
		prop_name = "zpos";
		break;
	case DLC_PLANE_PROPERTY_CHANNEL:
		prop_name = "channel";
		break;
	default:
		return DLC_STS_INVALID_PARAMS;
	}

	obj_props = drmModeObjectGetProperties(drmFd, plane_id, DRM_MODE_OBJECT_PLANE);
	if (!obj_props)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	for (prop_index = 0; prop_index < obj_props->count_props; prop_index++)
	{
		drmModePropertyRes *plane_prop;

		plane_prop = drmModeGetProperty(drmFd, obj_props->props[prop_index]);
		if (!strcmp(plane_prop->name, prop_name))
		{
			found = 1;
		}
		drmModeFreeProperty(plane_prop);
		if (found)
		{
			break;
		}
	}

	if (found)
	{
		pthread_mutex_lock(&drm_mutex);
		if (DLCSRV_SetMaster() == DLCSRV_OK)
		{
			if (drmModeObjectSetProperty(drmFd, DLCSRV_PlaneIndexToId(plane_index), DRM_MODE_OBJECT_PLANE,
							obj_props->props[prop_index], value))
			{
				eStatus = DLC_STS_NOT_SUPPORTED;
			}
			DLCSRV_DropMaster();
		}
		else
		{
			eStatus = DLC_STS_NOT_A_MASTER;
		}
		pthread_mutex_unlock(&drm_mutex);
	}
	else
	{
		eStatus = DLC_STS_NOT_SUPPORTED;
	}

	drmModeFreeObjectProperties(obj_props);

	return eStatus;
}

DLC_STATUS DLCSRV_SetPlane(unsigned int plane_id, int crtc_index, unsigned int fb_id,
				unsigned int crtc_x, unsigned int crtc_y,
				unsigned int crtc_w, unsigned int crtc_h,
				unsigned int src_x, unsigned int src_y,
				unsigned int src_w, unsigned int src_h)
{
	DLC_STATUS eStatus = DLC_STS_OK;

	DLCSRV_DRMLog_TimingBegin(crtc_index, "SetPlane", plane_id, fb_id, false);

	if (drmModeSetPlane(drmFd, plane_id,
				DLCSRV_CrtcIndexToId(crtc_index),
				fb_id, 0,
				crtc_x, crtc_y,
				crtc_w, crtc_h,
				src_x << 16, src_y << 16,
				src_w << 16, src_h << 16))
	{
		DLCSRV_LOG_ERR("PLANE(%d): %s\n",
				plane_id,
				strerror(errno));

		switch (errno)
		{
		case ENOENT:
			/* bad fb */
			eStatus = DLC_STS_INVALID_FB;
			break;
		case EBUSY:
			/* plane is busy (for V-IN ?) */
			eStatus = DLC_STS_PLANE_BUSY;
			break;
		case ENOSPC:
			/* plane rectangle is lager than fb */
			eStatus = DLC_STS_PLANE_BAD_SRC_SIZE;
			break;
		case ERANGE:
			/* crtc coordinates is lager than system max */
			eStatus = DLC_STS_PLANE_BAD_CRTC_SIZE;
			break;
		case EINVAL:
			/* bad combination of plane and crtc */
			/* fall through */
		default:
			eStatus = DLC_STS_INVALID_PARAMS;
			break;
		}
	}

	DLCSRV_DRMLog_TimingEnd(crtc_index);

	return eStatus;
}

DLC_STATUS DLCSRV_SubSetPlane(int plane_index, int crtc_index, unsigned int fb_id,
				unsigned int crtc_x, unsigned int crtc_y,
				unsigned int crtc_w, unsigned int crtc_h,
				unsigned int src_x, unsigned int src_y,
				unsigned int src_w, unsigned int src_h)
{
	unsigned int plane_id, crtc_id;

	DLC_STATUS eStatus = DLC_STS_OK;

	plane_id = DLCSRV_PlaneIndexToId(plane_index);
	if (!plane_id)
	{
		return DLC_STS_INVALID_PLANE;
	}

	crtc_id = DLCSRV_CrtcIndexToId(crtc_index);
	if (!crtc_id)
	{
		return DLC_STS_INVALID_CRTC;
	}

	if (!fb_id)
	{
		return DLC_STS_INVALID_FB;
	}

	pthread_mutex_lock(&drm_mutex);
	if (DLCSRV_SetMaster() == DLCSRV_OK)
	{
#ifdef USE_DRMATOMIC
		DLCSRV_PLANE_STATUS *plane = &plane_stat[plane_index];
		plane->crtc_index = crtc_index;
		plane->crtc_x = crtc_x;
		plane->crtc_y = crtc_y;
		plane->crtc_w = crtc_w;
		plane->crtc_h = crtc_h;
		plane->src_x = src_x;
		plane->src_y = src_y;
		plane->src_w = src_w;
		plane->src_h = src_h;
		eStatus = DLCSRV_AtomicAddProperties(plane_id, fb_id, plane, NULL, NULL);
#else
		eStatus = DLCSRV_SetPlane(plane_id, crtc_index, fb_id,
						crtc_x, crtc_y,
						crtc_w, crtc_h,
						src_x, src_y,
						src_w, src_h);
#endif /* USE_DRMATOMIC */

		DLCSRV_DropMaster();
	}
	else
	{
		eStatus = DLC_STS_NOT_A_MASTER;
	}
	pthread_mutex_unlock(&drm_mutex);

	return eStatus;
}

DLC_STATUS DLCSRV_SubDisablePlane(int plane_index)
{
	DLCSRV_PLANE_STATUS *plane;

	if (plane_index >= (int)plane_res->count_planes)
	{
		return DLC_STS_INVALID_PLANE;
	}

	plane = &plane_stat[plane_index];

	pthread_mutex_lock(&drm_mutex);
	DLCSRV_SetMaster();
	if (plane->in_use)
	{
		DLCSRV_LOG_DEBUG("PLANE(id=%d): OFF\n", DLCSRV_PlaneIndexToId(plane_index));

		drmModeSetPlane(drmFd, DLCSRV_PlaneIndexToId(plane_index),
					0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	}
	DLCSRV_DropMaster();
	pthread_mutex_unlock(&drm_mutex);

	return DLC_STS_OK;
}

static void UpdateInsertIndex(DLCSRV_PLANE_STATUS *plane)
{
	plane->flip_index.insert++;

	if (plane->flip_index.insert >= plane->buffers)
	{
		plane->flip_index.insert = 0;
	}
}

DLC_STATUS DLCSRV_SubAddSetPlaneQueue(int client_fd, int plane_index, unsigned int fb_id,
					unsigned int crtc_x, unsigned int crtc_y,
					unsigned int crtc_w, unsigned int crtc_h,
					unsigned int src_x, unsigned int src_y,
					unsigned int src_w, unsigned int src_h,
					unsigned int vinterval)
{
	DLCSRV_PLANE_STATUS *plane;
	DLCSRV_FLIP_QUEUE *flip;

	if (plane_index >= (int)plane_res->count_planes)
	{
		return DLC_STS_INVALID_PLANE;
	}

	plane = &plane_stat[plane_index];

	pthread_mutex_lock(&drm_mutex);

	flip = &plane->flip_queue[plane->flip_index.insert];

	flip->fb_id = fb_id;
	flip->status = DLCSRV_FLIP_PENDING;
	flip->interval = vinterval;

	plane->client_fd = client_fd;

	plane->crtc_x = crtc_x;
	plane->crtc_y = crtc_y;
	plane->crtc_w = crtc_w;
	plane->crtc_h = crtc_h;

	plane->src_x = src_x;
	plane->src_y = src_y;
	plane->src_w = src_w;
	plane->src_h = src_h;

	UpdateInsertIndex(plane);

	pthread_mutex_unlock(&drm_mutex);

	/* check overtake */
	while (plane->flip_index.insert == plane->flip_index.current)
	{
		usleep(10);
	}

	/* send response to client */
	DLCSRV_RespDrmModeSetPlaneComplete(plane->client_fd);

	return DLC_STS_OK;
}

