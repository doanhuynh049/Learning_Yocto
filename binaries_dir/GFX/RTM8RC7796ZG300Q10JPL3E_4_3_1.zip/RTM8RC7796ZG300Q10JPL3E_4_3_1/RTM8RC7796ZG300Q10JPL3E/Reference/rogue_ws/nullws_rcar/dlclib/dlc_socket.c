/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>

#include <pthread.h>

#include "dlc_client.h"
#include "dlc_socket.h"
#include "dlc_protocol.h"

#ifdef DEBUG
#define DPF(x...)	fprintf(stderr, x)
#else
#define DPF(x...)
#endif

pthread_mutex_t drm_mutex = PTHREAD_MUTEX_INITIALIZER;

static int SendMessage(int client_fd, void *data, int len)
{
	struct msghdr msg = {0};
	int ret;
	struct iovec iov_data;

	msg.msg_name = NULL;
	msg.msg_flags = 0;

	iov_data.iov_base = data;
	iov_data.iov_len = len;

	msg.msg_iov = &iov_data;
	msg.msg_iovlen = 1;

	ret = sendmsg(client_fd, &msg, MSG_NOSIGNAL);
	if ((ret == -1) || (ret !=len))
	{
		return -1;
	}

	return 0;
}

static int RecieveMessage(int client_fd, void *data, int len)
{
	struct msghdr msg = {0};
	struct iovec iov_data;

	msg.msg_name = NULL;
	msg.msg_flags = 0;

	iov_data.iov_base = data;
	iov_data.iov_len = len;

	msg.msg_iov = &iov_data;
	msg.msg_iovlen = 1;

	return recvmsg(client_fd, &msg, 0);
}

static inline int TransmitMessage(int client_fd, void *out_msg, int out_msg_len, void *in_msg, int in_msg_len)
{
	DLC_CMD_HEADER *hdr = (DLC_CMD_HEADER *)out_msg;

	hdr->major_v = DLC_VER_MAJOR;
	hdr->minor_v = DLC_VER_MINOR;
	hdr->pid = getpid();

	pthread_mutex_lock(&drm_mutex);
	if (SendMessage(client_fd, out_msg, out_msg_len) == -1)
	{
		DPF("sendmsg(): %s\n", strerror(errno));

		switch (errno)
		{
		case EACCES:
		case EBADF:
		case ECONNRESET:
		case EDESTADDRREQ:
		case EISCONN:
		case ENOTCONN:
		case ENOTSOCK:
		case EPIPE:
			dlc_status = DLC_STS_CONNECTION_REFUSED;
			break;
		case EAGAIN:
		case EMSGSIZE:
		case ENOBUFS:
		case EFAULT:
		case EINTR:
		case ENOMEM:
		case EOPNOTSUPP:
		case EINVAL:
		default:
			dlc_status = DLC_STS_COMMUNICATION_ERROR;
			break;
		}

		pthread_mutex_unlock(&drm_mutex);
		return -1;
	}

	if (RecieveMessage(client_fd, in_msg, in_msg_len) == -1)
	{
		DPF("rcvmsg(): %s\n", strerror(errno));

		switch (errno)
		{
		case ECONNREFUSED:
		case ENOTCONN:
		case ENOTSOCK:
		case EBADF:
			dlc_status = DLC_STS_CONNECTION_REFUSED;
			break;
		case EFAULT:
		case EINTR:
		case EAGAIN:
		case EINVAL:
		case ENOMEM:
		default:
			dlc_status = DLC_STS_COMMUNICATION_ERROR;
			break;
		}

		pthread_mutex_unlock(&drm_mutex);
		return -1;
	}
	pthread_mutex_unlock(&drm_mutex);

	return 0;
}

int DLC_Socket_GetDpmsMode(int socket_fd, int conn_index, unsigned int *value)
{
	DLC_MSG_GET_DPMS_MODE out_msg;
	DLC_RESP_DPMS_MODE in_msg;

	out_msg.hdr.cmd = DLC_CMD_GET_DPMS_MODE;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.connector_index = conn_index;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_GET_DPMS_MODE)
	{
		DPF("DLC_CMD_GET_DPMS_MODE: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_GET_DPMS_MODE: fail\n");
		return -1;
	}

	*value = in_msg.dpms_mode;

	return 0;
}

int DLC_Socket_SetDpmsMode(int socket_fd, int conn_index, unsigned int value)
{
	DLC_MSG_SET_DPMS_MODE out_msg;
	DLC_RESP_DPMS_MODE in_msg;

	out_msg.hdr.cmd = DLC_CMD_SET_DPMS_MODE;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.connector_index = conn_index;
	out_msg.dpms_mode = value;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_SET_DPMS_MODE)
	{
		DPF("DLC_CMD_SET_DPMS_MODE: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_SET_DPMS_MODE: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_AcquireDesktop(int socket_fd,
				int crtc_index, int buffers)
{
	DLC_MSG_ACQUIRE_DESKTOP out_msg;
	DLC_RESP_ACQUIRE_DESKTOP in_msg;

	out_msg.hdr.cmd = DLC_CMD_ACQUIRE_DESKTOP;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.crtc_index = crtc_index;
	out_msg.buffers = buffers;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_ACQUIRE_DESKTOP)
	{
		DPF("DLC_CMD_ACQUIRE_DESKTOP: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_ACQUIRE_DESKTOP: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_ReleaseDesktop(int socket_fd, int crtc_index)
{
	DLC_MSG_RELEASE_DESKTOP out_msg;
	DLC_RESP_RELEASE_DESKTOP in_msg;

	out_msg.hdr.cmd = DLC_CMD_RELEASE_DESKTOP;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.crtc_index = crtc_index;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_RELEASE_DESKTOP: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_SetCrtcMode(int socket_fd, 
                                int crtc_index,
                                int conn_index,
                                unsigned int fb_id,
                                unsigned int width, unsigned int height,
                                unsigned int src_x, unsigned int src_y)
{
	DLC_MSG_SET_CRTC_MODE out_msg;
	DLC_RESP_CRTC_MODE in_msg;

	out_msg.hdr.cmd = DLC_CMD_SET_MODE;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.crtc_index = crtc_index;
	out_msg.connector_index = conn_index;
	out_msg.fb_id = fb_id;
	out_msg.hdisplay = width;
	out_msg.vdisplay = height;
	out_msg.src_x = src_x;
	out_msg.src_y = src_y;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_SET_MODE)
	{
		DPF("DLC_CMD_SET_MODE: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_SET_MODE: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_PageFlip(int socket_fd,
				int crtc_index,
				unsigned int fb_id,
				unsigned int interval)
{
	DLC_MSG_PAGE_FLIP out_msg;
	DLC_RESP_PAGE_FLIP in_msg;

	out_msg.hdr.cmd = DLC_CMD_PAGE_FLIP;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.crtc_index = crtc_index;
	out_msg.fb_id = fb_id;

	out_msg.interval = interval;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_PAGE_FLIP)
	{
		DPF("DLC_CMD_PAGE_FLIP: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_PAGE_FLIP: fail\n");
		return -1;
	}

        return 0;
}

int DLC_Socket_AllocateFB(int socket_fd,
				unsigned int flink_name,
				unsigned int width,
				unsigned int height,
				unsigned int format,
				unsigned int pitch,
				unsigned int *remote_handle,
				unsigned int *fb_id)
{
	DLC_MSG_ALLOC_BUFFER out_msg;
	DLC_RESP_ALLOC_BUFFER in_msg;

	out_msg.hdr.cmd = DLC_CMD_ALLOC_BUFFER;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.flink_name = flink_name;

	out_msg.width = width;
	out_msg.height = height;
	out_msg.format = format;
	out_msg.pitch = pitch;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_ALLOC_BUFFER)
	{
		DPF("DLC_CMD_ALLOC_BUFFER: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_ALLOC_BUFFER: fail\n");
		return -1;
	}

	*remote_handle = in_msg.gem_handle;
	*fb_id = in_msg.fb_id;

	return 0;
}

int DLC_Socket_DestroyFB(int socket_fd, unsigned int remote_handle, unsigned int fb_id)
{
	DLC_MSG_FREE_BUFFER out_msg;
	DLC_RESP_FREE_BUFFER in_msg;

	out_msg.hdr.cmd = DLC_CMD_FREE_BUFFER;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.gem_handle = remote_handle;
	out_msg.fb_id = fb_id;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_FREE_BUFFER)
	{
		DPF("DLC_CMD_FREE_BUFFER: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_FREE_BUFFER: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_AcquirePlane(int socket_fd,
				int crtc_index, int buffers,
				int *plane_index, unsigned int *plane_id)
{
	DLC_MSG_ACQUIRE_PLANE out_msg;
	DLC_RESP_ACQUIRE_PLANE in_msg;

	out_msg.hdr.cmd = DLC_CMD_ACQUIRE_PLANE;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.crtc_index = crtc_index;
	out_msg.buffers = buffers;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_ACQUIRE_PLANE)
	{
		DPF("DLC_CMD_ACQUIRE_PLANE: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_ACQUIRE_PLANE: fail\n");
		return -1;
	}

	*plane_index = in_msg.plane_index;
	*plane_id = in_msg.plane_id;

	return 0;
}

int DLC_Socket_ReleasePlane(int socket_fd, int plane_index)
{
	DLC_MSG_RELEASE_PLANE	out_msg;
	DLC_RESP_RELEASE_PLANE	in_msg;

	out_msg.hdr.cmd = DLC_CMD_RELEASE_PLANE;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.plane_index = plane_index;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_RELEASE_PLANE: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_GetPlaneProperty(int socket_fd, int plane_index, DLC_PLANE_PROPERTY prop, unsigned int *value)
{
	DLC_MSG_PLANE_PROPERTY		out_msg;
	DLC_RESP_PLANE_PROPERTY		in_msg;

	out_msg.hdr.cmd = DLC_CMD_GET_PLANE_PROPERTY;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.plane_index = plane_index;
	out_msg.property = prop;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_GET_PLANE_PROPERTY)
	{
		DPF("DLC_CMD_GET_PLANE_PROPERTY: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_GET_PLANE_PROPERTY: fail\n");
		return -1;
	}

	*value = in_msg.value;

	return 0;
}

int DLC_Socket_SetPlaneProperty(int socket_fd, int plane_index, DLC_PLANE_PROPERTY prop, unsigned int value)
{
	DLC_MSG_PLANE_PROPERTY		out_msg;
	DLC_RESP_PLANE_PROPERTY		in_msg;

	out_msg.hdr.cmd = DLC_CMD_SET_PLANE_PROPERTY;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.plane_index = plane_index;
	out_msg.property = prop;
	out_msg.value = value;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_SET_PLANE_PROPERTY)
	{
		DPF("DLC_CMD_SET_PLANE_PROPERTY: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_SET_PLANE_PROPERTY: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_SetPlane(int socket_fd,
				int conn_index,
				int plane_index,
				int crtc_index,
				unsigned int fb_id,
				unsigned int disp_x, unsigned int disp_y,
				unsigned int disp_w, unsigned int disp_h,
				unsigned int src_x, unsigned int src_y,
				unsigned int src_w, unsigned int src_h,
				unsigned int interval)
{
	DLC_MSG_PLANE_INFO		out_msg;
	DLC_RESP_PLANE_INFO		in_msg;

	out_msg.hdr.cmd = DLC_CMD_SET_PLANE;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.connector_index = conn_index;
	out_msg.plane_index = plane_index;
	out_msg.crtc_index = crtc_index;

	out_msg.fb_id = fb_id;

	out_msg.disp.x = disp_x;
	out_msg.disp.y = disp_y;
	out_msg.disp.w = disp_w;
	out_msg.disp.h = disp_h;

	out_msg.src.x = src_x;
	out_msg.src.y = src_y;
	out_msg.src.w = src_w;
	out_msg.src.h = src_h;

	out_msg.interval = interval;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_SET_PLANE)
	{
		DPF("DLC_CMD_SET_PLANE: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_SET_PLANE: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_AcquireDeviceDC(int socket_fd,
				int plane_index,
				int crtc_index,
				unsigned int width,
				unsigned int height,
				unsigned int bytestride,
				unsigned int format,
				unsigned int buffers,
				unsigned long long *vaddr,
				unsigned int *dc_devid)
{
	DLC_MSG_ACQUIRE_DEVICE_DC	out_msg;
	DLC_RESP_ACQUIRE_DEVICE_DC	in_msg;
	int i;

	memset(&out_msg, 0, sizeof(out_msg));

	out_msg.hdr.cmd = DLC_CMD_ACQUIRE_DEVICE_DC;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.plane_index = plane_index;
	out_msg.crtc_index = crtc_index;
	out_msg.width = width;
	out_msg.height = height;
	out_msg.format = format;
	out_msg.stride = bytestride;
	out_msg.buffers = buffers;

	if (vaddr)
	{
		for (i = 0; i < (int)buffers; i++)
		{
			out_msg.vaddr[i] = vaddr[i];
		}
	}

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_ACQUIRE_DEVICE_DC)
	{
		DPF("DLC_CMD_ACQUIRE_DEVICE_DC: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_ACQUIRE_DEVICE_DC: fail\n");
		return -1;
	}

	*dc_devid = in_msg.dc_devid;

	return 0;
}

int DLC_Socket_ReleaseDeviceDC(int socket_fd,
				int plane_index,
				int crtc_index)
{
	DLC_MSG_RELEASE_DEVICE_DC	out_msg;
	DLC_RESP_RELEASE_DEVICE_DC	in_msg;

	out_msg.hdr.cmd = DLC_CMD_RELEASE_DEVICE_DC;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.plane_index = plane_index;
	out_msg.crtc_index = crtc_index;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_RELEASE_DEVICE_DC)
	{
		DPF("DLC_CMD_RELEASE_DEVICE_DC: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_RELEASE_DEVICE_DC: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_SetPlaneDC(int socket_fd,
				int conn_index,
				int plane_index,
				int crtc_index,
				unsigned int fb_id,
				unsigned int disp_x, unsigned int disp_y,
				unsigned int disp_w, unsigned int disp_h,
				unsigned int src_x, unsigned int src_y,
				unsigned int src_w, unsigned int src_h,
				unsigned int dc_devid)
{
	DLC_MSG_PLANE_INFO	out_msg;
	DLC_RESP_PLANE_INFO	in_msg;

	out_msg.hdr.cmd = DLC_CMD_SET_PLANE_DC;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.connector_index = conn_index;
	out_msg.plane_index = plane_index;
	out_msg.crtc_index = crtc_index;

	out_msg.fb_id = fb_id;

	out_msg.disp.x = disp_x;
	out_msg.disp.y = disp_y;
	out_msg.disp.w = disp_w;
	out_msg.disp.h = disp_h;

	out_msg.src.x = src_x;
	out_msg.src.y = src_y;
	out_msg.src.w = src_w;
	out_msg.src.h = src_h;

	out_msg.interval = 0;
	out_msg.dc_devid = dc_devid;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_SET_PLANE_DC)
	{
		DPF("DLC_CMD_SET_PLANE_DC: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_SET_PLANE_DC: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_PageFlipDC(int socket_fd,
				int crtc_index,
				unsigned int fb_id,
				unsigned int dc_devid)
{
	DLC_MSG_PAGE_FLIP out_msg;
	DLC_RESP_PAGE_FLIP in_msg;

	out_msg.hdr.cmd = DLC_CMD_PAGE_FLIP_DC;
	out_msg.hdr.len = sizeof(out_msg);

	out_msg.crtc_index = crtc_index;
	out_msg.fb_id = fb_id;
	out_msg.dc_devid = dc_devid;

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_PAGE_FLIP_DC)
	{
		DPF("DLC_CMD_PAGE_FLIP_DC: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_PAGE_FLIP_DC: fail\n");
		return -1;
	}

	return 0;

}

int DLC_Socket_SvrSetMaster(int socket_fd)
{
	DLC_MSG_DRM_MASTER	out_msg;
	DLC_RESP_DRM_MASTER	in_msg;

	out_msg.hdr.cmd = DLC_CMD_DRM_SET_MASTER;
	out_msg.hdr.len = sizeof(out_msg);

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_DRM_SET_MASTER)
	{
		DPF("DLC_CMD_DRM_SET_MASTER: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_DRM_SET_MASTER: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_SvrDropMaster(int socket_fd)
{
	DLC_MSG_DRM_MASTER	out_msg;
	DLC_RESP_DRM_MASTER	in_msg;

	out_msg.hdr.cmd = DLC_CMD_DRM_DROP_MASTER;
	out_msg.hdr.len = sizeof(out_msg);

	if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
	{
		return -1;
	}
	if (in_msg.hdr.cmd != DLC_CMD_DRM_DROP_MASTER)
	{
		DPF("DLC_CMD_DRM_DROP_MASTER: command mismatch\n");
		dlc_status = DLC_STS_COMMAND_MISMATCH;
		return -1;
	}

	dlc_status = in_msg.hdr.status;
	if (dlc_status != DLC_STS_OK)
	{
		DPF("DLC_CMD_DRM_DROP_MASTER: fail\n");
		return -1;
	}

	return 0;
}

int DLC_Socket_SvrAuthMagic(int socket_fd, drm_magic_t magic)
{
	DLC_MSG_DRM_AUTH_MAGIC	out_msg;
        DLC_RESP_DRM_AUTH_MAGIC	in_msg;

        out_msg.hdr.cmd = DLC_CMD_DRM_AUTH_MAGIC;
        out_msg.hdr.len = sizeof(out_msg);

	out_msg.magic = magic;

        if (TransmitMessage(socket_fd, &out_msg, sizeof(out_msg), &in_msg, sizeof(in_msg)) == -1)
        {
                return -1;
        }
        if (in_msg.hdr.cmd != DLC_CMD_DRM_AUTH_MAGIC)
        {
                DPF("DLC_CMD_DRM_AUTH_MAGIC: command mismatch\n");
                dlc_status = DLC_STS_COMMAND_MISMATCH;
                return -1;
        }

        dlc_status = in_msg.hdr.status;
        if (dlc_status != DLC_STS_OK)
        {
                DPF("DLC_CMD_DRM_AUTH_MAGIC: fail\n");
                return -1;
        }

        return 0;
}

int DLC_ConnectServer(int *socket_fd)
{
	int retry;
	struct stat st_buf;
	int fd;
	struct sockaddr_un remote_addr;

	for (retry = 0; retry < 10; retry++)
	{
		if (stat(SOCKET_PATH, &st_buf))
		{
			pid_t pid;

			/* excecute DRM server */
			pid = fork();
			if (pid == -1)
			{
				DPF("fork(): %s\n", strerror(errno));
				dlc_status = DLC_STS_COMMUNICATION_ERROR;
				return -1;
			}

			if (pid == 0)
			{
				char *old_env;
				char new_env[BUFSIZ];
				char svr_timeout[16];

				old_env = getenv("PATH");
				sprintf(new_env, "%s:/usr/local/bin", old_env);
				setenv("PATH", new_env, 1);

				sprintf(svr_timeout, "%d", DLC_SERVER_TIMEOUT);

				execlp(DLCSVR_NAME, DLCSVR_NAME, "-t", svr_timeout, NULL);
			}
			else
			{
				int status;
				pid_t w_pid;

				do {
					usleep(1000);
					w_pid = waitpid(pid, &status, WNOHANG);
				} while (w_pid != pid);
			}
		}
		else if (S_ISSOCK(st_buf.st_mode))
		{
			/* DRM server exist */
			break;
		}
		else
		{
			DPF(SOCKET_PATH "is not a socket\n");
			dlc_status = DLC_STS_COMMUNICATION_ERROR;
			return -1;
		}

		usleep(1000);
	}

	fd = socket(AF_UNIX, SOCK_STREAM, 0);
	if (fd == -1)
	{
		DPF("socket(): %s\n", strerror(errno));
		dlc_status = DLC_STS_COMMUNICATION_ERROR;
		return -1;
	}

	remote_addr.sun_family = AF_UNIX;
	strncpy(remote_addr.sun_path, SOCKET_PATH, sizeof(remote_addr.sun_path) - 1);

	if (connect(fd, (struct sockaddr *)&remote_addr, sizeof(struct sockaddr_un)) == -1)
	{
		DPF("connect(): %s\n", strerror(errno));

		dlc_status = DLC_STS_SERVER_NOT_RESPONDED;

		return -1;
	}

	*socket_fd = fd;

	pthread_mutex_init(&drm_mutex, NULL);

	dlc_status = DLC_STS_OK;

	return 0;
}

void DLC_DisconnectServer(int socket_fd)
{
	shutdown(socket_fd, SHUT_RDWR);
	close(socket_fd);

	dlc_status = DLC_STS_OK;

	pthread_mutex_destroy(&drm_mutex);
}

