/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

#ifndef __DLC_SCOPE_H
#define __DLC_SCOPE_H

#include "dlcsrv_scope.h"

typedef struct SCOPE_FUNCTION_TABLE_TAG
{
	SCOPE_HANDLE (*pfnAcquire)(const char *, const char *, unsigned int, eScopeBool);
	void (*pfnRelease)(SCOPE_HANDLE);
	void (*pfnStartContext(SCOPE_HANDLE);
	void (*pfnStopContext(SCOPE_HANDLE);
	void (*pfnUpdateFrame)(SCOPE_HANDLE);
	void (*pfnTimingBegin)(SCOPE_HANDLE, const char*, unsigned int, unsigned int);
	void (*pfnTimingEnd)(SCOPE_HANDLE);
	void (*pfnTimingVSYNC)(SCOPE_HANDLE);

} SCOPE_FUNCTION_TABLE;

const SCOPE_FUNCTION_TABLE* DLCScope_GetProcAddress(void);

#endif /* __DLC_SCOPE_H */
