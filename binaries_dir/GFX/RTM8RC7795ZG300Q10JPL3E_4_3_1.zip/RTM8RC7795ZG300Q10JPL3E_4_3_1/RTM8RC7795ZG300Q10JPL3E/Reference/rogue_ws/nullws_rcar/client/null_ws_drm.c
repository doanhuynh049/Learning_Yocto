/*************************************************************************/ /*!
@File           null_ws_drm.c
@Title          NULLDRM WSEGL module
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
                Copyright (c) 2013-2016 Renesas Electronics Corporation
@License        Strictly Confidential.
*/ /**************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <pthread.h>
#include <semaphore.h>

#include "dlc_client.h"

#include <EGL/eglplatform.h>
#include <EGL/egl.h>
#include <EGL/eglext_REL.h>
#include "null_ws_drm.h"
#include "rcargx_version.h"

#if defined(SUPPORT_WSEGL_LOGGING)
#include "dlcsrv_scope.h"
IMG_HANDLE hScopeMain = 0;
IMG_HANDLE hScopeFlip = 0;
#endif /* SUPPORT_WSEGL_LOGGING */

#define D_MIN_BUFFER_SIZE		16
#define D_MAX_BUFFER_SIZE		8192
#define D_STRIDE_GRANULARITY		2U

const char *const __rcargx_version = RCARGX_VERSION_CODE_STRING;

NULLDRM_WSEGL_DISPLAY gasDisplay[NULLDRM_NUM_DISPLAYS] = { {0} };

/* Used by client and server */
static NULLDRM_WSEGL_INFO gsWSInfo;

static bool bConnectedToServices = false;

static WSEGLCaps gasCaps[] =
{
	{ WSEGL_CAP_COLORSPACE, WSEGL_COLORSPACE_NONE },
	{ WSEGL_CAP_IMAGE_COLORSPACE, WSEGL_COLORSPACE_NONE },
	{ WSEGL_CAP_WINDOWS_USE_HW_SYNC, 1 },
	{ WSEGL_CAP_MIN_SWAP_INTERVAL, NULLDRM_MIN_SWAP_INTERVAL },
	{ WSEGL_CAP_MAX_SWAP_INTERVAL, NULLDRM_MAX_SWAP_INTERVAL },
	{ WSEGL_CAP_IMAGE_EXTERNAL_SUPPORT, 1},		/* [RELCOMMENT STD-0052:P-0149] Add to support eglImage_external for glslcompiler. */
	{ WSEGL_NO_CAPS, 0 }
};

static WSEGLConfig gasConfigs[] =
{
	{ WSEGL_DRAWABLE_WINDOW | WSEGL_DRAWABLE_PIXMAP, IMG_PIXFMT_B5G6R5_UNORM,   false, 0, 0, 0, WSEGL_OPAQUE, 0, false, true },
	{ WSEGL_DRAWABLE_WINDOW | WSEGL_DRAWABLE_PIXMAP, IMG_PIXFMT_B5G5R5A1_UNORM, false, 0, 0, 0, WSEGL_OPAQUE, 0, false, true },
	{ WSEGL_DRAWABLE_WINDOW | WSEGL_DRAWABLE_PIXMAP, IMG_PIXFMT_B8G8R8A8_UNORM, false, 0, 0, 0, WSEGL_OPAQUE, 0, false, true },
	{ WSEGL_DRAWABLE_WINDOW, IMG_PIXFMT_B8G8R8X8_UNORM, false, 0, 0, 0, WSEGL_OPAQUE, 0, false, true },
	{ WSEGL_DRAWABLE_PIXMAP, IMG_PIXFMT_B4G4R4A4_UNORM, false, 0, 0, 0, WSEGL_OPAQUE, 0, false, false },
	{ WSEGL_NO_DRAWABLE, 0, 0, 0, 0, 0, 0, 0 }
};

static struct {
	uint32_t	uiOpenCount;
	DLC_HANDLE	hDevice;
} gsDrmDriver = { 0 , 0 };

static WSEGLError GetDefaultDisplayAppHints(long lDisplay, long *plDispIndex)
{
	void *pvHintState;
	uint32_t uiDefault, uiSetDefaultDisplay;

	PVRSRVCreateAppHintStateExt(0, &pvHintState);
	uiDefault = (uint32_t)WSEGL_DEFAULT_DISPLAY;
	PVRSRVGetAppHintUintExt(pvHintState, NULLDRM_WSEGL_APPHINT_DEFAULT_DISPLAY, &uiDefault, &uiSetDefaultDisplay);
	PVRSRVFreeAppHintStateExt(pvHintState);

	if (uiSetDefaultDisplay >= NULLDRM_NUM_DISPLAYS)
	{
		fprintf(stderr, "[%s=%d] out of range\n", "SetDefaultDisplay", uiSetDefaultDisplay);
		return WSEGL_CANNOT_INITIALISE;
	}

	/* swap display index */
	if (lDisplay == WSEGL_DEFAULT_DISPLAY)
	{
		*plDispIndex = uiSetDefaultDisplay;
	}
	else if (lDisplay == uiSetDefaultDisplay)
	{
		*plDispIndex = WSEGL_DEFAULT_DISPLAY;
	}
	else
	{
		*plDispIndex = lDisplay - WSEGL_DEFAULT_DISPLAY;
	}

	return WSEGL_SUCCESS;
}


static WSEGLError GetAppHints(NULLDRM_WSEGL_DISPLAY *psDisplay, NULLDRM_WSEGL_DRAWABLE *psDrawable)
{
	void *pvHintState;
	char szHintName[32];
	char szLayerHint[256];
	uint32_t uiDefault;
	uint32_t uiUsePrimarySurface;
	uint32_t uiWidth, uiHeight, uiXOffset, uiYOffset;
	int32_t iParams;

	/* Get Primary Surface Hint */
	PVRSRVCreateAppHintStateExt(0, &pvHintState);
	uiDefault = 0xFFFFFFFF;
	PVRSRVGetAppHintUintExt(pvHintState, NULLDRM_WSEGL_APPHINT_USE_DESKTOP, &uiDefault, &uiUsePrimarySurface);
	if (uiDefault == uiUsePrimarySurface)
	{
		uiDefault = 1;
		PVRSRVGetAppHintUintExt(pvHintState, NULLDRM_WSEGL_APPHINT_PRIMARY_SURFACE, &uiDefault, &uiUsePrimarySurface);
	}
	PVRSRVFreeAppHintStateExt(pvHintState);

	if (!uiUsePrimarySurface && (psDrawable->iPlaneIndex < 0))
	{
		psDrawable->iPlaneIndex = 0;
	}

	if (psDrawable->iPlaneIndex < 0)
	{
		/* Get primary plane Hint */
		PVRSRVCreateAppHintStateExt(0, &pvHintState);

		uiDefault = psDisplay->sDims.uiWidth;
		PVRSRVGetAppHintUintExt(pvHintState,
					NULLDRM_WSEGL_APPHINT_DISPLAY_WIDTH,
					&uiDefault,
					&(psDrawable->sPlaneRect.sDims.uiWidth));

		uiDefault = psDisplay->sDims.uiHeight;
		PVRSRVGetAppHintUintExt(pvHintState,
					NULLDRM_WSEGL_APPHINT_DISPLAY_HEIGHT,
					&uiDefault,
					&(psDrawable->sPlaneRect.sDims.uiHeight));

		PVRSRVFreeAppHintStateExt(pvHintState);

		psDrawable->sPlaneRect.iXOffset = 0;
		psDrawable->sPlaneRect.iYOffset = 0;
	}
	else
	{
		/* Get plane Hint */
		PVRSRVCreateAppHintStateExt(0, &pvHintState);
		sprintf(szHintName, "DisplayLayer:%d:%d", psDisplay->iConnIndex, psDrawable->iPlaneIndex);
		PVRSRVGetAppHintStringExt(pvHintState, szHintName, "", szLayerHint);
		PVRSRVFreeAppHintStateExt(pvHintState);

		/* Check the layer hint */
		if (szLayerHint[0] == '\0')
		{
			fprintf(stderr, "[%s] not found in powervr.ini\n", szHintName);
			return WSEGL_BAD_NATIVE_WINDOW;
		}

		/* Get plane settings */
		iParams = sscanf(szLayerHint, "%dx%d:%d,%d", &uiWidth, &uiHeight, &uiXOffset, &uiYOffset);
		if (iParams != 4)
		{
			fprintf(stderr, "%s: [%s=%s] is invalid (powervr.ini)\n", __func__, szHintName, szLayerHint);
			return WSEGL_BAD_NATIVE_WINDOW;
		}

		psDrawable->sPlaneRect.sDims.uiWidth  = uiWidth;
		psDrawable->sPlaneRect.sDims.uiHeight = uiHeight;
		psDrawable->sPlaneRect.iXOffset = uiXOffset;
		psDrawable->sPlaneRect.iYOffset = uiYOffset;
	}

	return WSEGL_SUCCESS;
}

static uint32_t IMGPixFmtGetBPP(IMG_PIXFMT ePixelFormat)
{
	switch (ePixelFormat)
	{
	case IMG_PIXFMT_B5G6R5_UNORM:
	case IMG_PIXFMT_B5G5R5A1_UNORM:
	case IMG_PIXFMT_B4G4R4A4_UNORM:
		return 16;
	case IMG_PIXFMT_B8G8R8A8_UNORM:
	case IMG_PIXFMT_B8G8R8X8_UNORM: // fall through
	default:
		return 32;
	}
}


static DLC_FORMAT IMGPixFmtToDLCPixFmt(IMG_PIXFMT ePixelFormat)
{
	switch (ePixelFormat)
	{
	case IMG_PIXFMT_B5G6R5_UNORM:
		return DLC_FORMAT_RGB565;
	case IMG_PIXFMT_B5G5R5A1_UNORM:
		return DLC_FORMAT_ARGB1555;
	case IMG_PIXFMT_B8G8R8A8_UNORM:
		return DLC_FORMAT_ARGB8888;
	case IMG_PIXFMT_B4G4R4A4_UNORM:
		return DLC_FORMAT_ARGB4444;
	case IMG_PIXFMT_B8G8R8X8_UNORM: // fall through
		return DLC_FORMAT_XRGB8888;
	default:
		return ePixelFormat;
	}
}

static IMG_PIXFMT DLCPixFmtToIMGPixFmt(DLC_FORMAT ePixelFormat)
{
	switch (ePixelFormat)
	{
	case DLC_FORMAT_RGB565:
		return IMG_PIXFMT_B5G6R5_UNORM;
	case DLC_FORMAT_ARGB1555:
		return IMG_PIXFMT_B5G5R5A1_UNORM;
	case DLC_FORMAT_ARGB8888:
		return IMG_PIXFMT_B8G8R8A8_UNORM;
	case DLC_FORMAT_ARGB4444:
		return IMG_PIXFMT_B4G4R4A4_UNORM;
	case DLC_FORMAT_XRGB8888: // fall through
		return IMG_PIXFMT_B8G8R8X8_UNORM;
	default:
		return ePixelFormat;
	}
}

static DLC_MEMLAYOUT FBMemLayoutToDLCLayout(IMG_MEMLAYOUT eMemLayout)
{
	switch (eMemLayout)
	{
	case IMG_MEMLAYOUT_STRIDED:
		return DLC_MEMLAYOUT_STRIDED;
	case IMG_MEMLAYOUT_TWIDDLED:
		return DLC_MEMLAYOUT_TWIDDLED;
	case IMG_MEMLAYOUT_3DTWIDDLED:
		return DLC_MEMLAYOUT_3DTWIDDLED;
	case IMG_MEMLAYOUT_TILED:
		return DLC_MEMLAYOUT_TILED;
	case IMG_MEMLAYOUT_PAGETILED:
		return DLC_MEMLAYOUT_PAGETILED;
	default:
//		assert(!"unsupported fb memory layout");
		return DLC_MEMLAYOUT_STRIDED;
	}
}

static IMG_MEMLAYOUT DLCMemLayoutToFBLayout(DLC_MEMLAYOUT eMemLayout)
{
	switch (eMemLayout)
	{
	case DLC_MEMLAYOUT_STRIDED:
		return IMG_MEMLAYOUT_STRIDED;
	case DLC_MEMLAYOUT_TWIDDLED:
		return IMG_MEMLAYOUT_TWIDDLED;
	case DLC_MEMLAYOUT_3DTWIDDLED:
		return IMG_MEMLAYOUT_3DTWIDDLED;
	case DLC_MEMLAYOUT_TILED:
		return IMG_MEMLAYOUT_TILED;
	case DLC_MEMLAYOUT_PAGETILED:
		return IMG_MEMLAYOUT_PAGETILED;
	default:
		return IMG_MEMLAYOUT_STRIDED;
	}
}

static DLC_COMPRESSION FBCompressionToDLCFbc(IMG_FB_COMPRESSION eCompression)
{
	switch (eCompression)
	{
	case IMG_FB_COMPRESSION_NONE:
		return DLC_COMPRESSION_NONE;
	case IMG_FB_COMPRESSION_DIRECT_8x8:
		return DLC_COMPRESSION_DIRECT_8x8;
	case IMG_FB_COMPRESSION_DIRECT_16x4:
		return DLC_COMPRESSION_DIRECT_16x4;
	case IMG_FB_COMPRESSION_DIRECT_32x2:
		return DLC_COMPRESSION_DIRECT_32x2;
	default:
//		assert(!"unsupported framebuffer compression");
		return DLC_COMPRESSION_NONE;
	}
}

static IMG_FB_COMPRESSION DLCCompressionToFBFbc(DLC_COMPRESSION eCompression)
{
	switch (eCompression)
	{
	case DLC_COMPRESSION_NONE:
		return IMG_FB_COMPRESSION_NONE;
	case DLC_COMPRESSION_DIRECT_8x8:
		return IMG_FB_COMPRESSION_DIRECT_8x8;
	case DLC_COMPRESSION_DIRECT_16x4:
		return IMG_FB_COMPRESSION_DIRECT_16x4;
	case DLC_COMPRESSION_DIRECT_32x2:
		return IMG_FB_COMPRESSION_DIRECT_32x2;
	default:
		return IMG_FB_COMPRESSION_NONE;
	}
}

static NULLDRM_WSEGL_BUFFER *GetDisplayBuffer(NULLDRM_WSEGL_DRAWABLE *psDrawable)
{
	if (psDrawable->uiCurrentBuffer)
	{
		return psDrawable->apsBuffers[psDrawable->uiCurrentBuffer - 1];
	}
	else
	{
		return psDrawable->apsBuffers[psDrawable->uiNumBuffers - 1];
	}
}

static NULLDRM_WSEGL_BUFFER *GetRenderBuffer(NULLDRM_WSEGL_DRAWABLE *psDrawable)
{
	return psDrawable->apsBuffers[psDrawable->uiCurrentBuffer];
}

static void NextFrameBuffer(NULLDRM_WSEGL_DRAWABLE *psDrawable)
{
	psDrawable->uiCurrentBuffer = (psDrawable->uiCurrentBuffer + 1) % psDrawable->uiNumBuffers;
}

static void *FlipThread(void *arg)
{
	NULLDRM_WSEGL_DRAWABLE *psDrawable = (NULLDRM_WSEGL_DRAWABLE *)arg;
	NULLDRM_WSEGL_BUFFER *psRemoveBuffer;
	uint32_t uiNextBuffer;
	bool   bBufferFull = false;

#if defined(SUPPORT_WSEGL_LOGGING)
	{
		hScopeFlip = DLCScope_Acquire("nullws_drm", "Thread", 1, SCOPE_FALSE);
		DLCScope_StartContext(hScopeFlip);
	}
#endif /* SUPPORT_WSEGL_LOGGING */

	while (!psDrawable->bThreadEnd)
	{
		sem_wait(&psDrawable->hThreadSemWakeup);
		if (psDrawable->bThreadEnd)
		{
			break;
		}

		if (!psDrawable->bFrameStarted)
		{
			psDrawable->uiRemoveBuffer = psDrawable->uiRemoveBuffer > 0
										 ? psDrawable->uiRemoveBuffer - 1
										 : psDrawable->uiNumBuffers - 1;
		}

		uiNextBuffer = (psDrawable->uiRemoveBuffer + 1) % psDrawable->uiNumBuffers;
		if ((psDrawable->uiSwapInterval) > 1 && (psDrawable->apsBuffers[uiNextBuffer]->bFBInUse))
		{
			bBufferFull = true;
		}
		else
		{
			bBufferFull = false;
			sem_post(&psDrawable->hThreadSemComplete);
		}

		psRemoveBuffer = psDrawable->apsBuffers[psDrawable->uiRemoveBuffer];

#if defined(WAIT_FENCE_CLIENT)
		if (psRemoveBuffer->hReadFence != PVRSRV_NO_FENCE)
		{
                        PVRSRVFenceWaitExt(gsWSInfo.psDevConnection, psRemoveBuffer->hReadFence, 10000, NULL);
		}
#endif

#if defined(SUPPORT_WSEGL_LOGGING)
		DLCScope_UpdateFrame(hScopeFlip);
		DLCScope_TimingBegin(hScopeFlip, "Flip Call", 0, 0);
#endif /* SUPPORT_WSEGL_LOGGING */
		if (psDrawable->iPlaneIndex >= 0)
		{
			/* Overlay plane */
			DLC_SetPlane(gsDrmDriver.hDevice,
				     psDrawable->hDrmPlane,
				     psRemoveBuffer->hDLCHandle,
				     psDrawable->sPlaneRect.iXOffset,
				     psDrawable->sPlaneRect.iYOffset,
				     psDrawable->sPlaneRect.sDims.uiWidth,
				     psDrawable->sPlaneRect.sDims.uiHeight,
				     0, 0,
				     psDrawable->uiSwapInterval);
		}
		else
		{
			/* Primary Plane */
			DLC_PageFlip(gsDrmDriver.hDevice,
				     psDrawable->hDrmCrtc,
				     psRemoveBuffer->hDLCHandle,
				     psDrawable->uiSwapInterval);
		}
#if defined(SUPPORT_WSEGL_LOGGING)
		DLCScope_TimingEnd(hScopeFlip);
#endif /* SUPPORT_WSEGL_LOGGING */

		if (bBufferFull)
		{
			sem_post(&psDrawable->hThreadSemComplete);
		}
		if (psDrawable->uiSwapInterval > 1)
		{
			psRemoveBuffer->bFBInUse = true;
		}

		psDrawable->uiRemoveBuffer = uiNextBuffer;
	}

	return NULL;
}

static bool IMGPixFmtIsRELYUVFmt(IMG_PIXFMT eIMGPixFmt)
{
	switch (eIMGPixFmt)
	{
		/* [RELCOMMENT STD-0052:P-0149] Check if supported YUV formats. */
		case IMG_PIXFMT_UYVY:
		case IMG_PIXFMT_YUYV:
		case IMG_PIXFMT_VYUY:
		case IMG_PIXFMT_YVYU:
		case IMG_PIXFMT_YUV420_2PLANE:
		case IMG_PIXFMT_YVU420_2PLANE:
		case IMG_PIXFMT_YUV8_422_2PLANE_PACK8:
		case IMG_PIXFMT_YUV420_3PLANE:
		case IMG_PIXFMT_YVU420_3PLANE:
			return true;
		default:
			return false;
	}
}

static bool GetYUVPlaneTexelStrideFromByteStride(IMG_PIXFMT eIMGPixFmt,
												  uint32_t ui32StrideInBytes,
												  uint32_t *ui32YPlaneStrideInTexels)
{
	uint32_t ui32PlaneBytes;

	switch (eIMGPixFmt)
	{
		/* [RELCOMMENT STD-0052:P-0149] Define Plane Bytes for supported YUV formats. */
		case IMG_PIXFMT_UYVY:
		case IMG_PIXFMT_VYUY:
		case IMG_PIXFMT_YUYV:
		case IMG_PIXFMT_YVYU:
		case IMG_PIXFMT_YUV8_422_2PLANE_PACK8:
			ui32PlaneBytes = 2;
			break;
		case IMG_PIXFMT_YUV420_2PLANE:
		case IMG_PIXFMT_YVU420_2PLANE:
		case IMG_PIXFMT_YUV420_3PLANE:
		case IMG_PIXFMT_YVU420_3PLANE:
			ui32PlaneBytes = 1;
			break;
		default:
			/* Unsupported YUV format */
			return false;
	}

	if (ui32StrideInBytes % ui32PlaneBytes)
	{
		/* The stride of YUV is not properly aligned. */
		return false;
	}

	*ui32YPlaneStrideInTexels = ui32StrideInBytes / ui32PlaneBytes;

	return true;
}

static bool GetPlaneSizeInBytes(IMG_PIXFMT eIMGPixFmt, uint32_t *aui32PlaneSizeInBytes, uint32_t ui32StrideInBytes, int i32Height)
{
	switch (eIMGPixFmt)
	{
		/* [RELCOMMENT STD-0052:P-0149] Check if supported YUV formats.
			Only support with format have Memlayout is IMG_MEMLAYOUT_STRIDED*/
		case IMG_PIXFMT_YUV420_2PLANE:
		case IMG_PIXFMT_YVU420_2PLANE:
			aui32PlaneSizeInBytes[0] = ui32StrideInBytes * i32Height;
			return true;
		case IMG_PIXFMT_YUV8_422_2PLANE_PACK8:
			aui32PlaneSizeInBytes[0] = (ui32StrideInBytes >> 1) * i32Height;
			return true;
		case IMG_PIXFMT_YUV420_3PLANE:
		case IMG_PIXFMT_YVU420_3PLANE:
			aui32PlaneSizeInBytes[0] = ui32StrideInBytes * i32Height;
			aui32PlaneSizeInBytes[1] = (ui32StrideInBytes >> 1 ) * (i32Height >> 1);
			return true;
		default:
			return false;
	}
}

#if defined(DEBUG)
static void CheckBufferAttribs(NULLDRM_WSEGL_BUFFER *psBuffer, uint32_t uiDrawableType)
{
#if 0
//	DLC_BUFFER_ATTRIBUTES sAttribs;
//	DLC_GetBufferAttributes(psBuffer->hDLCHandle, &sAttribs);

	PVR_DPF((PVR_DBG_MESSAGE, "--------------------------------------------------"));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->Attribs.uiHandle     = %u",       psBuffer->sAttribs.uiHandle));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->Attribs.uiWidth      = %u",       psBuffer->sAttribs.uiWidth));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->Attribs.uiHeight     = %u",       psBuffer->sAttribs.uiHeight));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->Attribs.uiMemSize    = %#x",      psBuffer->sAttribs.uiMemSize));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->Attribs.uiStride     = %#x",      psBuffer->sAttribs.uiStride));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->Attribs.ePixelFormat = %d",       psBuffer->sAttribs.ePixelFormat));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->Attribs.eMemLayout   = %d",       psBuffer->sAttribs.eMemLayout));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->Attribs.eCompression = %d",       psBuffer->sAttribs.eCompression));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->Attribs.pCpuVirtAddr = %p",       psBuffer->sAttribs.pvCpuVirtAddr));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->sDevVirtAddr         = %#"PRIx64, psBuffer->sDevVirtAddr.uiAddr));
	PVR_DPF((PVR_DBG_MESSAGE, "Buffer->hMemDesc             = %p",       psBuffer->hMemDesc));

	if (uiDrawableType == WSEGL_DRAWABLE_WINDOW)
	{
		PVR_DPF((PVR_DBG_MESSAGE, "Buffer->hDLCHandle           = %p", psBuffer->hDLCHandle));
		PVR_DPF((PVR_DBG_MESSAGE, "Buffer->bFBInUse             = %d", psBuffer->bFBInUse));
	}
	else
	{
		PVR_DPF((PVR_DBG_MESSAGE, "Buffer->eYUVColorSpace       = %d", psBuffer->eYUVColorSpace));
		PVR_DPF((PVR_DBG_MESSAGE, "Buffer->eYUVChromaUInterp    = %d", psBuffer->eYUVChromaUInterp));
		PVR_DPF((PVR_DBG_MESSAGE, "Buffer->eYUVChromaVInterp    = %d", psBuffer->eYUVChromaVInterp));
	}
#endif
}
#endif /* DEBUG */

static bool CreateBuffer(NULLDRM_WSEGL_DISPLAY *psDisplay,
				 uint32_t uiDrawableType,
				 uint32_t uiWidth,
				 uint32_t uiHeight,
				 IMG_PIXFMT ePixelFormat,
				 void *pvNativePixmapVAddr,   /* PIXMAP only */
				 uint32_t uiAllocationSize, /* PIXMAP only */
				 uint32_t uiStrideInBytes,  /* PIXMAP only */
				 NULLDRM_WSEGL_BUFFER **ppsBufferOut)
{
	NULLDRM_WSEGL_BUFFER *psBuffer;
	bool bRet = false;

	psBuffer = malloc(sizeof(*psBuffer));
	if (!psBuffer)
	{
		return false;
	}

	if (uiDrawableType == WSEGL_DRAWABLE_WINDOW)
	{
		DLC_STATUS eDLCStat;

		eDLCStat = DLC_AllocateRemoteFB(gsDrmDriver.hDevice,
						uiWidth,
						uiHeight,
						IMGPixFmtGetBPP(ePixelFormat),
						IMGPixFmtToDLCPixFmt(ePixelFormat),
						FBMemLayoutToDLCLayout(psDisplay->eFBMemLayout),
						FBCompressionToDLCFbc(psDisplay->eFBCFormat),
						&psBuffer->hDLCHandle);
		if (eDLCStat == DLC_STS_OK)
		{
			int prime_fd;
			IMG_DEVMEM_SIZE_T uiImportSize;

			DLC_FBPrimeHandleToFD(psBuffer->hDLCHandle, &prime_fd);

			bRet = PVRSRVDmaBufImportDevMemExt(gsWSInfo.psDevConnection,
							  prime_fd,
							  &psBuffer->hMemDesc,
							  &uiImportSize,
							  "nullws_drm");
			close(prime_fd);

			if (bRet)
			{
				DLC_GetBufferAttributes(psBuffer->hDLCHandle, &psBuffer->sAttribs);
			}
			else
			{
				DLC_DestroyRemoteFB(gsDrmDriver.hDevice, psBuffer->hDLCHandle);
			}
		}
		else
		{
			// PVR_DPF((PVR_DBG_ERROR,
			// 	"Failed to add buffer as framebuffer: %d", eDLCStat));
			bRet = false;
		}
	}
	else if (uiDrawableType == WSEGL_DRAWABLE_PIXMAP)
	{
			/* Create hMemDesc from WrapExtMemory */
			bRet = PVRSRVWrapExtMemExt(gsWSInfo.hDevMemContext,
											uiAllocationSize,
											pvNativePixmapVAddr,
											4096,
											"",
											&psBuffer->hMemDesc);

			if (bRet)
			{
					psBuffer->sAttribs.uiWidth       = uiWidth;
					psBuffer->sAttribs.uiHeight      = uiHeight;
					psBuffer->sAttribs.uiStride      = uiStrideInBytes;
					psBuffer->sAttribs.uiMemSize     = uiAllocationSize;
					psBuffer->sAttribs.ePixelFormat  = IMGPixFmtToDLCPixFmt(ePixelFormat);
					psBuffer->sAttribs.eMemLayout    = FBMemLayoutToDLCLayout(psDisplay->eFBMemLayout);
					psBuffer->sAttribs.eCompression  = FBCompressionToDLCFbc(psDisplay->eFBCFormat);
					psBuffer->sAttribs.pvCpuVirtAddr = pvNativePixmapVAddr;
			}

	}
	else
	{
		bRet = false;
	}
	if (!bRet)
	{
		// PVR_DPF((PVR_DBG_ERROR,
		// 	 "Failed to allocate device memory: %s", PVRSRVGetErrorString(eError)));
		free(psBuffer);
		return false;
	}

	/* Map it into Rogue address space */
	bRet = PVRSRVMapToDeviceExt(psBuffer->hMemDesc,
				   gsWSInfo.hHeap,
				   &psBuffer->sDevVirtAddr);
	if (!bRet)
	{
		// PVR_DPF((PVR_DBG_ERROR,
		// 	 "Failed to map buffer to device: %s", PVRSRVGetErrorString(eError)));
		goto error_map_to_device;
	}

#if 0
	eError = PVRSRVAcquireCPUMapping(psBuffer->hMemDesc,
					 &psBuffer->pvCpuVirtAddr);
#endif
	psBuffer->hFence = PVRSRV_NO_FENCE;
	psBuffer->hReadFence = PVRSRV_NO_FENCE;

	psBuffer->bFBInUse = false;
	psBuffer->uiBufferAge = 0;

	*ppsBufferOut = psBuffer;

	return true;


error_map_to_device:
        PVRSRVFreeDeviceMemExtREL(psBuffer->hMemDesc);

	if (uiDrawableType == WSEGL_DRAWABLE_WINDOW)
	{
		DLC_DestroyRemoteFB(gsDrmDriver.hDevice, psBuffer->hDLCHandle);
	}
		else

	{
		// PVR_DPF((PVR_DBG_MESSAGE, "Buffer->eYUVColorSpace       = %d", psBuffer->eYUVColorSpace));
		// PVR_DPF((PVR_DBG_MESSAGE, "Buffer->eYUVChromaUInterp    = %d", psBuffer->eYUVChromaUInterp));
		// PVR_DPF((PVR_DBG_MESSAGE, "Buffer->eYUVChromaVInterp    = %d", psBuffer->eYUVChromaVInterp));
	}

	free(psBuffer);

	return false;
}

static bool DestroyBuffer(NULLDRM_WSEGL_BUFFER *psBuffer, uint32_t uiDrawableType)
{
	if (psBuffer->hFence != PVRSRV_NO_FENCE)
	{
		PVRSRVFenceDestroyExt(gsWSInfo.psDevConnection, psBuffer->hFence);
		psBuffer->hFence = PVRSRV_NO_FENCE;
	}
	if (psBuffer->hReadFence != PVRSRV_NO_FENCE)
	{
		PVRSRVFenceDestroyExt(gsWSInfo.psDevConnection, psBuffer->hReadFence);
		psBuffer->hReadFence = PVRSRV_NO_FENCE;
	}

	PVRSRVReleaseDeviceMappingExt(psBuffer->hMemDesc);
        PVRSRVFreeDeviceMemExtREL(psBuffer->hMemDesc);

	if (uiDrawableType == WSEGL_DRAWABLE_WINDOW)
	{
		DLC_DestroyRemoteFB(gsDrmDriver.hDevice, psBuffer->hDLCHandle);
	}

	free(psBuffer);

	return true;
}

static void* CreateDrawable(NULLDRM_WSEGL_DISPLAY *psDisplay,
			    uint32_t uiDrawableType,
			    int32_t iPlaneIndex)
{
	NULLDRM_WSEGL_DRAWABLE *psDrawable;
	char *pszPresentMode;
	DLC_STATUS eDLCStat;

	psDrawable = malloc(sizeof(NULLDRM_WSEGL_DRAWABLE));
	if (!psDrawable)
	{
		return NULL;
	}
	memset(psDrawable, 0, sizeof(NULLDRM_WSEGL_DRAWABLE));

	psDrawable->uiType          = uiDrawableType;
	psDrawable->psDisplay       = psDisplay;
	psDrawable->uiSwapInterval  = 1;
	psDrawable->uiCurrentBuffer = 0;
	psDrawable->iPlaneIndex     = iPlaneIndex;
	psDrawable->bSwapBehaviourPreserve = false;
	psDrawable->bFrameStarted   = false;
	psDrawable->uiDisable_update = 0;

	if (psDrawable->uiType == WSEGL_DRAWABLE_WINDOW)
	{
		/* Get the AppHints */
		if (GetAppHints(psDisplay, psDrawable) != WSEGL_SUCCESS)
		{
			goto error;
		}

		pszPresentMode = getenv("NULLWS_PRESENT_MODE");
		if (pszPresentMode && strcmp(pszPresentMode, "front") == 0)
		{
			psDrawable->ePresentMode = NULLDRM_WSEGL_PRESENTMODE_FRONT;
			psDrawable->uiNumBuffers = 1;
		}
#if 0 /* Default PresentMode is FLIP */
		else if (pszPresentMode && strcmp(pszPresentMode, "blit") == 0)
		{
			PVR_DPF((PVR_DBG_ERROR, "Blit mode is not supported"));
			goto error;
		}
#endif
		else
		{
			psDrawable->ePresentMode = NULLDRM_WSEGL_PRESENTMODE_FLIP;
			psDrawable->uiNumBuffers = ARRAY_SIZE(psDrawable->apsBuffers);
			pszPresentMode = "flip";
		}

		if (psDrawable->iPlaneIndex >= 0)
		{
			/* Reserve a free OVERLAY plane */
			eDLCStat = DLC_AcquirePlane(gsDrmDriver.hDevice,
							psDisplay->hDrmCrtc,
							psDrawable->uiNumBuffers,
							&psDrawable->hDrmPlane);
			if (eDLCStat != DLC_STS_OK)
			{
				goto error;
			}
		}
		else
		{
			/* Reserve a Desktop plane */
			eDLCStat = DLC_AcquireDesktop(gsDrmDriver.hDevice,
							psDisplay->hDrmCrtc,
							psDrawable->uiNumBuffers);
			if (eDLCStat != DLC_STS_OK)
			{
				goto error;
			}

			psDrawable->hDrmCrtc = psDisplay->hDrmCrtc;
		}

	}
	else if (psDrawable->uiType == WSEGL_DRAWABLE_PIXMAP)
	{
		psDrawable->uiNumBuffers = 1;
	}
	else
	{
		goto error;
	}

	return psDrawable;

error:
	free(psDrawable);
	return NULL;
}

static bool DestroyDrawable(NULLDRM_WSEGL_DRAWABLE *psDrawable)
{
	if (psDrawable->uiType == WSEGL_DRAWABLE_WINDOW)
	{
		if (psDrawable->iPlaneIndex >= 0)
		{
			DLC_ReleasePlane(gsDrmDriver.hDevice, psDrawable->hDrmPlane);
		}
		else
		{
			DLC_ReleaseDesktop(gsDrmDriver.hDevice, psDrawable->hDrmCrtc);
		}
	}

	free(psDrawable);

#if defined(SUPPORT_WSEGL_LOGGING)
	if (hScopeMain) DLCScope_Release(hScopeMain);
	if (hScopeFlip) DLCScope_Release(hScopeFlip);
#endif /* SUPPORT_WSEGL_LOGGING */

	return true;
}

static WSEGLError AcquireServicesData(void)
{
	if (!bConnectedToServices)
	{
		if (!PVRSRVConnectExt(&gsWSInfo.psDevConnection))
		{
			// PVR_DPF((PVR_DBG_ERROR,
			// 	 "Failed to open connection: %s", PVRSRVGetErrorString(eError)));
			goto error_exit;
		}

		if (!PVRSRVCreateDeviceMemContextExt(gsWSInfo.psDevConnection, &gsWSInfo.hRGXDevMemContext, &gsWSInfo.hDevMemContext))
 		{
			// PVR_DPF((PVR_DBG_ERROR,
			// 	 "Failed to create context for device memory: %s", PVRSRVGetErrorString(eError)));
			goto error_disconnect;
		}

		if (!PVRSRVFindHeapExt(gsWSInfo.hDevMemContext, &gsWSInfo.hHeap))
 		{
			// PVR_DPF((PVR_DBG_ERROR,
			// 	 "Failed to find general heap handle: %s", PVRSRVGetErrorString(eError)));
			goto error_destroy_mem_context;
		}

		if(!PVRSRVAcquireGlobalEventHandleExt(gsWSInfo.psDevConnection, &gsWSInfo.hEventObject))
 		{
			// PVR_DPF((PVR_DBG_ERROR,
			// 	 "Failed to acquire event handle: %s", PVRSRVGetErrorString(eError)));
			goto error_destroy_mem_context;
		}

		bConnectedToServices = true;
	}

	return WSEGL_SUCCESS;

error_destroy_mem_context:
	PVRSRVReleaseDeviceMemContextExt(gsWSInfo.hRGXDevMemContext, gsWSInfo.hDevMemContext);

error_disconnect:
	PVRSRVDisconnectExt(gsWSInfo.psDevConnection);

error_exit:
	return WSEGL_CANNOT_INITIALISE;
}

static WSEGLError ReleaseServicesData(void)
{
	if (bConnectedToServices)
	{
		PVRSRVReleaseGlobalEventHandleExt(gsWSInfo.psDevConnection, gsWSInfo.hEventObject);

		PVRSRVReleaseDeviceMemContextExt(gsWSInfo.hRGXDevMemContext, gsWSInfo.hDevMemContext);

		PVRSRVDisconnectExt(gsWSInfo.psDevConnection);

		gsWSInfo.psDevConnection = NULL;

		bConnectedToServices = false;
	}

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_IsDisplayValid
 Inputs             : hNativeDisplay
 Outputs            : None
 Returns            : Error code
 Description        : Validates a native display
************************************************************************************/
static WSEGLError WSEGL_IsDisplayValid(NativeDisplayType hNativeDisplay)
{
	DLC_HANDLE hDevice;
	DLC_STATUS eDLCStat;
	int32_t iNumDisplays;

	eDLCStat = DLC_Init(&hDevice, DLC_FALSE);
	if (eDLCStat != DLC_STS_OK)
	{
		return WSEGL_BAD_NATIVE_DISPLAY;
	}
	eDLCStat = DLC_GetConnectorCount(hDevice, &iNumDisplays);
	if (eDLCStat != DLC_STS_OK)
	{
		DLC_Exit(hDevice);
		return WSEGL_BAD_NATIVE_DISPLAY;
	}

	DLC_Exit(hDevice);

	if (iNumDisplays > NULLDRM_NUM_DISPLAYS)
	{
		iNumDisplays = NULLDRM_NUM_DISPLAYS;
	}

	if (((long)hNativeDisplay >= (long)WSEGL_DEFAULT_DISPLAY) &&
				((long)hNativeDisplay < (long)iNumDisplays))
	{
		return WSEGL_SUCCESS;
	}

	return WSEGL_BAD_NATIVE_DISPLAY;
}


/***********************************************************************************
 Function Name      : WSEGL_InitialiseDisplay
 Inputs             : hNativeDisplay
 Outputs            : phDisplay, ppsCapabilities, ppsConfigs, ppsDevConnection
 Returns            : Error code
 Description        : Initialises a display
************************************************************************************/
static WSEGLError WSEGL_InitialiseDisplay(NativeDisplayType hNativeDisplay,
					  WSEGLDisplayHandle *phDisplay,
					  const WSEGLCaps **ppsCapabilities,
					  WSEGLConfig **ppsConfigs,
					  PVRSRV_DEV_CONNECTION **ppsDevConnection)
{
	NULLDRM_WSEGL_DISPLAY *psDisplay;
	long lDispIndex = (long)hNativeDisplay;
	WSEGLError eWSEGLError;
	DLC_STATUS eDLCStat;

	eWSEGLError = GetDefaultDisplayAppHints((long)hNativeDisplay, &lDispIndex);
	if (eWSEGLError != WSEGL_SUCCESS)
	{
		goto exit_wsegl;
	}

	if (gasDisplay[lDispIndex].uiRefCount > 0)
	{
		gasDisplay[lDispIndex].uiRefCount++;

		*phDisplay        = (WSEGLDisplayHandle)&gasDisplay[lDispIndex];
		*ppsCapabilities  = gasCaps;
		*ppsConfigs       = gasConfigs;
		*ppsDevConnection = gsWSInfo.psDevConnection;

		return WSEGL_SUCCESS;
	}

	psDisplay = &gasDisplay[lDispIndex];
	psDisplay->iConnIndex = (int)lDispIndex;

	if (gsDrmDriver.uiOpenCount == 0)
	{
		eDLCStat = DLC_Init(&gsDrmDriver.hDevice, DLC_TRUE);
		if (eDLCStat != DLC_STS_OK)
		{
			goto exit_drm;
		}
	}
	gsDrmDriver.uiOpenCount++;

	psDisplay->uiRefCount = 1;

	eWSEGLError = AcquireServicesData();
	if (eWSEGLError != WSEGL_SUCCESS)
	{
		goto exit_service;
	}

	/* Get the index for output connector */
	eDLCStat = DLC_GetConnector(gsDrmDriver.hDevice, psDisplay->iConnIndex, &psDisplay->hDrmConn);
	if (eDLCStat != DLC_STS_OK)
	{
		goto exit_get_connector;
	}

	/* Search the connector and encoder paire */
	eDLCStat = DLC_GetEncoderFromConnector(gsDrmDriver.hDevice, psDisplay->hDrmConn, &psDisplay->hDrmEnc);
	if (eDLCStat != DLC_STS_OK)
	{
		goto exit_get_encoder;
	}

	eDLCStat = DLC_GetCrtcFromEncoder(gsDrmDriver.hDevice, psDisplay->hDrmEnc, &psDisplay->hDrmCrtc);
	if (eDLCStat != DLC_STS_OK)
	{
		goto exit_get_crtc;
	}

	eDLCStat = DLC_QueryCrtcMode(gsDrmDriver.hDevice, psDisplay->hDrmCrtc,
					&psDisplay->sDims.uiWidth,
					&psDisplay->sDims.uiHeight);
	if (eDLCStat != DLC_STS_OK)
	{
		goto exit_mode_misc;
	}

	/* Set up some defaults */
	psDisplay->eFBCFormat   = IMG_FB_COMPRESSION_NONE;
	psDisplay->eFBMemLayout = IMG_MEMLAYOUT_STRIDED;

	*phDisplay = psDisplay;
	*ppsCapabilities = gasCaps;
	*ppsConfigs = gasConfigs;
	*ppsDevConnection = gsWSInfo.psDevConnection;

	return WSEGL_SUCCESS;


exit_mode_misc:
	DLC_FreeCrtc(psDisplay->hDrmCrtc);

exit_get_crtc:
	DLC_FreeEncoder(psDisplay->hDrmEnc);

exit_get_encoder:
	DLC_FreeConnector(psDisplay->hDrmConn);

exit_get_connector:
	ReleaseServicesData();

exit_service:
	gsDrmDriver.uiOpenCount--;
	if (gsDrmDriver.uiOpenCount == 0)
	{
		DLC_Exit(gsDrmDriver.hDevice);
		gsDrmDriver.hDevice = 0;
	}
	psDisplay->uiRefCount = 0;

exit_drm:
exit_wsegl:
	eWSEGLError = WSEGL_CANNOT_INITIALISE;
	return eWSEGLError;
}

/***********************************************************************************
 Function Name      : WSEGL_CloseDisplay
 Inputs             : hDisplay
 Outputs            : None
 Returns            : Error code
 Description        : Closes a display
************************************************************************************/
static WSEGLError WSEGL_CloseDisplay(WSEGLDisplayHandle hDisplay)
{
	NULLDRM_WSEGL_DISPLAY *psDisplay = (NULLDRM_WSEGL_DISPLAY *)hDisplay;

	/* Only close displays with a ref count of 0 */
	psDisplay->uiRefCount--;

	if (psDisplay->uiRefCount)
	{
		return WSEGL_SUCCESS;
	}

	DLC_FreeCrtc(psDisplay->hDrmCrtc);
	DLC_FreeEncoder(psDisplay->hDrmEnc);
	DLC_FreeConnector(psDisplay->hDrmConn);

	gsDrmDriver.uiOpenCount--;
	if (gsDrmDriver.uiOpenCount == 0)
	{
		/* Destroy the DRM resources */
		DLC_Exit(gsDrmDriver.hDevice);
		gsDrmDriver.hDevice = 0;
		ReleaseServicesData();
	}

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_CreateWindowDrawable
 Inputs             : hDisplay, psConfig, hNativeWindow
 Outputs            : phDrawable, peRotationAngle
 Returns            : Error code
 Description        : Create a window drawable for a native window
************************************************************************************/
static WSEGLError WSEGL_CreateWindowDrawable(WSEGLDisplayHandle hDisplay,
					     WSEGLConfig *psConfig,
					     WSEGLDrawableHandle *phDrawable,
					     NativeWindowType hNativeWindow,
					     IMG_ROTATION *peRotationAngle,
					     IMG_COLOURSPACE_FORMAT eColorSpace,
						 bool bIsProtected)
{
	NULLDRM_WSEGL_DISPLAY *psDisplay = (NULLDRM_WSEGL_DISPLAY *)hDisplay;
	NULLDRM_WSEGL_DRAWABLE *psDrawable;

	NULLDRM_WSEGL_BUFFER *psCurrentBuffer;
	uint32_t uiBufferNum;
	int32_t iPlaneIndex;

	WSEGL_UNREFERENCED_PARAMETER(eColorSpace);
	WSEGL_UNREFERENCED_PARAMETER(bIsProtected);

	if (hNativeWindow == 0)
	{
		iPlaneIndex = -1;
	}
	else
	{
		iPlaneIndex = *((int32_t *)hNativeWindow);
		if (iPlaneIndex < 0)
		{
			return WSEGL_BAD_NATIVE_WINDOW;
		}
	}

	psDrawable = CreateDrawable(psDisplay, WSEGL_DRAWABLE_WINDOW, iPlaneIndex);
	if (!psDrawable)
	{
		return WSEGL_OUT_OF_MEMORY;
	}

	switch (psDrawable->ePresentMode)
	{
		case NULLDRM_WSEGL_PRESENTMODE_FLIP:
			// PVR_DPF((PVR_DBG_MESSAGE, "Window created (present mode: flip)"));

			/* Allocate buffers, map them etc. If we fail just let resman cleanup*/
			for (uiBufferNum = 0; uiBufferNum < psDrawable->uiNumBuffers; uiBufferNum++)
			{
				if (!CreateBuffer(psDisplay,
						 psDrawable->uiType,
						 psDrawable->sPlaneRect.sDims.uiWidth,
						 psDrawable->sPlaneRect.sDims.uiHeight,
						 psConfig->ePixelFormat,
						 NULL,
						 0,
						 0,
						 &psDrawable->apsBuffers[uiBufferNum]))
				{
					goto error_destroy_buffers;
				}

				psCurrentBuffer = psDrawable->apsBuffers[uiBufferNum];

#if defined(DEBUG)
				CheckBufferAttribs(psCurrentBuffer, psDrawable->uiType);
#endif /* DEBUG */
			}

			sem_init(&psDrawable->hThreadSemWakeup, 0, 0);
			sem_init(&psDrawable->hThreadSemComplete, 0, 0);

			psDrawable->bThreadEnd = false;
			pthread_create(&psDrawable->hThread, NULL, FlipThread, psDrawable);
			break;

error_destroy_buffers:
			while (uiBufferNum--)
			{
				psCurrentBuffer = psDrawable->apsBuffers[uiBufferNum];
				(void)DestroyBuffer(psCurrentBuffer, psDrawable->uiType);
			}

			psDrawable->ePresentMode = NULLDRM_WSEGL_PRESENTMODE_FRONT;
			psDrawable->uiNumBuffers = 1;
			/* fall through */

		default:
		case NULLDRM_WSEGL_PRESENTMODE_FRONT:
			// PVR_DPF((PVR_DBG_MESSAGE, "Window created (present mode: front)"));

			if (!CreateBuffer(psDisplay,
					 psDrawable->uiType,
					 psDrawable->sPlaneRect.sDims.uiWidth,
					 psDrawable->sPlaneRect.sDims.uiHeight,
					 psConfig->ePixelFormat,
					 NULL,
					 0,
					 0,
					 &psDrawable->apsBuffers[0]))
			{
				goto error;
			}

			psCurrentBuffer = psDrawable->apsBuffers[0];

			if (psDrawable->iPlaneIndex >= 0)
			{
				/* Show the Overlay plane */
				DLC_SetPlane(gsDrmDriver.hDevice,
						psDrawable->hDrmPlane,
						psCurrentBuffer->hDLCHandle,
						psDrawable->sPlaneRect.iXOffset,
						psDrawable->sPlaneRect.iYOffset,
						psCurrentBuffer->sAttribs.uiWidth,
						psCurrentBuffer->sAttribs.uiHeight,
						0, 0,
						0);
			}

#if defined(DEBUG)
			CheckBufferAttribs(psCurrentBuffer, psDrawable->uiType);
#endif /* DEBUG */
			break;
	}

	/* Set Display mode */
	if (psDrawable->iPlaneIndex < 0)
	{
		psCurrentBuffer = psDrawable->apsBuffers[0];

		DLC_SetCrtcMode(gsDrmDriver.hDevice,
				psDrawable->hDrmCrtc,
				psCurrentBuffer->hDLCHandle,
				psCurrentBuffer->sAttribs.uiWidth,
				psCurrentBuffer->sAttribs.uiHeight,
				0, 0);
	}

#if defined(SUPPORT_WSEGL_LOGGING)
	{
		hScopeMain = DLCScope_Acquire("nullws_drm", "Thread", 0, SCOPE_FALSE);
		DLCScope_StartContext(hScopeMain);
	}
#endif /* SUPPORT_WSEGL_LOGGING */

	*phDrawable = psDrawable;
	*peRotationAngle = IMG_ROTATION_0DEG;
	return WSEGL_SUCCESS;

error:
	free(psDrawable);
	return WSEGL_OUT_OF_MEMORY;
}

/***********************************************************************************
 Function Name      : ValidateNativePixmap
 Inputs             : psNativePixmap
 Outputs            : None
 Returns            : Error code
 Description        : Validates native pixmap parameters
************************************************************************************/
static int ValidateNativePixmap(EGLNativePixmapTypeREL *psNativePixmap)
{
	/* Check psNativePixmap */
	if (psNativePixmap == NULL)
	{
		// PVR_DPF((PVR_DBG_ERROR, "Invalid Paramter: psNativePixmap = NULL"));
		return -1;
	}

	/* Check Width */
	if ((psNativePixmap->width < D_MIN_BUFFER_SIZE) || (psNativePixmap->width > D_MAX_BUFFER_SIZE))
	{
		// PVR_DPF((PVR_DBG_ERROR, "Invalid Paramter: width = %d", psNativePixmap->width));
		return -1;
	}

	/* Check Height */
	if ((psNativePixmap->height < D_MIN_BUFFER_SIZE) || (psNativePixmap->height > D_MAX_BUFFER_SIZE))
	{
		// PVR_DPF((PVR_DBG_ERROR, "Invalid Paramter: height = %d", psNativePixmap->height));
		return -1;
	}

	/* Check Stride(Align & Larger than or Equal to Width) */
	if ((psNativePixmap->stride & (D_STRIDE_GRANULARITY - 1)) || (psNativePixmap->stride < psNativePixmap->width))
	{
		// PVR_DPF((PVR_DBG_ERROR, "Invalid Paramter: stride = %d", psNativePixmap->stride));
		return -1;
	}

	/* Check Pixel Format */
	switch((psNativePixmap->format) & D_MASK_FORMAT)
	{
		case EGL_NATIVE_PIXFORMAT_RGB565_REL:
		case EGL_NATIVE_PIXFORMAT_ARGB1555_REL:
		case EGL_NATIVE_PIXFORMAT_ARGB8888_REL:
		case EGL_NATIVE_PIXFORMAT_ARGB4444_REL:
		/* [RELCOMMENT STD-0052:P-0149] Add Validate for NativePixmap.*/
		case EGL_NATIVE_PIXFORMAT_NV12_REL:
		case EGL_NATIVE_PIXFORMAT_NV16_REL:
#if defined(D_MASK_YUV_CHROMA_INTERP_U) && defined(D_MASK_YUV_CHROMA_INTERP_V)
		case EGL_NATIVE_PIXFORMAT_YUYV_REL:
		case EGL_NATIVE_PIXFORMAT_UYVY_REL:
		case EGL_NATIVE_PIXFORMAT_VYUY_REL:
		case EGL_NATIVE_PIXFORMAT_YVYU_REL:
		case EGL_NATIVE_PIXFORMAT_NV21_REL:
		case EGL_NATIVE_PIXFORMAT_I420_REL:
		case EGL_NATIVE_PIXFORMAT_YV12_REL:
#endif
			break;
		default:
			// PVR_DPF((PVR_DBG_ERROR, "Invalid Paramter: format = %d", psNativePixmap->format));
			return -1;
			break;
	}

	/* Buffer Address must not be NULL, and must be allocated with PAGE_SIZE (4096 byte) alignment*/
        if( (psNativePixmap->pixelData == NULL) || (((uint64_t)psNativePixmap->pixelData & (4096U - 1U)) != 0) )
	{
		// PVR_DPF((PVR_DBG_ERROR, "Invalid Paramter: pixelData = NULL"));
		return -1;
	}

	return 0;
}

/***********************************************************************************
 Function Name      : NativePixFmtToIMGPixFmt
 Inputs             : psConfig, psNativePixmap
 Outputs            : pePixelFormat, puiBitPerPixel,
                      peColorSpace, peChromaUInterp, peChromaVInterp
 Returns            : Error code
 Description        : Validates native pixmap parameters
************************************************************************************/
static int NativePixFmtToIMGPixFmt(WSEGLConfig *psConfig,
				   EGLNativePixmapTypeREL *psNativePixmap,
				   IMG_PIXFMT *pePixelFormat,
				   uint32_t *puiBitPerPixel,
				   IMG_YUV_COLORSPACE *peYUVColorSpace,
				   IMG_YUV_CHROMA_INTERP *peYUVChromaUInterp,
				   IMG_YUV_CHROMA_INTERP *peYUVChromaVInterp)
{
	bool bYUVformat = false;

	if (psNativePixmap == NULL ||
	    pePixelFormat == NULL || puiBitPerPixel == NULL ||
	    peYUVColorSpace == NULL || peYUVChromaUInterp == NULL || peYUVChromaVInterp == NULL)
	{
		// PVR_DPF((PVR_DBG_ERROR, "Invalid Paramter"));
		return -1;
	}

	/*
	 * Configuration must match that of the native pixmap
	 * We modified parameter check code. "psConfig==NULL" is correct patern. (Redmine:#26262)
	 */
	if(psConfig != NULL)
	{
		switch (psNativePixmap->format & D_MASK_FORMAT)
		{
			/* [RELCOMMENT STD-0052:P-0149] Set IMGPixFmt and bit per pixel. */
			case EGL_NATIVE_PIXFORMAT_RGB565_REL:
				*pePixelFormat  = IMG_PIXFMT_B5G6R5_UNORM;
				*puiBitPerPixel = 16;
				break;
			case EGL_NATIVE_PIXFORMAT_ARGB1555_REL:
				*pePixelFormat  = IMG_PIXFMT_B5G5R5A1_UNORM;
				*puiBitPerPixel = 16;
				break;
			case EGL_NATIVE_PIXFORMAT_ARGB4444_REL:
				*pePixelFormat  = IMG_PIXFMT_B4G4R4A4_UNORM;
				*puiBitPerPixel = 16;
				break;
			case EGL_NATIVE_PIXFORMAT_ARGB8888_REL:
				*pePixelFormat  = IMG_PIXFMT_B8G8R8A8_UNORM;
				*puiBitPerPixel = 32;
				break;
			default:
				// PVR_DPF((PVR_DBG_ERROR, "Unsupport format"));
				return -1;
		}
	/* [RELCOMMENT STD-0052:P-0149] Set IMGPixFmt and bit per pixel from EGLImage. */
	}
	else
	{
		switch (psNativePixmap->format & D_MASK_FORMAT)
		{
			case EGL_NATIVE_PIXFORMAT_RGB565_REL:
				*pePixelFormat  = IMG_PIXFMT_B5G6R5_UNORM;
				*puiBitPerPixel = 16;
				break;
			case EGL_NATIVE_PIXFORMAT_ARGB1555_REL:
				*pePixelFormat  = IMG_PIXFMT_B5G5R5A1_UNORM;
				*puiBitPerPixel = 16;
				break;
			case EGL_NATIVE_PIXFORMAT_ARGB4444_REL:
				*pePixelFormat  = IMG_PIXFMT_B4G4R4A4_UNORM;
				*puiBitPerPixel = 16;
				break;
			case EGL_NATIVE_PIXFORMAT_ARGB8888_REL:
				*pePixelFormat  = IMG_PIXFMT_B8G8R8A8_UNORM;
				*puiBitPerPixel = 32;
				break;
			case EGL_NATIVE_PIXFORMAT_UYVY_REL:
				*pePixelFormat  = IMG_PIXFMT_UYVY;
				*puiBitPerPixel = 16;
				bYUVformat    = true;
				break;
			case EGL_NATIVE_PIXFORMAT_NV12_REL:
				*pePixelFormat  = IMG_PIXFMT_YUV420_2PLANE;
				*puiBitPerPixel = 12;
				bYUVformat    = true;
				break;
			case EGL_NATIVE_PIXFORMAT_NV16_REL:
				*pePixelFormat  = IMG_PIXFMT_YUV8_422_2PLANE_PACK8;
				*puiBitPerPixel = 16;
				break;
#if defined(D_MASK_YUV_CHROMA_INTERP_U) && defined(D_MASK_YUV_CHROMA_INTERP_V)
			case EGL_NATIVE_PIXFORMAT_YUYV_REL:
				*pePixelFormat  = IMG_PIXFMT_YUYV;
				*puiBitPerPixel = 16;
				bYUVformat    = true;
				break;
			case EGL_NATIVE_PIXFORMAT_VYUY_REL:
				*pePixelFormat  = IMG_PIXFMT_VYUY;
				*puiBitPerPixel = 16;
				bYUVformat    = true;
				break;
			case EGL_NATIVE_PIXFORMAT_YVYU_REL:
				*pePixelFormat  = IMG_PIXFMT_YVYU;
				*puiBitPerPixel = 16;
				bYUVformat    = true;
				break;
			case EGL_NATIVE_PIXFORMAT_NV21_REL:
				*pePixelFormat  = IMG_PIXFMT_YVU420_2PLANE;
				*puiBitPerPixel = 12;
				bYUVformat    = true;
				break;
			case EGL_NATIVE_PIXFORMAT_I420_REL:
				*pePixelFormat  = IMG_PIXFMT_YUV420_3PLANE;
				*puiBitPerPixel = 12;
				bYUVformat    = true;
				break;
			case EGL_NATIVE_PIXFORMAT_YV12_REL:
				*pePixelFormat  = IMG_PIXFMT_YVU420_3PLANE;
				*puiBitPerPixel = 12;
				bYUVformat    = true;
				break;
#endif
			default:
				// PVR_DPF((PVR_DBG_ERROR, "Unsupport format"));
				return -1;
		}
	}

	/* [RELCOMMENT STD-0052:P-0149] Set parameter for YUV Attributes. */
	if (bYUVformat)
	{
		switch ((psNativePixmap->format & D_MASK_YUV_COLORSPACE))
		{
			case EGL_YUV_COLORSPACE_BT601_CONFORMANT_RANGE_REL:
				*peYUVColorSpace = IMG_COLORSPACE_BT601_CONFORMANT_RANGE;
				break;
			case EGL_YUV_COLORSPACE_BT601_FULL_RANGE_REL:
				*peYUVColorSpace = IMG_COLORSPACE_BT601_FULL_RANGE;
				break;
			case EGL_YUV_COLORSPACE_BT709_CONFORMANT_RANGE_REL:
				*peYUVColorSpace = IMG_COLORSPACE_BT709_CONFORMANT_RANGE;
				break;
			case EGL_YUV_COLORSPACE_BT709_FULL_RANGE_REL:
				*peYUVColorSpace = IMG_COLORSPACE_BT709_FULL_RANGE;
				break;
			default:
				*peYUVColorSpace = IMG_COLORSPACE_BT601_FULL_RANGE;
				break;
		}

		/* [RELCOMMENT STD-0052:P-0149] eYUVChromaUInterp and eYUVChromaUInterp are extra attributes that doesn't open. */
#if defined(D_MASK_YUV_CHROMA_INTERP_U) && defined(D_MASK_YUV_CHROMA_INTERP_V)
		switch ((psNativePixmap->format & D_MASK_YUV_CHROMA_INTERP_U))
		{
			case EGL_CHROMA_INTERP_U_ZERO_REL:
				*peYUVChromaUInterp = IMG_CHROMA_INTERP_ZERO;
				break;
			case EGL_CHROMA_INTERP_U_QUATER_REL:
				*peYUVChromaUInterp = IMG_CHROMA_INTERP_QUARTER;
				break;
			case EGL_CHROMA_INTERP_U_HALF_REL:
				*peYUVChromaUInterp = IMG_CHROMA_INTERP_HALF;
				break;
			case EGL_CHROMA_INTERP_U_THREEQUARTERS_REL:
				*peYUVChromaUInterp = IMG_CHROMA_INTERP_THREEQUARTERS;
				break;
			default:
				*peYUVChromaUInterp = IMG_CHROMA_INTERP_ZERO;
				break;
		}

		switch ((psNativePixmap->format & D_MASK_YUV_CHROMA_INTERP_V))
		{
			case EGL_CHROMA_INTERP_V_ZERO_REL:
				*peYUVChromaVInterp = IMG_CHROMA_INTERP_ZERO;
				break;
			case EGL_CHROMA_INTERP_V_QUATER_REL:
				*peYUVChromaVInterp = IMG_CHROMA_INTERP_QUARTER;
				break;
			case EGL_CHROMA_INTERP_V_HALF_REL:
				*peYUVChromaVInterp = IMG_CHROMA_INTERP_HALF;
				break;
			case EGL_CHROMA_INTERP_V_THREEQUARTERS_REL:
				*peYUVChromaVInterp = IMG_CHROMA_INTERP_THREEQUARTERS;
				break;
			default:
				*peYUVChromaVInterp = IMG_CHROMA_INTERP_ZERO;
				break;
		}
#endif
	}
	else
	{
		*peYUVColorSpace = 0;
		*peYUVChromaUInterp = 0;
		*peYUVChromaVInterp = 0;
	}

	return 0;
}

/***********************************************************************************
 Function Name      : WSEGL_CreatePixmapDrawable
 Inputs             : hDisplay, psConfig, hNativePixmap
 Outputs            : phDrawable, peRotationAngle
 Returns            : Error code
 Description        : Create a pixmap drawable for a native pixmap
************************************************************************************/
static WSEGLError WSEGL_CreatePixmapDrawable(WSEGLDisplayHandle hDisplay,
					     WSEGLConfig *psConfig,
					     WSEGLDrawableHandle *phDrawable,
					     NativePixmapType hNativePixmap,
					     IMG_ROTATION *peRotationAngle,
					     IMG_COLOURSPACE_FORMAT eColorSpace,
						 bool bIsProtected)
{

	NULLDRM_WSEGL_DISPLAY *psDisplay = (NULLDRM_WSEGL_DISPLAY *)hDisplay;
	NULLDRM_WSEGL_DRAWABLE *psDrawable;
	EGLNativePixmapTypeREL *psNativePixmap;
	void *pvNativePixmapVAddr;
	uint32_t uiAllocationSize;
	uint32_t uiStrideInBytes;
	/* [RELCOMMENT STD-0052:P-0149] Add variable for yuv texture.*/
	IMG_YUV_COLORSPACE    eYUVColorSpace;
	IMG_YUV_CHROMA_INTERP eYUVChromaUInterp;
	IMG_YUV_CHROMA_INTERP eYUVChromaVInterp;
	uint32_t uiBitPerPixel;
	IMG_PIXFMT ePixelFormat;
	int ret;

	WSEGL_UNREFERENCED_PARAMETER(hDisplay);
	WSEGL_UNREFERENCED_PARAMETER(eColorSpace);
	WSEGL_UNREFERENCED_PARAMETER(bIsProtected);

	/*
	 * Not allow NULL native pixmap
	 */
	if(hNativePixmap == NULL)
	{
		// PVR_DPF((PVR_DBG_ERROR, "Invalid Paramter: hNativePixmap is NULL"));
		return WSEGL_BAD_NATIVE_PIXMAP;
	}

	psNativePixmap = (EGLNativePixmapTypeREL *)hNativePixmap;
	ret = ValidateNativePixmap(psNativePixmap);
	if(ret != 0)
	{
		// PVR_DPF((PVR_DBG_ERROR, "Invalid Paramter: ValidateNativePixmap return %d", ret));
		return WSEGL_BAD_NATIVE_PIXMAP;
	}

	pvNativePixmapVAddr = psNativePixmap->pixelData;

	if(psConfig != NULL && !(psConfig->ui32DrawableType & WSEGL_DRAWABLE_PIXMAP))
	{
		// PVR_DPF((PVR_DBG_ERROR, "Configuration doesn't match"));
		return WSEGL_BAD_MATCH;
	}

	ret = NativePixFmtToIMGPixFmt(psConfig, psNativePixmap,
				      &ePixelFormat,
				      &uiBitPerPixel,
				      &eYUVColorSpace,
				      &eYUVChromaUInterp,
				      &eYUVChromaVInterp);
	if (ret != 0)
	{
		return WSEGL_BAD_NATIVE_PIXMAP;
	}

	psDrawable = CreateDrawable(psDisplay, WSEGL_DRAWABLE_PIXMAP, 1);
	if (!psDrawable)
	{
		return WSEGL_OUT_OF_MEMORY;
	}

	/* Wrap the native pixmap (in this case simply a virtual address) */
	{
		/* [RELCOMMENT STD-0052:P-0149] If format is YUV 2 or 3plane, set stride for Component of Y plane.*/
		switch (ePixelFormat)
		{
			case IMG_PIXFMT_YUV420_2PLANE:
			case IMG_PIXFMT_YVU420_2PLANE:
			case IMG_PIXFMT_YUV420_3PLANE:
			case IMG_PIXFMT_YVU420_3PLANE:
				uiStrideInBytes = (uint32_t)psNativePixmap->stride; /* Y plane is 8bpp. */
				break;
			default:
				uiStrideInBytes = ((uint32_t)psNativePixmap->stride * uiBitPerPixel) >> 3;
		}

		/* [RELCOMMENT STD-0052:P-0149] Convert bit to byte.*/
		uiAllocationSize = ((uint32_t)psNativePixmap->stride * (uint32_t)psNativePixmap->height * uiBitPerPixel) >> 3;

		if (!CreateBuffer(psDisplay,
				      psDrawable->uiType,
				      (uint32_t)psNativePixmap->width,
				      (uint32_t)psNativePixmap->height,
				      ePixelFormat,
				      pvNativePixmapVAddr, /* PIXMAP only */
				      uiAllocationSize,    /* PIXMAP only */
				      uiStrideInBytes,     /* PIXMAP only */
				      &psDrawable->apsBuffers[0]))
		{
			DestroyDrawable(psDrawable);
			return WSEGL_OUT_OF_MEMORY;
		}

		/* [RELCOMMENT STD-0052:P-0149] Set YUV attributes.*/
		psDrawable->apsBuffers[0]->eYUVColorSpace    = eYUVColorSpace;
		psDrawable->apsBuffers[0]->eYUVChromaUInterp = eYUVChromaUInterp;
		psDrawable->apsBuffers[0]->eYUVChromaVInterp = eYUVChromaVInterp;

#if defined(DEBUG)
		CheckBufferAttribs(psDrawable->apsBuffers[0], psDrawable->uiType);
#endif /* DEBUG */
	}

	*phDrawable = (WSEGLDrawableHandle)psDrawable;
	*peRotationAngle = IMG_ROTATION_0DEG;

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_DeleteDrawable
 Inputs             : hDrawable
 Outputs            : None
 Returns            : Error code
 Description        : Delete a drawable - Only a window drawable is supported
                                          in this implementation
************************************************************************************/
static WSEGLError WSEGL_DeleteDrawable(WSEGLDrawableHandle hDrawable)
{
	NULLDRM_WSEGL_DRAWABLE *psDrawable = (NULLDRM_WSEGL_DRAWABLE *)hDrawable;
	NULLDRM_WSEGL_BUFFER *psCurrentBuffer;

	DLC_WaitForVBlank(gsDrmDriver.hDevice, psDrawable->hDrmCrtc, NULLDRM_WSEGL_DRAWABLE_BUFFER_COUNT);

	if (psDrawable->uiType == WSEGL_DRAWABLE_WINDOW)
	{
		uint32_t uiBufferNum;

		if (psDrawable->iPlaneIndex < 0)
		{
			/* Detach a FB from Crtc */
			DLC_SetCrtcMode(gsDrmDriver.hDevice,
					psDrawable->hDrmCrtc,
					0,
					0, 0,
					0, 0);
		}

		if(psDrawable->ePresentMode == NULLDRM_WSEGL_PRESENTMODE_FLIP)
		{
			psDrawable->bThreadEnd = true;
			sem_post(&psDrawable->hThreadSemWakeup);

			pthread_join(psDrawable->hThread, NULL);

			sem_destroy(&psDrawable->hThreadSemWakeup);
			sem_destroy(&psDrawable->hThreadSemComplete);

			for (uiBufferNum = 0; uiBufferNum < psDrawable->uiNumBuffers; uiBufferNum++)
			{
				psCurrentBuffer = psDrawable->apsBuffers[uiBufferNum];

				if (GetDisplayBuffer(psDrawable) != psCurrentBuffer)
				{
					if (psCurrentBuffer->hReadFence != PVRSRV_NO_FENCE)
					{
						PVRSRVFenceWaitExt(gsWSInfo.psDevConnection, psCurrentBuffer->hReadFence, 10000, NULL);
					}
				}
			}

			for (uiBufferNum = 0; uiBufferNum < psDrawable->uiNumBuffers; uiBufferNum++)
			{
				psCurrentBuffer = psDrawable->apsBuffers[uiBufferNum];

				DestroyBuffer(psCurrentBuffer, psDrawable->uiType);
			}
		}
		else if(psDrawable->ePresentMode == NULLDRM_WSEGL_PRESENTMODE_FRONT)
		{
			psCurrentBuffer = psDrawable->apsBuffers[0];

			DestroyBuffer(psCurrentBuffer, psDrawable->uiType);
		}
	}
	else if (psDrawable->uiType == WSEGL_DRAWABLE_PIXMAP)
	{
		psCurrentBuffer = psDrawable->apsBuffers[0];

		DestroyBuffer(psCurrentBuffer, psDrawable->uiType);
	}

	DestroyDrawable(psDrawable);

	return WSEGL_SUCCESS;
}

static WSEGLError DoPresentFlip(NULLDRM_WSEGL_DRAWABLE *psDrawable, PVRSRV_FENCE hFence)
{
	NULLDRM_WSEGL_BUFFER *psCurrentBuffer = psDrawable->apsBuffers[psDrawable->uiCurrentBuffer];
	WSEGLError eResult = WSEGL_SUCCESS;

	/* assert(psDrawable->ePresentMode == NULLDRM_WSEGL_PRESENTMODE_FLIP); */

	if (psCurrentBuffer->hFence != PVRSRV_NO_FENCE)
	{
		PVRSRVFenceDestroyExt(gsWSInfo.psDevConnection, psCurrentBuffer->hFence);
		psCurrentBuffer->hFence = PVRSRV_NO_FENCE;
	}
	if (psCurrentBuffer->hReadFence != PVRSRV_NO_FENCE)
	{
		PVRSRVFenceDestroyExt(gsWSInfo.psDevConnection, psCurrentBuffer->hReadFence);
	}
	psCurrentBuffer->hReadFence = hFence;

	if (psDrawable->uiSwapInterval == 0)
	{
		if (psDrawable->uiDisable_update == 0)
		{
			if (psDrawable->iPlaneIndex >= 0)
			{
				/* Overlay plane */
				if (DLC_SetPlane(gsDrmDriver.hDevice,
							psDrawable->hDrmPlane,
							psCurrentBuffer->hDLCHandle,
							psDrawable->sPlaneRect.iXOffset,
							psDrawable->sPlaneRect.iYOffset,
							psDrawable->sPlaneRect.sDims.uiWidth,
							psDrawable->sPlaneRect.sDims.uiHeight,
							0, 0,
							psDrawable->uiSwapInterval))
				{
					// PVR_DPF((PVR_DBG_ERROR, "%s: SetPlane failed", __func__));
					eResult = WSEGL_BAD_NATIVE_DISPLAY;
				}
			}
			else
			{
				/* Primary Plane */
				if (DLC_PageFlip(gsDrmDriver.hDevice,
							psDrawable->hDrmCrtc,
							psCurrentBuffer->hDLCHandle,
							psDrawable->uiSwapInterval))
				{
					// PVR_DPF((PVR_DBG_ERROR, "%s: PageFlip failed", __func__));
					eResult = WSEGL_BAD_NATIVE_DISPLAY;
				}
			}
		}
		else
		{
			if (psCurrentBuffer->hReadFence != PVRSRV_NO_FENCE)
			{
				PVRSRVFenceDestroyExt(gsWSInfo.psDevConnection, psCurrentBuffer->hReadFence);
				psCurrentBuffer->hReadFence = PVRSRV_NO_FENCE;
			}
		}

		psDrawable->uiDisable_update = 1;
	}
	else if (psDrawable->uiSwapInterval)
	{
		sem_post(&psDrawable->hThreadSemWakeup);
		sem_wait(&psDrawable->hThreadSemComplete);

		psDrawable->uiDisable_update = 0;
	}

	return eResult;
}

/***********************************************************************************
 Function Name      : WSEGL_SwapDrawable
 Inputs             : hDrawable, hFence
 Outputs            : None
 Returns            : Error code
 Description        : Post the colour buffer of a window drawable to a window
************************************************************************************/
static WSEGLError WSEGL_SwapDrawableWithDamage(WSEGLDrawableHandle hDrawable,
                                               EGLint *paiDamageRect,
                                               EGLint iNumDamageRect,
                                               PVRSRV_FENCE hFence)
{
	WSEGLError eError = WSEGL_SUCCESS;
	NULLDRM_WSEGL_DRAWABLE *psDrawable = (NULLDRM_WSEGL_DRAWABLE *)hDrawable;
	unsigned i;

#if defined(SUPPORT_WSEGL_LOGGING)
	char str[4][32] = {
		"SwapDrawable: buffer0",
		"SwapDrawable: buffer1",
		"SwapDrawable: buffer2",
		"SwapDrawable: buffer3",
	};
#endif /* SUPPORT_SUPPORT_WSEGL_LOGGING */

	WSEGL_UNREFERENCED_PARAMETER(paiDamageRect);
	WSEGL_UNREFERENCED_PARAMETER(iNumDamageRect);

	if (psDrawable->uiType == WSEGL_DRAWABLE_PIXMAP)
	{
		return WSEGL_SUCCESS;
	}

	if (psDrawable->ePresentMode == NULLDRM_WSEGL_PRESENTMODE_FRONT)
	{
		if (hFence != PVRSRV_NO_FENCE)
		{
			PVRSRVFenceDestroyExt(gsWSInfo.psDevConnection, hFence);
		}
		return WSEGL_SUCCESS;
	}

	for (i = 0; i < ARRAY_SIZE(psDrawable->apsBuffers); i++)
	{
		/* With EGL_BUFFER_PRESERVED, all the frames after the first have the
		 * previous frame's data, i.e. 1 frame before */
		if (psDrawable->bSwapBehaviourPreserve)
		{
			psDrawable->apsBuffers[i]->uiBufferAge = 1;
		}
		else /* EGL_BUFFER_DESTROYED, each buffer is now one frame older */
		{
			/* Unused buffer have invalid data */
			if (psDrawable->apsBuffers[i]->uiBufferAge > 0)
			{
				psDrawable->apsBuffers[i]->uiBufferAge++;
			}
		}
	}
	GetRenderBuffer(psDrawable)->uiBufferAge = 1;

	switch (psDrawable->ePresentMode)
	{
		case NULLDRM_WSEGL_PRESENTMODE_FLIP:
#if defined(SUPPORT_WSEGL_LOGGING)
			DLCScope_UpdateFrame(hScopeMain);
			DLCScope_TimingBegin(hScopeMain, str[psDrawable->uiCurrentBuffer], 0, 0);
#endif /* SUPPORT_WSEGL_LOGGING */
			eError = DoPresentFlip(psDrawable, hFence);
#if defined(SUPPORT_WSEGL_LOGGING)
			DLCScope_TimingEnd(hScopeMain);
#endif /* SUPPORT_WSEGL_LOGGING */
			break;
		default:
			return WSEGL_BAD_MATCH;
	}

	if (psDrawable->bFrameStarted)
	{
		NextFrameBuffer(psDrawable);

		if (psDrawable->uiSwapInterval > 1)
		{
			psDrawable->apsBuffers[psDrawable->uiCurrentBuffer]->bFBInUse = false;
		}
	}

	psDrawable->bFrameStarted = false;

	return eError;
}

/***********************************************************************************
 Function Name      : WSEGL_SwapControlInterval
 Inputs             : hDrawable, uiInterval
 Outputs            : None
 Returns            : Error code
 Description        : Set the swap interval of a window drawable
************************************************************************************/
static WSEGLError WSEGL_SwapControlInterval(WSEGLDrawableHandle hDrawable,
					    EGLint iInterval)
{
	NULLDRM_WSEGL_DRAWABLE *psDrawable = (NULLDRM_WSEGL_DRAWABLE *)hDrawable;

	if (((int32_t)iInterval >= NULLDRM_MIN_SWAP_INTERVAL) &&
		((int32_t)iInterval <= NULLDRM_MAX_SWAP_INTERVAL))
	{
		psDrawable->uiSwapInterval = (uint32_t)iInterval;
	}
	else
	{
		// PVR_DPF((PVR_DBG_ERROR, "%s: Swap interval outside of DC range ", __func__));
		return WSEGL_BAD_DRAWABLE;
	}

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_WaitNative
 Inputs             : hDrawable, uiEngine
 Outputs            : None
 Returns            : Error code
 Description        : Flush any native rendering requests on a drawable
************************************************************************************/
static WSEGLError WSEGL_WaitNative(WSEGLDrawableHandle hDrawable, EGLint iEngine)
{
	WSEGL_UNREFERENCED_PARAMETER(hDrawable);

	/* Not supported */
	if (iEngine != WSEGL_DEFAULT_NATIVE_ENGINE)
	{
		return WSEGL_BAD_NATIVE_ENGINE;
	}

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_CopyFromDrawable
 Inputs             : hDrawable, hNativePixmap
 Outputs            : None
 Returns            : Error code
 Description        : Copies colour buffer data from a drawable to a native Pixmap
************************************************************************************/
static WSEGLError WSEGL_CopyFromDrawable(WSEGLDrawableHandle hDrawable,
					 NativePixmapType hNativePixmap)
{
	WSEGL_UNREFERENCED_PARAMETER(hDrawable);
	WSEGL_UNREFERENCED_PARAMETER(hNativePixmap);

	/* Not supported */
	return WSEGL_BAD_NATIVE_PIXMAP;
}

/***********************************************************************************
 Function Name      : WSEGL_CopyFromPBuffer
 Inputs             : hMemDesc, uiWidth, uiHeight, uiStride,
                      ePixelFormat, hNativePixmap
 Outputs            : None
 Returns            : Error code
 Description        : Copies colour buffer data from a PBuffer to a native Pixmap
************************************************************************************/
static WSEGLError WSEGL_CopyFromPBuffer(PVRSRV_MEMDESC hMemDesc,
					EGLint iWidth,
					EGLint iHeight,
					uint32_t uiStride,
					IMG_PIXFMT ePixelFormat,
					NativePixmapType hNativePixmap)
{
	WSEGL_UNREFERENCED_PARAMETER(hMemDesc);
	WSEGL_UNREFERENCED_PARAMETER(iWidth);
	WSEGL_UNREFERENCED_PARAMETER(iHeight);
	WSEGL_UNREFERENCED_PARAMETER(uiStride);
	WSEGL_UNREFERENCED_PARAMETER(ePixelFormat);
	WSEGL_UNREFERENCED_PARAMETER(hNativePixmap);

	/* Not supported */
	return WSEGL_BAD_NATIVE_PIXMAP;
}

/***********************************************************************************
 Function Name      : WSEGL_GetDrawableParameters
 Inputs             : hDrawable
 Outputs            : psSourceParams, psRenderParams
 Returns            : Error code
 Description        : Returns the parameters of a drawable that are needed
                      by the GL driver
************************************************************************************/
static WSEGLError WSEGL_GetDrawableParameters(WSEGLDrawableHandle hDrawable,
					      WSEGLDrawableParams *psSourceParams,
					      WSEGLDrawableParams *psRenderParams)
{
	NULLDRM_WSEGL_DRAWABLE *psDrawable = (NULLDRM_WSEGL_DRAWABLE *)hDrawable;
	NULLDRM_WSEGL_BUFFER *psSourceBuffer;
	NULLDRM_WSEGL_BUFFER *psRenderBuffer;
	int i;

	memset(psSourceParams, 0, sizeof(*psSourceParams));
	memset(psRenderParams, 0, sizeof(*psRenderParams));

	/* Source buffer params */
	psSourceBuffer = GetDisplayBuffer(psDrawable);

	psSourceParams->sBase.iWidth		= psSourceBuffer->sAttribs.uiWidth;
	psSourceParams->sBase.iHeight		= psSourceBuffer->sAttribs.uiHeight;
	psSourceParams->sBase.ui32StrideInBytes	= psSourceBuffer->sAttribs.uiStride;
	psSourceParams->sBase.ePixelFormat	= DLCPixFmtToIMGPixFmt(psSourceBuffer->sAttribs.ePixelFormat);
	psSourceParams->sBase.eMemLayout	= DLCMemLayoutToFBLayout(psSourceBuffer->sAttribs.eMemLayout);
	psSourceParams->sBase.eFBCompression	= DLCCompressionToFBFbc(psSourceBuffer->sAttribs.eCompression);

	if (psSourceBuffer->hReadFence != PVRSRV_NO_FENCE)
	{
		psSourceParams->sBase.hFence	= psSourceBuffer->hReadFence;
	}

	else
	{
		psSourceParams->sBase.hFence	= psSourceBuffer->hFence;
	}
	psSourceParams->sBase.ui32Flags = 0;

	psSourceParams->sBase.ui32Layers	= 1;
	psSourceParams->eRotationAngle		= IMG_ROTATION_0DEG;

	psSourceParams->sBase.asHWAddress[0]	= psSourceBuffer->sDevVirtAddr;
	psSourceParams->sBase.ahMemDesc[0]	= psSourceBuffer->hMemDesc;
	for (i = 1; i < WSEGL_MAX_PLANES; i++)
	{
		psSourceParams->sBase.asHWAddress[i].uiAddr = 0;
		psSourceParams->sBase.ahMemDesc[i]          = 0;
	}

	/* Render buffer params */
	psRenderBuffer = GetRenderBuffer(psDrawable);

	psRenderParams->sBase.iWidth		= psRenderBuffer->sAttribs.uiWidth;
	psRenderParams->sBase.iHeight		= psRenderBuffer->sAttribs.uiHeight;
	psRenderParams->sBase.ui32StrideInBytes	= psRenderBuffer->sAttribs.uiStride;
	psRenderParams->sBase.ePixelFormat	= DLCPixFmtToIMGPixFmt(psRenderBuffer->sAttribs.ePixelFormat);
	psRenderParams->sBase.eMemLayout	= DLCMemLayoutToFBLayout(psRenderBuffer->sAttribs.eMemLayout);
	psRenderParams->sBase.eFBCompression	= DLCCompressionToFBFbc(psRenderBuffer->sAttribs.eCompression);

	psRenderParams->sBase.hFence		= psRenderBuffer->hFence;
	psRenderParams->sBase.ui32Flags = 0;

	psRenderParams->ui32MaxPending3D	= 0;
	psRenderParams->sBase.i32BufferAge	= psRenderBuffer->uiBufferAge;
	psRenderParams->sBase.ui32Layers 	= 1;
	psRenderParams->eRotationAngle		= IMG_ROTATION_0DEG;

	psRenderParams->sBase.asHWAddress[0]	= psRenderBuffer->sDevVirtAddr;
	psRenderParams->sBase.ahMemDesc[0]	= psRenderBuffer->hMemDesc;
	for (i = 1; i < WSEGL_MAX_PLANES; i++)
	{
		psRenderParams->sBase.asHWAddress[i].uiAddr = 0;
		psRenderParams->sBase.ahMemDesc[i]          = 0;
	}

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_GetImageParameters
 Inputs             : hDrawable
 Outputs            : psImageParams
 Returns            : Error code
 Description        : Returns the parameters of an image that are needed
                      by the GL driver
************************************************************************************/
static WSEGLError WSEGL_GetImageParameters(WSEGLDrawableHandle hDrawable,
                                           WSEGLImageParams *psImageParams,
                                           unsigned long ulPlaneOffset)
{
	NULLDRM_WSEGL_DRAWABLE *psDrawable = (NULLDRM_WSEGL_DRAWABLE *)hDrawable;
	NULLDRM_WSEGL_BUFFER *psCurrentBuffer;

	uint32_t  aui32PlaneSizeInBytes[2] = {0};
	WSEGL_UNREFERENCED_PARAMETER(ulPlaneOffset);

	/* [RELCOMMENT STD-0052:P-0149] Reset by 0.*/
	memset(psImageParams, 0, sizeof(*psImageParams));

	psCurrentBuffer = psDrawable->apsBuffers[0];

	psImageParams->sBase.iWidth		= psCurrentBuffer->sAttribs.uiWidth;
	psImageParams->sBase.iHeight		= psCurrentBuffer->sAttribs.uiHeight;
	psImageParams->sBase.ui32StrideInBytes	= psCurrentBuffer->sAttribs.uiStride;
	psImageParams->sBase.ePixelFormat	= DLCPixFmtToIMGPixFmt(psCurrentBuffer->sAttribs.ePixelFormat);
	psImageParams->sBase.eMemLayout		= DLCMemLayoutToFBLayout(psCurrentBuffer->sAttribs.eMemLayout);
	psImageParams->sBase.eFBCompression	= DLCCompressionToFBFbc(psCurrentBuffer->sAttribs.eCompression);

	psImageParams->sBase.hFence			= PVRSRV_NO_FENCE;

#if defined(EGL_EXTENSION_PARTIAL_UPDATES)
	psImageParams->sBase.i32BufferAge	= 0;
#endif /* EGL_EXTENSION_PARTIAL_UPDATES */
	psImageParams->sBase.ui32Flags = 0;
	psImageParams->sBase.ui32Layers = 1;

	/* [RELCOMMENT STD-0052:P-0149] Set YUV attributes.*/
	psImageParams->sBase.eYUVColorspace		= psCurrentBuffer->eYUVColorSpace;
	psImageParams->eChromaUInterp		= psCurrentBuffer->eYUVChromaUInterp;
	psImageParams->eChromaVInterp		= psCurrentBuffer->eYUVChromaVInterp;

	psImageParams->sBase.asHWAddress[0]			= psCurrentBuffer->sDevVirtAddr;
	psImageParams->sBase.ahMemDesc[0]			= psCurrentBuffer->hMemDesc;
	psImageParams->sBase.auiAllocSize[0]		= psCurrentBuffer->sAttribs.uiMemSize;

	if (IMGPixFmtIsRELYUVFmt(psImageParams->sBase.ePixelFormat))
	{
		if (GetPlaneSizeInBytes(psImageParams->sBase.ePixelFormat, aui32PlaneSizeInBytes, psImageParams->sBase.ui32StrideInBytes, psImageParams->sBase.iHeight))
		{
			psImageParams->sBase.asHWAddress[1].uiAddr                      = psImageParams->sBase.asHWAddress[0].uiAddr + aui32PlaneSizeInBytes[0];
			psImageParams->sBase.asHWAddress[2].uiAddr                      = psImageParams->sBase.asHWAddress[1].uiAddr + aui32PlaneSizeInBytes[1];
		}
		/* ui32YPlaneStrideInTexels is required for YUV formats */
		if (!GetYUVPlaneTexelStrideFromByteStride(psImageParams->sBase.ePixelFormat, psImageParams->sBase.ui32StrideInBytes, &psImageParams->sYUVInfo.ui32Plane0StrideInTexels))
		{
			return WSEGL_BAD_NATIVE_PIXMAP;
		}
	}

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_ConnectDrawable
 Inputs             : hDrawable
 Outputs            : None
 Returns            : Error code
 Description        : Indicates that the specified Drawable is in use by EGL as a
                      read or draw surface (separately)
************************************************************************************/
static WSEGLError WSEGL_ConnectDrawable(WSEGLDrawableHandle hDrawable)
{
	WSEGL_UNREFERENCED_PARAMETER(hDrawable);

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_DisconnectDrawable
 Inputs             : hDrawable
 Outputs            : None
 Returns            : Error code
 Description        : Indicates that the specified Drawable is no longer in use by
                      EGL as a read or draw surface (separately)
************************************************************************************/
static WSEGLError WSEGL_DisconnectDrawable(WSEGLDrawableHandle hDrawable)
{
	WSEGL_UNREFERENCED_PARAMETER(hDrawable);

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_FlagStartFrame
 Inputs             : hDrawable
 Outputs            : None
 Returns            : Error code
 Description        : Indicates that a client driver has started a frame (started
                      drawing) since the last SwapDrawable call.
************************************************************************************/
static WSEGLError WSEGL_FlagStartFrame(WSEGLDrawableHandle hDrawable)
{
	NULLDRM_WSEGL_DRAWABLE *psDrawable = hDrawable;

	// PVR_ASSERT(psDrawable);

	psDrawable->bFrameStarted = true;

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_AcquireCPUMapping
 Inputs             : hDrawable, hMemDesc
 Outputs            : ppvCpuVirtAddr
 Returns            : Error code
 Description        : Request the CPU virtual address of (or a mapping to be
                      established for) a WSEGLDrawable.
************************************************************************************/
static WSEGLError WSEGL_AcquireCPUMapping(WSEGLDrawableHandle hDrawable,
					  PVRSRV_MEMDESC hMemDesc,
					  void **ppvCpuVirtAddr)
{
	NULLDRM_WSEGL_DRAWABLE *psDrawable = (NULLDRM_WSEGL_DRAWABLE *)hDrawable;
	WSEGLError eWSEGLError = WSEGL_SUCCESS;

	if (psDrawable->uiType == WSEGL_DRAWABLE_WINDOW)
	{
		if (!PVRSRVAcquireCPUMappingExt(hMemDesc, ppvCpuVirtAddr))
		{
			eWSEGLError = WSEGL_BAD_DRAWABLE;
		}
	}
	else
	{
		/* WSEGL_DRAWABLE_PIXMAP */
		*ppvCpuVirtAddr = psDrawable->apsBuffers[0]->sAttribs.pvCpuVirtAddr;
	}

	return eWSEGLError;
}

/***********************************************************************************
 Function Name      : WSEGL_ReleaseCPUMapping
 Inputs             : hDrawable, hMemDesc
 Outputs            : None
 Returns            : Error code
 Description        : Indicate that a WSEGLDrawable's CPU virtual address and/or
                      mapping is no longer required.
************************************************************************************/
static WSEGLError WSEGL_ReleaseCPUMapping(WSEGLDrawableHandle hDrawable,
					  PVRSRV_MEMDESC hMemDesc)
{
	NULLDRM_WSEGL_DRAWABLE *psDrawable = (NULLDRM_WSEGL_DRAWABLE *)hDrawable;

	if (psDrawable->uiType == WSEGL_DRAWABLE_WINDOW)
	{
		PVRSRVReleaseCPUMappingExt(hMemDesc);
	}

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_SetSwapBehaviour
 Inputs             : hDrawable
 Inputs             : iDestroyed
 Outputs            : None
 Returns            : Error code
 Description        : Indicates if the surface is using EGL_BUFFER_DESTROYED.
************************************************************************************/
static WSEGLError WSEGL_SetSwapBehaviour(WSEGLDrawableHandle hDrawable, int iDestroyed)
{
	NULLDRM_WSEGL_DRAWABLE *psDrawable = hDrawable;

	// PVR_ASSERT(psDrawable);

	psDrawable->bSwapBehaviourPreserve = !iDestroyed;

	return WSEGL_SUCCESS;
}

/***********************************************************************************
 Function Name      : WSEGL_SetSingleBuffered
 Inputs             : hDrawable
 Inputs             : bEnabled
 Outputs            : None
 Returns            : Error code
 Description        : 
************************************************************************************/
static WSEGLError WSEGL_SetSingleBuffered(WSEGLDrawableHandle hDrawable, int bEnabled)
{
	WSEGL_UNREFERENCED_PARAMETER(hDrawable);
	WSEGL_UNREFERENCED_PARAMETER(bEnabled);
	return WSEGL_BAD_DRAWABLE;
}

/**********************************************************************
 *
 *       WARNING: Do not modify any code below this point
 *
 ***********************************************************************/

/**************************************************************************/ /*!
@Function    WSEGL_FlagIntentToQuery
@Description Indicates if EGL is going to query information for a drawable
             without colour buffers.
@Input       hDrawable        WSEGL drawable handle.
@Return      A WSEGL error code
*/ /***************************************************************************/
static WSEGLError WSEGL_FlagIntentToQuery(WSEGLDrawableHandle hDrawable)
{
	WSEGL_UNREFERENCED_PARAMETER(hDrawable);

	return WSEGL_SUCCESS;
}

/**********************************************************************
 *
 *       WARNING: Do not modify any code below this point
 *
 ***********************************************************************/
static const WSEGL_FunctionTable gsFunctionTable =
{
	WSEGL_VERSION,
	WSEGL_IsDisplayValid,
	WSEGL_InitialiseDisplay,
	WSEGL_CloseDisplay,
	WSEGL_CreateWindowDrawable,
	WSEGL_CreatePixmapDrawable,
	WSEGL_DeleteDrawable,
	WSEGL_SwapDrawableWithDamage,
	WSEGL_SwapControlInterval,
	WSEGL_WaitNative,
	WSEGL_CopyFromDrawable,
	WSEGL_CopyFromPBuffer,
	WSEGL_GetDrawableParameters,
	WSEGL_GetImageParameters,
	WSEGL_ConnectDrawable,
	WSEGL_DisconnectDrawable,
	WSEGL_FlagStartFrame,
	WSEGL_AcquireCPUMapping,
	WSEGL_ReleaseCPUMapping,
	WSEGL_SetSwapBehaviour,
	WSEGL_SetSingleBuffered,
	WSEGL_FlagIntentToQuery
};

/***********************************************************************************
 Function Name      : WSEGL_GetFunctionTablePointer
 Inputs             : None
 Outputs            : None
 Returns            : Function table pointer
 Description        : Returns a pointer to the window system function pointer table
************************************************************************************/
WSEGL_EXPORT const WSEGL_FunctionTable *WSEGL_GetFunctionTablePointer(void)
{
	return &gsFunctionTable;
}


/******************************************************************************
   End of file (null_ws_drm.c)
 ******************************************************************************/
