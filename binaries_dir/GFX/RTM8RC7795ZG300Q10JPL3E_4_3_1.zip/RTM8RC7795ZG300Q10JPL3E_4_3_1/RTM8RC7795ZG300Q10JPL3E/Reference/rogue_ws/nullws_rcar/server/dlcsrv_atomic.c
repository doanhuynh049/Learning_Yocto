/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server
 *
 *	libdrm access functions
 */

#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>

#include "dlcsrv_common.h"

#ifdef USE_DRMATOMIC
extern int  drmFd;
static bool bAcquireAtomic = false;


static DLC_STATUS DrmModeAtomicCommit(int crtc_index, drmModeAtomicReqPtr atomic_req, void *user_data)
{
	uint32_t flags = 0;
	int ret;
	DLC_STATUS eStatus = DLC_STS_OK;

	DLCSRV_DRMLog_TimingBegin(crtc_index, "AtomicCommit", 0, 0, false);

	if (user_data) {
//		flags = DRM_MODE_PAGE_FLIP_EVENT;
		flags = DRM_MODE_PAGE_FLIP_EVENT | DRM_MODE_ATOMIC_NONBLOCK;
	} else {
		flags = DRM_MODE_ATOMIC_NONBLOCK;
	}

	ret = drmModeAtomicCommit(drmFd, atomic_req, flags, user_data);

	if (ret < 0)
	{
		DLCSRV_LOG_ERR("CRTC(%d): %s\n", DLCSRV_CrtcIndexToId(crtc_index), strerror(ret));

		switch (ret)
		{
		case ENOMEM:
			eStatus = DLC_STS_OUT_OF_MEMORY;
			break;
		case EINVAL:	/* fall through */
		default:
			eStatus = DLC_STS_INVALID_PARAMS;
			break;
		}
	}

	DLCSRV_DRMLog_TimingEnd(crtc_index);

	return eStatus;
}

static DLC_STATUS DrmModeAtomicAddProperties(unsigned int plane_id, unsigned int fb_id, DLCSRV_PLANE_STATUS *plane, drmModeAtomicReqPtr req)
{
	int ret = 0;
	DLC_STATUS eStatus = DLC_STS_OK;

	DLCSRV_DRMLog_TimingBegin(plane->crtc_index, "AtomicAddProperty", plane_id, fb_id, true);

	ret  = drmModeAtomicAddProperty(req, plane_id, plane->property_id.crtc_pid,   DLCSRV_CrtcIndexToId(plane->crtc_index));
	ret |= drmModeAtomicAddProperty(req, plane_id, plane->property_id.fb_pid,     fb_id);
	ret |= drmModeAtomicAddProperty(req, plane_id, plane->property_id.crtc_x_pid, plane->crtc_x);
	ret |= drmModeAtomicAddProperty(req, plane_id, plane->property_id.crtc_y_pid, plane->crtc_y);
	ret |= drmModeAtomicAddProperty(req, plane_id, plane->property_id.crtc_w_pid, plane->crtc_w);
	ret |= drmModeAtomicAddProperty(req, plane_id, plane->property_id.crtc_h_pid, plane->crtc_h);
	ret |= drmModeAtomicAddProperty(req, plane_id, plane->property_id.src_x_pid,  plane->src_x << 16);
	ret |= drmModeAtomicAddProperty(req, plane_id, plane->property_id.src_y_pid,  plane->src_y << 16);
	ret |= drmModeAtomicAddProperty(req, plane_id, plane->property_id.src_w_pid,  plane->src_w << 16);
	ret |= drmModeAtomicAddProperty(req, plane_id, plane->property_id.src_h_pid,  plane->src_h << 16);

	if (ret < 0)
	{
		DLCSRV_LOG_ERR("CRTC(%d): %s\n", DLCSRV_CrtcIndexToId(plane->crtc_index), strerror(ret));

		switch (ret)
		{
		case ENOMEM:
			eStatus = DLC_STS_OUT_OF_MEMORY;
			break;
		case ENOENT:	/* fall through */
		case EINVAL:	/* fall through */
		default:
			eStatus = DLC_STS_INVALID_PARAMS;
			break;
		}
	}

	DLCSRV_DRMLog_TimingEnd(plane->crtc_index);

	return eStatus;
}

/***********************************************************************************
 Function Name      : DLCSRV_AtomicCommit
 Inputs             : crtc_index, atomic_req, user_data
 Outputs            : None
 Returns            : DLC_STATUS
 Description        : 
************************************************************************************/
DLC_STATUS DLCSRV_AtomicCommit(int crtc_index, drmModeAtomicReqPtr atomic_req, void *user_data)
{
	DLC_STATUS eStatus = DLC_STS_OK;

	if (bAcquireAtomic && atomic_req)
	{
		eStatus = DrmModeAtomicCommit(crtc_index, atomic_req, user_data);
	}
	return eStatus;
}

/***********************************************************************************
 Function Name      : DLCSRV_AtomicAddProperties
 Inputs             : plane_id, fb_id, plane, req, user_data
 Outputs            : None
 Returns            : DLC_STATUS
 Description        : 
************************************************************************************/
DLC_STATUS DLCSRV_AtomicAddProperties(unsigned int plane_id, unsigned int fb_id, DLCSRV_PLANE_STATUS *plane, drmModeAtomicReqPtr req, void *user_data)
{
	DLC_STATUS eStatus = DLC_STS_OK;

	if (bAcquireAtomic)
	{
		drmModeAtomicReqPtr atomic_req = req;
		if (!req)
		{
			atomic_req = drmModeAtomicAlloc();
			if (!atomic_req)
			{
				return DLC_STS_OUT_OF_MEMORY;
			}
		}

		eStatus = DrmModeAtomicAddProperties(plane_id, fb_id, plane, atomic_req);

		if (!req)
		{
			/* when req is NULL, to AtomicCommit in one plane */
			DrmModeAtomicCommit(plane->crtc_index, atomic_req, user_data);
			drmModeAtomicFree(atomic_req);
		}
	}
	else
	{
		/* If Atomic is not available, use the SetPlane */
		eStatus = DLCSRV_SetPlane(plane_id, plane->crtc_index, fb_id,
						plane->crtc_x, plane->crtc_y,
						plane->crtc_w, plane->crtc_h,
						plane->src_x,  plane->src_y,
						plane->src_w,  plane->src_h);
	}
	return eStatus;
}

/***********************************************************************************
 Function Name      : DLCSRV_GetPropertyID
 Inputs             : obj_props, prop_name
 Outputs            : prop_id
 Returns            : DLC_STATUS
 Description        : 
************************************************************************************/
DLC_STATUS DLCSRV_GetPropertyID(drmModeObjectPropertiesPtr obj_props, const char *prop_name, unsigned int *prop_id)
{
	drmModePropertyPtr plane_prop;
	unsigned int prop_index;
	unsigned int pid = 0;

	for (prop_index = 0; pid == 0 && prop_index < obj_props->count_props; prop_index++)
	{
		plane_prop = drmModeGetProperty(drmFd, obj_props->props[prop_index]);
		if (!strcmp(plane_prop->name, prop_name))
		{
			pid = plane_prop->prop_id;
		}
		drmModeFreeProperty(plane_prop);
	}
	if (!pid)
	{
		return DLC_STS_NOT_SUPPORTED;
	}

	*prop_id = pid;

	return DLC_STS_OK;
}

/***********************************************************************************
 Function Name      : DLCSRV_GetPlaneProperties
 Inputs             : plane_id, prop_id
 Outputs            : None
 Returns            : DLC_STATUS
 Description        : 
************************************************************************************/
DLC_STATUS DLCSRV_GetPlaneProperties(unsigned int plane_id, DLCSRV_PROPEATY_ID *prop_id)
{
	drmModeObjectProperties *obj_props;
	DLC_STATUS eStatus = DLC_STS_OK;

	obj_props = drmModeObjectGetProperties(drmFd, plane_id, DRM_MODE_OBJECT_PLANE);
	if (!obj_props) {
		return DLC_STS_NOT_SUPPORTED;
	}

	eStatus  = DLCSRV_GetPropertyID(obj_props, "CRTC_ID", &prop_id->crtc_pid);
	eStatus |= DLCSRV_GetPropertyID(obj_props, "FB_ID",   &prop_id->fb_pid);
	eStatus |= DLCSRV_GetPropertyID(obj_props, "CRTC_X",  &prop_id->crtc_x_pid);
	eStatus |= DLCSRV_GetPropertyID(obj_props, "CRTC_Y",  &prop_id->crtc_y_pid);
	eStatus |= DLCSRV_GetPropertyID(obj_props, "CRTC_W",  &prop_id->crtc_w_pid);
	eStatus |= DLCSRV_GetPropertyID(obj_props, "CRTC_H",  &prop_id->crtc_h_pid);
	eStatus |= DLCSRV_GetPropertyID(obj_props, "SRC_X",   &prop_id->src_x_pid);
	eStatus |= DLCSRV_GetPropertyID(obj_props, "SRC_Y",   &prop_id->src_y_pid);
	eStatus |= DLCSRV_GetPropertyID(obj_props, "SRC_W",   &prop_id->src_w_pid);
	eStatus |= DLCSRV_GetPropertyID(obj_props, "SRC_H",   &prop_id->src_h_pid);

	drmModeFreeObjectProperties(obj_props);

	return eStatus;
}

/***********************************************************************************
 Function Name      : DLCSRV_AcquireAtomic
 Inputs             : None
 Outputs            : None
 Returns            : DLCSRV_RESULT
 Description        : 
************************************************************************************/
DLCSRV_RESULT DLCSRV_AcquireAtomic(void)
{
	if (drmSetClientCap(drmFd, DRM_CLIENT_CAP_UNIVERSAL_PLANES, 1))
	{
		return DLCSRV_ERROR_OUT_OF_MEMORY;
	}

	if (drmSetClientCap(drmFd, DRM_CLIENT_CAP_ATOMIC, 1))
	{
		bAcquireAtomic = false;
		return DLCSRV_ERROR_OUT_OF_MEMORY;
	}

	bAcquireAtomic = true;
	return DLCSRV_OK;
}

/***********************************************************************************
 Function Name      : DLCSRV_ReleaseAtomic
 Inputs             : None
 Outputs            : None
 Returns            : None
 Description        : 
************************************************************************************/
void DLCSRV_ReleaseAtomic(void)
{
	drmSetClientCap(drmFd, DRM_CLIENT_CAP_ATOMIC, 0);
	drmSetClientCap(drmFd, DRM_CLIENT_CAP_UNIVERSAL_PLANES, 0);

	bAcquireAtomic = false;
}
#endif /* USE_DRMATOMIC */
