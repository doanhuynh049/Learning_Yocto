/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <pthread.h>

#include "dlcsrv_common.h"

#define DRM_DEVICE	"rcar-du"

static int socket_fd;
static int num_clients = 0;

static int max_client = 0;
static int timeout = 0;
static int server_terminate = 0;

DLCSRV_CLIENT **clients;

extern DLCSRV_DESKTOP_STATUS *desktop_stat;
extern DLCSRV_PLANE_STATUS *plane_stat;

static void AddClient(int client_fd)
{
	DLCSRV_CLIENT *new_client;

	new_client = (DLCSRV_CLIENT *)malloc(sizeof(DLCSRV_CLIENT));
	memset(new_client, 0, sizeof(DLCSRV_CLIENT));

	new_client->client_fd = client_fd;
	new_client->index = num_clients;

	pthread_create(&new_client->thread, NULL, DLCSRV_CommandThread, new_client);

	clients[num_clients] = new_client;

	num_clients++;
}

static void RemoveClient(int index)
{
	DLCSRV_CLIENT *del_client;
	int i;

	num_clients--;

	del_client = clients[index];
	free(del_client);

	for (i = index; i < num_clients; i++)
	{
		clients[i] = clients[i+1];
		clients[i]->index = i;
	}
}

void CloseConnection(int index)
{
	int i;

	DLCSRV_LOG_DEBUG("CLIENT(%d): close\n", clients[index]->client_fd);

	clients[index]->terminate = 1;

	pthread_join(clients[index]->thread, NULL);

	shutdown (clients[index]->client_fd, SHUT_RDWR);
	close(clients[index]->client_fd);


	(void)DLCSRV_SetMaster();
	for (i = 0; i < DLCSRV_GetCrtcNum(); i++)
	{
		if (desktop_stat[i].plane.client_fd == clients[index]->client_fd)
		{
			/* hide desktop plane */
			DLCSRV_SubReleaseDesktop(i);
		}
	}
	for (i = 0; i < DLCSRV_GetPlaneNum(); i++)
	{
		if (plane_stat[i].client_fd == clients[index]->client_fd)
		{
			/* hide plane */
			DLCSRV_SubReleasePlane(i);
		}
	}
	(void)DLCSRV_DropMaster();

	/* release buffers */
	if (clients[index]->buffers)
	{
		usleep(500000);
		DLCSRV_SubFreeBufferAll(clients[index]);
	}

	RemoveClient(index);
}

void CloseAllClient(void)
{
	int i;

	/*
	 * Server exit and close all clients
	 */
	DLCSRV_LOG_DEBUG("DLC_CMD_TERMINATE\n");

	/* delete vblank thread and close DC char dev */
	DLCSRV_KillAllVBlankThreads();

	/* delete PVRScope context */
	DLCSRV_DRMLog_DeinitScope();

	/* terminate sockets */
	for (i = num_clients -1; i >= 0; i--)
	{
		CloseConnection(i);
	}

	server_terminate = 1;
}

static int GetNextEvent(void)
{
	fd_set read_fds;
	struct timeval tv;
	int ret;
	static int time_count = 0;

	FD_ZERO(&read_fds);
	FD_SET(socket_fd, &read_fds);

	tv.tv_sec = 1;
	tv.tv_usec = 0;
	ret = select(socket_fd + 1, &read_fds, NULL, NULL, &tv);
	if (ret == -1)
	{
		DLCSRV_LOG_ERR("select: %s\n", strerror(errno));
		return -1;
	}

	if ((num_clients > 0) || (timeout == 0))
	{
		time_count = 0;
	}
	else
	{
		time_count++;
	}

	if ((ret == 0) && (num_clients == 0) && (time_count > timeout))
	{
		DLCSRV_LOG_INFO("timeout\n");
		return -1;
	}

	if (server_terminate)
	{
		DLCSRV_LOG_INFO("terminate\n");
		return -1;
	}

	/*
	 * check the new connection
	 */
	if (FD_ISSET(socket_fd, &read_fds))
	{
		int new_socket;
		struct sockaddr_un peer_addr;
		socklen_t peer_addr_size;

		peer_addr_size = sizeof(struct sockaddr_un);
		new_socket = accept(socket_fd, (struct sockaddr *) &peer_addr, &peer_addr_size);

		if (new_socket == -1)
		{
			DLCSRV_LOG_ERR("accept: %s\n", strerror(errno));
			return -1;
		}

		if (num_clients <= max_client)
		{
			AddClient(new_socket);
			DLCSRV_LOG_DEBUG("CLIENT(%d): open\n", new_socket);
		}
		else
		{
			shutdown (new_socket, SHUT_RDWR);
			close(new_socket);
			DLCSRV_LOG_INFO("CLIENT(%d): more than %d clients, closed\n", new_socket, max_client);
		}
	}

	return 0;
}

static int InitSocket(void)
{
	mode_t old_umask;
	struct sockaddr_un my_addr;

	DLCSRV_LOG_DEBUG("initialize socket\n");

	socket_fd = socket(AF_UNIX, SOCK_STREAM, 0);
	if (socket_fd == -1)
	{
		DLCSRV_LOG_ERR("socket: %s\n", strerror(errno));
		return -1;
	}

	old_umask = umask(0000);
	memset(&my_addr, 0, sizeof(struct sockaddr_un));
	my_addr.sun_family = AF_UNIX;
	strncpy(my_addr.sun_path, SOCKET_PATH, sizeof(my_addr.sun_path) - 1);

	if(bind(socket_fd, (struct sockaddr *) &my_addr, sizeof(struct sockaddr_un)) == -1)
	{
		DLCSRV_LOG_ERR("bind: %s\n", strerror(errno));
		umask (old_umask);
		return -1;
	}
	umask (old_umask);

	if (listen(socket_fd, max_client) == -1)
	{
		DLCSRV_LOG_ERR("listen: %s\n", strerror(errno));
		return -1;
	}

	return 0;
}

static void DeinitSocket(void)
{
	close(socket_fd);
	unlink(SOCKET_PATH);

	DLCSRV_LOG_DEBUG("close socket\n");
}

static int IsServerExist(void)
{
	int client_fd;
	struct stat stat_data;
	struct sockaddr_un remote_addr;

	if (stat(SOCKET_PATH, &stat_data) == -1)
	{
		if (errno != ENOENT)
		{
			perror("stat");
		}
		return 0;
	}

	if ((stat_data.st_mode & S_IFMT) == S_IFSOCK)
	{
		client_fd = socket(AF_UNIX, SOCK_STREAM, 0);
		if (client_fd >= 0)
		{
			remote_addr.sun_family = AF_UNIX;
			strncpy(remote_addr.sun_path, SOCKET_PATH, sizeof(remote_addr.sun_path) - 1);

			if (connect(client_fd, (struct sockaddr *)&remote_addr, sizeof(struct sockaddr_un)) == 0)
			{
				shutdown(client_fd, SHUT_RDWR);
				close(client_fd);

				return 1;
			}
		}
	}

	DLCSRV_LOG_DEBUG("remove old socket file\n");
	unlink(SOCKET_PATH);

	return 0;
}

static void ServerKill(void)
{
	int client_fd;
	struct sockaddr_un remote_addr;

	client_fd = socket(AF_UNIX, SOCK_STREAM, 0);
	if (client_fd == -1)
	{
		return;
	}

	remote_addr.sun_family = AF_UNIX;
	strncpy(remote_addr.sun_path, SOCKET_PATH, sizeof(remote_addr.sun_path) - 1);
	if (connect(client_fd, (struct sockaddr *)&remote_addr, sizeof(struct sockaddr_un)) == 0)
	{
		printf("send server kill command\n");

		DLCSRV_RemoteServerTerminate(client_fd);

		shutdown(client_fd, SHUT_RDWR);
		close(client_fd);
	}
}

static void PrintDrmStatus(void)
{
	int i;
	if (DLCSRV_InitDRM(DRM_DEVICE, 0) != DLCSRV_OK)
	{
		printf("DRM I/O error!\n");
		return;
	}

	printf("  drm device name: \"%s\"\n", DRM_DEVICE);

	/* connector ids */
	printf("  connector ids:\t");
	for (i = 0; i < DLCSRV_GetConnectorNum(); i++)
	{
		printf("%d ", DLCSRV_ConnectorIndexToId(i));
	}
	printf("\n");

	/* encoder ids */
	printf("  encoder ids:\t\t");
	for (i = 0; i < DLCSRV_GetEncoderNum(); i++)
	{
		printf("%d ", DLCSRV_EncoderIndexToId(i));
	}
	printf("\n");

	/* crtc ids */
	printf("  crtc ids:\t\t");
	for (i = 0; i < DLCSRV_GetCrtcNum(); i++)
	{
		printf("%d ", DLCSRV_CrtcIndexToId(i));
	}
	printf("\n");

	/* plane ids */
	printf("  plane ids:\t\t");
	for (i = 0; i < DLCSRV_GetPlaneNum(); i++)
	{
		printf("%d ", DLCSRV_PlaneIndexToId(i));
	}
	printf("\n");

	DLCSRV_DeinitDRM();
}

int main(int argc, char *argv[])
{
	int opt;
	int flag_kill_server = 0;

	openlog("dlcsrv_REL", LOG_PID, LOG_DAEMON);

	/* check option */
	while ((opt = getopt(argc, argv, "qt:")) != -1)
	{
		switch (opt)
		{
		case 'q':
			flag_kill_server = 1;
			break;
		case 't':
			timeout = atoi(optarg);
			break;
		default:
			printf("invalid command\n");
			return -1;
		}
	}

	/* Check another server running. */
	if (IsServerExist())
	{
		if (flag_kill_server)
		{
			// printf("shutdown\n");
			ServerKill();
		}
		else
		{
			printf("DRM Layer Compsitor.\n");
			PrintDrmStatus();
		}

		closelog();
		return 0;
	}

	if (flag_kill_server)
	{
		closelog();
		return 0;
	}

	/* become a daeomn */
	if (daemon(1, 0) == -1)
	{
		printf("failed to be daemon\n");
		closelog();
		return -1;
	}

	/* init DRM */
	if (DLCSRV_InitDRM(DRM_DEVICE, 1) != DLCSRV_OK)
	{
		DLCSRV_LOG_ERR("DRM init failed: exit\n");
		closelog();
		return -1;
	}

	max_client = DLCSRV_GetPlaneNum() + 1; /* plane  + control */
	clients = (DLCSRV_CLIENT **)malloc(sizeof(DLCSRV_CLIENT *) * max_client);

	/* init socket */
	if (InitSocket() == -1)
	{
		DLCSRV_LOG_ERR("socket inti failed: exit\n");
		free(clients);
		DLCSRV_DeinitDRM();
		closelog();
		return -1;
	}

	DLCSRV_LOG_INFO("start\n");

	/* command dispatch */
	while (GetNextEvent() >= 0) { }

	/* close socket */
	DeinitSocket();

	/* close DRM */
	DLCSRV_DeinitDRM();

	free(clients);

	DLCSRV_LOG_INFO("finish\n");

	closelog();

	return 0;
}
