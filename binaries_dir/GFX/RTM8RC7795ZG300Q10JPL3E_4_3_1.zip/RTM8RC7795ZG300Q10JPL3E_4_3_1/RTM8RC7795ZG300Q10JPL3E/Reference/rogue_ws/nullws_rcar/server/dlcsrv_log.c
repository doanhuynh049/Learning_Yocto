/*
 * Copyright(c) 2021 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "dlcsrv_common.h"

#if defined(SUPPORT_WSEGL_LOGGING)
#include "dlcsrv_scope.h"
#endif /* SUPPORT_WSEGL_LOGGING */


#if defined(SUPPORT_WSEGL_LOGGING)
SCOPE_HANDLE *pahScopeHandle = NULL;

/*
 * Logging function of DRM event
 */
inline void DLCSRV_DRMLog_InitScope(void)
{
	int i;

	pahScopeHandle = calloc(DLCSRV_GetCrtcNum(), sizeof(SCOPE_HANDLE));
	if (pahScopeHandle)
	{
		for (i = 0; i < DLCSRV_GetCrtcNum(); i++)
		{
			pahScopeHandle[i] = DLCScope_Acquire("DLC", "CRTC", DLCSRV_CrtcIndexToId(i), SCOPE_FALSE);
		}
	}
}

inline void DLCSRV_DRMLog_DeinitScope(void)
{
	int i;

	if (pahScopeHandle)
	{
		for (i = 0; i < DLCSRV_GetCrtcNum(); i++)
		{
			DLCScope_Release(pahScopeHandle[i]);
		}

		free(pahScopeHandle);
		pahScopeHandle = NULL;
	}
}

inline void DLCSRV_DRMLog_StartContext(unsigned int crtc_index)
{
	if (pahScopeHandle) DLCScope_StartContext(pahScopeHandle[crtc_index]);
}

inline void DLCSRV_DRMLog_StopContext(unsigned int crtc_index)
{
	if (pahScopeHandle) DLCScope_StopContext(pahScopeHandle[crtc_index]);
}

inline void DLCSRV_DRMLog_TimingBegin(unsigned int crtc_index, const char *title, unsigned int plane_id, unsigned int fb_id, bool update_frame)
{
	if (pahScopeHandle)
	{
		if (update_frame) DLCScope_UpdateFrame(pahScopeHandle[crtc_index]);
		DLCScope_TimingBegin(pahScopeHandle[crtc_index], title, plane_id, fb_id);
	}
}

inline void DLCSRV_DRMLog_TimingEnd(unsigned int crtc_index)
{
	if (pahScopeHandle) DLCScope_TimingEnd(pahScopeHandle[crtc_index]);
}

inline void DLCSRV_DRMLog_TimingVSYNC(unsigned int crtc_index)
{
	if (pahScopeHandle) DLCScope_TimingVSYNC(pahScopeHandle[crtc_index]);
}

#else

inline void DLCSRV_DRMLog_InitScope(void)
{
}

inline void DLCSRV_DRMLog_DeinitScope(void)
{
}

inline void DLCSRV_DRMLog_StartContext(unsigned int crtc_index)
{
	DLC_UNREFERENCED_PARAMETER(crtc_index);
}

inline void DLCSRV_DRMLog_StopContext(unsigned int crtc_index)
{
	DLC_UNREFERENCED_PARAMETER(crtc_index);
}

inline void DLCSRV_DRMLog_TimingBegin(unsigned int crtc_index, const char *title, unsigned int plane_id, unsigned int fb_id, bool update_frame)
{
	DLC_UNREFERENCED_PARAMETER(crtc_index);
	DLC_UNREFERENCED_PARAMETER(title);
	DLC_UNREFERENCED_PARAMETER(plane_id);
	DLC_UNREFERENCED_PARAMETER(fb_id);
	DLC_UNREFERENCED_PARAMETER(update_frame);
}

inline void DLCSRV_DRMLog_TimingEnd(unsigned int crtc_index)
{
	DLC_UNREFERENCED_PARAMETER(crtc_index);
}

inline void DLCSRV_DRMLog_TimingVSYNC(unsigned int crtc_index)
{
	DLC_UNREFERENCED_PARAMETER(crtc_index);
}

#endif /* SUPPORT_WSEGL_LOGGING */
