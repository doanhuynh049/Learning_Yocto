/****************************************************************************/
// (C) 2009-2018 Renesas Electronics Corporation. All rights reserved.
//
// OpenGL ES 3.2 sample application
//
// FILE     : OES3_Texture.cpp
// CREATED  : 2010.12.10
// MODIFIED : 2018.03.08
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : 
// HISTORY  : 
//            2010.12.10
//            - Created release code.
//            2011.02.03
//            - Added eglReleaseThread() and optimized code.
//            2012.07.05
//            - Deleted un-necessary code.
//            2015.09.18
//            - Support OpenGL ES 3.1.
//            2018.03.08
//            - Support OpenGL ES 3.2.
/****************************************************************************/
/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <pthread.h>

#include  <sys/time.h>
#include  <unistd.h>

#ifndef NULL
#define NULL (void *)0
#endif /* NULL */

#include "GLES3/gl32.h"
#include "GLES3/gl2ext.h"
#include "EGL/egl.h"

#include "vertices.h"       // vertex data
#include "texture.h"        // texture data
#include "RTMatrix.h"

/****************************************************************************
 *  DECLARATIONS
 ****************************************************************************/
void InitApplication(void);
void RenderScene(void);
void CreateTexture(void);
void ChangeCurrent(void);
void InitShader(void);
void SetupGLSLUniform(void);
void DrawIndexStrips(void);
void *RenderThread(void *lpParameter);
void AppTerminate(void);

/****************************************************************************
 *  GLOBALS
 ****************************************************************************/

int		g_nScreenWidth;
int		g_nScreenHeight;

pthread_t	g_hRenderThread;
int		g_hThreadTerminateEvent;

EGLDisplay	dpy;
EGLSurface	surface;
EGLContext	context;

GLuint		g_uiProgramObject;
GLuint		g_hTexture;
GLuint		g_uiFragShader, g_uiVertShader;

const char	c_szVertShaderBinFile[]  = "./OES3_VertShaderSample.vsc";  // VertexShader file
const char	c_szFragShaderBinFile[]  = "./OES3_FragShaderSample.fsc";  // FragmentShader file
const char	c_szVertShaderSrcFile[]  = "./OES3_VertShaderSample.vsh";  // VertexShader file
const char	c_szFragShaderSrcFile[]  = "./OES3_FragShaderSample.fsh";  // FragmentShader file

/****************************************************************************
 *  DEFINES
 ****************************************************************************/

#define VERTEX_ARRAY		0
#define NORMAL_ARRAY		1
#define UV1_ARRAY			2
#define DIFFUSE_ARRAY		3

/***********************************************************************************
 Function Name      : MainThread()
 Description        : The Main Thread
 ************************************************************************************/
void *MainThread(void *pParam)
{
	int loop = 60;

	printf("main start.\n");
	
	while(loop--)
	{
		usleep(1000 * 1000);
	}

	printf("main terminate.\n");
	
	g_hThreadTerminateEvent = 0;

	return pParam;
}

/*******************************************************************************
 * Function Name  : InitApplication
 * Description    : Beginning process.
 *******************************************************************************/
void InitApplication( void )
{
	EGLBoolean eRetStatus;

	eRetStatus = eglMakeCurrent(dpy, surface, surface, context);
	if (eRetStatus != EGL_TRUE)
	{
		printf("eglMakeCurrent failed.\n");
	}

	// Create texture
	CreateTexture( );

	InitShader( );

	glClearColor( 0.5f, 0.5f, 0.5f, 1.0f );
	glViewport( 0, 0, g_nScreenWidth, g_nScreenHeight );
}

/*******************************************************************************
 * Function Name  : RenderScene
 * Description    : Drawing process.
 *******************************************************************************/
void RenderScene( void )
{
	static int nCount = 1, nColor = 0;

	if ( ( nCount % 200 ) == 0 )
	{
		nColor++;
		nColor %= 3;
	}

	nCount++;

	switch( nColor )
	{
	case 0: // Red.
		glClearColor( 0.5f, 0.0f, 0.0f, 1.0f );
	break;
	case 1: // Green.
		glClearColor( 0.0f, 0.5f, 0.0f, 1.0f );
	break;
	case 2: // Blue.
		glClearColor( 0.0f, 0.0f, 0.5f, 1.0f );
	break;
	default:
		glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
	}

	// Beginning of scene
	glClear( GL_COLOR_BUFFER_BIT );
	glEnable( GL_CULL_FACE );

	// Current change
	ChangeCurrent( );

	SetupGLSLUniform( );
	glUseProgram( g_uiProgramObject );

	DrawIndexStrips( );
}

/*******************************************************************************
 * Function Name  : CreateTexture
 * Description    : Create texture.
 *******************************************************************************/
void CreateTexture( void )
{

	unsigned int	*pTex;

	// Get texture handle
	glGenTextures( 1,&g_hTexture );
	glBindTexture( GL_TEXTURE_2D, g_hTexture );

	// Create texture area
	// Set texture data to the area
	pTex = const_cast<unsigned int *>((texture + (texture[0] / sizeof(unsigned int))));
	glTexImage2D( GL_TEXTURE_2D , 0 , GL_RGBA , texture[2] , texture[1] ,0 , GL_RGBA , GL_UNSIGNED_BYTE , pTex );

	{
		GLint glerr = glGetError();
		if(glerr) printf("<ERROR name=\"CreateTexture\" glerr=\"0x%x\"/>\n", glerr);
	}
}

/*******************************************************************************
 * Function Name  : ChangeCurrent
 * Description    : Chage current status.
 *******************************************************************************/
void ChangeCurrent( void )
{
	// Set drawing texture
	glActiveTexture( GL_TEXTURE0 );
	glBindTexture( GL_TEXTURE_2D, g_hTexture );

	glUniform1i( glGetUniformLocation( g_uiProgramObject, "sampler2d"), 0 );

	// Set texture quality
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glUniform1i( glGetUniformLocation( g_uiProgramObject, "uTexFlag"), 1 );
}

/*******************************************************************************
 * Function Name  : SetupGLSLUniform
 * Description    : Set all uniform constants.
 *******************************************************************************/
void SetupGLSLUniform( void )
{
	static float fTheta = 0.0f;
	float		fAngle = 1.0f;
	RTMATRIX	ModelMatrix,ViewMatrix,ProjectionMatrix, MVMatrix, PMVMatrix;
	RTVECTOR3	CameraPosition = { 3.0f, -1.3f, 0.0f };
	RTVECTOR3	CameraPointing = { 0.0f,  1.1f, 0.0f };
	RTVECTOR3	UpVector       = { 0.0f, 1.0f, 0.0f };
	float		fFOVHoriz      = 60.0f * PI / 180.0f;    // Default : 60.0 [degree].
	float		fAspectRatio   = (float)g_nScreenWidth / (float)g_nScreenHeight;

	fTheta -= ( fAngle / 180.0f ) * PI;

	RTMatrixIdentity( ModelMatrix );
	RTMatrixIdentity( ViewMatrix );
	RTMatrixIdentity( ProjectionMatrix );
	RTMatrixRotationY( ModelMatrix, fTheta );

	RTMatrixPerspective( ProjectionMatrix, fFOVHoriz, fAspectRatio, 0.1f, 1000.0f );
	RTMatrixLookAt( ViewMatrix, CameraPosition, CameraPointing, UpVector );

	RTMatrixMultiply( MVMatrix, ModelMatrix, ViewMatrix );
	RTMatrixMultiply( PMVMatrix, MVMatrix, ProjectionMatrix );

	int i32Location = glGetUniformLocation( g_uiProgramObject, "uPMVMatrix" );
	glUniformMatrix4fv( i32Location, 1, GL_FALSE, PMVMatrix.f );
}

/*******************************************************************************
 * Function Name    : DrawIndexStrips
 * Description      : Renders strips of triangles using indexed vertices
 *******************************************************************************/
void DrawIndexStrips( void )
{
	float colors[NUMBER_OF_INDEXED_VERTICES*4];

	for ( int i = 0; i < NUMBER_OF_INDEXED_VERTICES; i++ )
	{
		colors[i*4+0] = 1.0f;   colors[i*4+1] = 1.0f;
		colors[i*4+2] = 1.0f;   colors[i*4+3] = 1.0f;
	}

	glEnableVertexAttribArray( VERTEX_ARRAY );
	glEnableVertexAttribArray( NORMAL_ARRAY );
	glEnableVertexAttribArray( UV1_ARRAY );
	glEnableVertexAttribArray( DIFFUSE_ARRAY );

	glVertexAttribPointer( VERTEX_ARRAY,  3, GL_FLOAT, GL_FALSE, 0, Vertices );
	glVertexAttribPointer( NORMAL_ARRAY,  3, GL_FLOAT, GL_FALSE, 0, Normals );
	glVertexAttribPointer( UV1_ARRAY,     2, GL_FLOAT, GL_FALSE, 0, UVs );
	glVertexAttribPointer( DIFFUSE_ARRAY, 4, GL_FLOAT, GL_FALSE, 0, colors );

	glDrawElements( GL_TRIANGLES, NUMBER_OF_INDEXED_STRIPS*3, GL_UNSIGNED_SHORT, uIndexedStripsArray );

	glDisableVertexAttribArray( VERTEX_ARRAY );
	glDisableVertexAttribArray( NORMAL_ARRAY );
	glDisableVertexAttribArray( UV1_ARRAY );
	glDisableVertexAttribArray( DIFFUSE_ARRAY );
}

/*******************************************************************************
 * Function Name  : LoadShader
 * Description    : Loading of shader files.
 *******************************************************************************/
void LoadShader(const char* shader_path, const char* &m_pData, GLint &m_Size)
{
	bool m_bOpen;

	FILE* pFile = fopen(shader_path, "rb");
	if (pFile)
	{
		// Get the file size
		fseek(pFile, 0, SEEK_END);
		m_Size = ftell(pFile);
		fseek(pFile, 0, SEEK_SET);

		// read the data, append a 0 byte as the data might represent a string
		char* pData = new char[m_Size + 1];
		pData[m_Size] = '\0';
		size_t BytesRead = fread(pData, 1, m_Size, pFile);

		if (BytesRead != m_Size)
		{
			delete [] pData;
			m_Size = 0;
		}
		else
		{
			m_pData = pData;
			m_bOpen = true;
		}
		fclose(pFile);

	}
	else
	{
		m_Size = 0;
	}
}

/*******************************************************************************
 * Function Name  : InitShader
 * Description    : Initialization of shader.
 *******************************************************************************/
void InitShader( void )
{
	g_uiProgramObject = glCreateProgram( );
	g_uiVertShader = glCreateShader( GL_VERTEX_SHADER );
	g_uiFragShader = glCreateShader( GL_FRAGMENT_SHADER );

	GLint       m_Size;
	const char* m_pData;

	LoadShader(c_szVertShaderBinFile, m_pData, m_Size);
	if (m_Size > 0)
	{
		glShaderBinary( 1, &g_uiVertShader, GL_SGX_BINARY_IMG, m_pData, m_Size);
	}
	else
	{
		LoadShader(c_szVertShaderSrcFile, m_pData, m_Size);
		if ( m_Size > 0)
		{
			GLint glerr;

			glShaderSource( g_uiVertShader, 1, &m_pData, NULL);

			glCompileShader(g_uiVertShader);
			glerr = glGetError();
			if(glerr) printf("<ERROR name=\"InitShader\" call=\"glShaderSource\" type=\"VertShader\" glerr=\"0x%x\"/>\n", glerr);
		}
		else
		{
			printf("File Open failed. The vsc or vsh file is needed.\n");
		}
	}

	LoadShader(c_szFragShaderBinFile, m_pData, m_Size);
	if (m_Size > 0)
	{
		glShaderBinary( 1, &g_uiFragShader, GL_SGX_BINARY_IMG, m_pData, m_Size);
	}
	else
	{
		LoadShader(c_szFragShaderSrcFile, m_pData, m_Size);
		if (m_Size > 0)
		{
			GLint glerr;

			glShaderSource( g_uiFragShader, 1, &m_pData, NULL);

			glCompileShader(g_uiFragShader);
			glerr = glGetError();
			if(glerr) printf("<ERROR name=\"InitShader\" call=\"glShaderSource\" type=\"FragShader\" glerr=\"0x%x\"/>\n", glerr);
		}
		else
		{
			printf("File Open failed. The fsc or fsh file is needed.\n");
		}
	}

	glAttachShader( g_uiProgramObject, g_uiVertShader );
	glAttachShader( g_uiProgramObject, g_uiFragShader );

	glBindAttribLocation( g_uiProgramObject, VERTEX_ARRAY,  "aVertex"  );
	glBindAttribLocation( g_uiProgramObject, NORMAL_ARRAY,  "aNormal"  );
	glBindAttribLocation( g_uiProgramObject, UV1_ARRAY,     "aUv1"     );
	glBindAttribLocation( g_uiProgramObject, DIFFUSE_ARRAY, "aDiffuse" );

	glLinkProgram( g_uiProgramObject );
	glUseProgram( g_uiProgramObject );
	
	{
		GLint glerr = glGetError();
		if(glerr) printf("<ERROR name=\"InitShader\" glerr=\"0x%x\"/>\n", glerr);
	}
}

/*******************************************************************************
 * Function Name  : WinMain()
 * Description    : Initialization, message loop
 *******************************************************************************/
int main(int argc, char** argv)
{
	EGLConfig configs[2];
	EGLBoolean eRetStatus;
	EGLint config_count;
	EGLint major, minor;
	EGLint cfg_attribs[] = {EGL_BUFFER_SIZE,     16, /* RGB565 */
				EGL_DEPTH_SIZE,      8,
				EGL_SURFACE_TYPE,    EGL_WINDOW_BIT,
				EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
				EGL_NONE};

	NativeWindowType eglWindow = 0;

	pthread_t tid_window;

	dpy = eglGetDisplay((NativeDisplayType)EGL_DEFAULT_DISPLAY);
	if(dpy == EGL_NO_DISPLAY)
	{
		printf("eglGetDisplay failed.\n");
	}

	eRetStatus = eglInitialize(dpy, &major, &minor);
	if (eRetStatus != EGL_TRUE)
	{
		printf("eglInitialize failed.\n");
	}

	eRetStatus = eglBindAPI(EGL_OPENGL_ES_API);
	if (eRetStatus != EGL_TRUE)
	{
		printf("eglBindAPI failed.\n");
	}

	eRetStatus = eglChooseConfig(dpy, cfg_attribs, configs, 2, &config_count);
	if (eRetStatus != EGL_TRUE)
	{
		printf("eglChooseConfig failed.\n");
	}

	surface = eglCreateWindowSurface(dpy, configs[0], eglWindow, NULL);
	if (surface == EGL_NO_SURFACE)
	{
		printf("eglCreateWindowSurface failed.\n");
	}

	EGLint ai32ContextAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
	context = eglCreateContext(dpy, configs[0], EGL_NO_CONTEXT, ai32ContextAttribs);
	if (context == EGL_NO_CONTEXT)
	{
		printf("eglCreateContext failed.\n");
	}

	// Get screen width and height
	eRetStatus = eglQuerySurface(dpy, surface, EGL_WIDTH, &g_nScreenWidth);
	if (eRetStatus != EGL_TRUE)
	{
		printf("eglQuerySurface failed.\n");
	}
	
	eRetStatus = eglQuerySurface(dpy, surface, EGL_HEIGHT, &g_nScreenHeight);
	if (eRetStatus != EGL_TRUE)
	{
		printf("eglQuerySurface failed.\n");
	}

	g_hThreadTerminateEvent = 1;
	
	pthread_create(&tid_window, NULL, MainThread, NULL);
	pthread_create(&g_hRenderThread, NULL, RenderThread, NULL);

	pthread_join(tid_window, NULL);
	pthread_join(g_hRenderThread, NULL);

	eglDestroyContext(dpy, context);
	eglDestroySurface(dpy, surface);

	eglTerminate(dpy);

	printf("Application terminate.\n");

	return 0;

}

/***********************************************************************************
 * Function Name  : RenderThread()
 * Description    : Rendering Thread
 ************************************************************************************/
void *RenderThread(void *lpParameter)
{
	printf("thread start.\n");

	InitApplication();

	while(g_hThreadTerminateEvent){
		RenderScene();
		eglSwapBuffers(dpy, surface);
	}

	AppTerminate();

	printf("thread exit.\n");

	return lpParameter;
}

/***********************************************************************************
 * Function Name  : AppTerminate()
 * Description    : Terminate Process
 ************************************************************************************/
void AppTerminate(void)
{
	eglSwapBuffers(dpy, surface);
	glDeleteTextures(1, &g_hTexture);

	eglMakeCurrent(dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
	eglReleaseThread();
}
