/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server
 *
 *      DUMB buffer access functions
 */
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>

#include "dlcsrv_common.h"

extern int drmFd;

static inline void AddBufferInfo(DLCSRV_CLIENT *client, unsigned int gem_handle, unsigned int fb_id)
{
	DLCSRV_BUFFER *new_buffer;

	new_buffer = (DLCSRV_BUFFER *)malloc(sizeof(DLCSRV_BUFFER));

	new_buffer->gem_handle = gem_handle;
	new_buffer->fb_id = fb_id;

	new_buffer->next = client->buffers;

	client->buffers = new_buffer;
}

static inline void DelBufferInfo(DLCSRV_CLIENT *client, unsigned int gem_handle, unsigned int fb_id)
{
	DLCSRV_BUFFER *current_buffer;
	DLCSRV_BUFFER *del_buffer = NULL;

	current_buffer = client->buffers;

	while(current_buffer)
	{
		del_buffer = current_buffer;
		current_buffer = current_buffer->next;

		if ((del_buffer->gem_handle == gem_handle) &&
			(del_buffer->fb_id == fb_id))
		{
			free(del_buffer);
			break;
		}
	}

	if (client->buffers == del_buffer)
	{
		client->buffers = NULL;
	}
}

DLC_STATUS DLCSRV_SubAllocBuffer(DLCSRV_CLIENT *client,
					unsigned int flink_name,
					unsigned int width,
					unsigned int height,
					unsigned int format,
					unsigned int pitch,
					unsigned int *gem_handle,
					unsigned int *fb_id)
{
	struct drm_gem_open gem_open;
	unsigned int bo_handles[4];
	unsigned int bo_pitches[4];
	unsigned int bo_offsets[4];

	memset(bo_handles, 0, sizeof(unsigned int) * 4);
	memset(bo_pitches, 0, sizeof(unsigned int) * 4);
	memset(bo_offsets, 0, sizeof(unsigned int) * 4);

	gem_open.name = flink_name;
	if (drmIoctl(drmFd, DRM_IOCTL_GEM_OPEN, &gem_open))
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	bo_handles[0] = gem_open.handle;
	bo_pitches[0] = pitch;
	if (drmModeAddFB2(drmFd, width, height, format,
				bo_handles, bo_pitches, bo_offsets, fb_id, 0))
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	*gem_handle = gem_open.handle;

	AddBufferInfo(client, *gem_handle, *fb_id);

	return DLC_STS_OK;
}

DLC_STATUS DLCSRV_SubFreeBuffer(DLCSRV_CLIENT *client, unsigned int gem_handle, unsigned int fb_id)
{
	struct drm_gem_close gem_close;

	DelBufferInfo(client, gem_handle, fb_id);

	drmModeRmFB(drmFd, fb_id);

	gem_close.handle = gem_handle;
	drmIoctl(drmFd, DRM_IOCTL_GEM_CLOSE, &gem_close);

	return DLC_STS_OK;
}

DLC_STATUS DLCSRV_SubFreeBufferAll(DLCSRV_CLIENT *client)
{
	DLCSRV_BUFFER *del_buffer;
	struct drm_gem_close gem_close;

	while(client->buffers)
	{
		del_buffer = client->buffers;
		client->buffers = del_buffer->next;

		drmModeRmFB(drmFd, del_buffer->fb_id);

		gem_close.handle = del_buffer->gem_handle;
		drmIoctl(drmFd, DRM_IOCTL_GEM_CLOSE, &gem_close);

		free(del_buffer);
	}

	return DLC_STS_OK;
}

