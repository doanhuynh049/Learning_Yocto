/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server
 *
 *	Transport commands/messages
 */
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <pthread.h>

#include "dlcsrv_common.h"

extern drmModeRes *mode_res;

static int RecieveMessage(int client_fd, void *data, int len)
{
	struct msghdr msg = {0};
	struct iovec iov_data;

	msg.msg_name = NULL;
	msg.msg_flags = 0;

	iov_data.iov_base = data;
	iov_data.iov_len = len;

	msg.msg_iov = &iov_data;
	msg.msg_iovlen = 1;

	return recvmsg(client_fd, &msg, 0);
}

static int SendMessage(int client_fd, void *data, int len)
{
	struct msghdr msg = {0};
	int ret;
	struct iovec iov_data;

	msg.msg_name = NULL;
	msg.msg_flags = 0;

	iov_data.iov_base = data;
	iov_data.iov_len = len;

	msg.msg_iov = &iov_data;
	msg.msg_iovlen = 1;

	ret = sendmsg(client_fd, &msg, MSG_NOSIGNAL);
	if (ret == -1)
	{
		DLCSRV_LOG_ERR("client(%d): %s\n", client_fd, strerror(errno));
		return -1;
	}

	return 0;
}

#define CMD_STR(x)	#x

static DLC_STATUS ValidateMessage(DLC_CMD_HEADER *hdr, DLC_COMMANDS cmd,
					unsigned int cmd_len, char *cmd_str)
{
	DLC_STATUS eStatus = DLC_STS_OK;

	if ((hdr->cmd != cmd) || (hdr->len != cmd_len))
	{
		DLCSRV_LOG_ERR("%s: bad data (cmd = %d, len = %d)\n", cmd_str, hdr->cmd, hdr->len);

		eStatus = DLCSRV_ERROR_INVALID_PARAMS;
	}
	else if ((hdr->major_v != DLC_VER_MAJOR) || (hdr->minor_v != DLC_VER_MINOR))
	{
		DLCSRV_LOG_ERR("client (pid: %d): version mismatch\n", hdr->pid);

		eStatus = DLC_STS_VERSION_MISMATCH;
	}

	return eStatus;
}

/*
 * NOP
 */
static DLCSRV_RESULT DLCSRV_CmdNop(int client_fd)
{
	struct { DLC_CMD_HEADER hdr; } in_msg;
	struct { DLC_RESP_HEADER hdr; } out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_NOP, sizeof(in_msg), CMD_STR(DLC_CMD_NOP));

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_NOP;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

/*
 * Connector
 */
static DLCSRV_RESULT DLCSRV_CmdGetDpmsMode(int client_fd)
{
	DLC_MSG_GET_DPMS_MODE in_msg;
	DLC_RESP_DPMS_MODE out_msg;

	unsigned int dpms_id;
	unsigned int dpms_mode = 0;
	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_GET_DPMS_MODE, sizeof(in_msg), CMD_STR(DLC_CMD_GET_DPMS_MODE));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubGetDpmsId(in_msg.connector_index, &dpms_id);
		if (eStatus == DLC_STS_OK)
		{
			eStatus = DLCSRV_SubGetDpmsMode(dpms_id, &dpms_mode);
		}
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_GET_DPMS_MODE;
	out_msg.hdr.status = eStatus;
	out_msg.dpms_mode = dpms_mode;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdSetDpmsMode(int client_fd)
{
	DLC_MSG_SET_DPMS_MODE in_msg;
	DLC_RESP_DPMS_MODE out_msg;

	unsigned int dpms_id;
	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_SET_DPMS_MODE, sizeof(in_msg), CMD_STR(DLC_CMD_SET_DPMS_MODE));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubGetDpmsId(in_msg.connector_index, &dpms_id);
		if (eStatus == DLC_STS_OK)
		{
			eStatus = DLCSRV_SubSetDpmsMode(in_msg.connector_index, dpms_id, in_msg.dpms_mode);
		}
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_SET_DPMS_MODE;
	out_msg.hdr.status = eStatus;
	out_msg.dpms_mode = in_msg.dpms_mode;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdAllocBuffer(DLCSRV_CLIENT *client)
{
	DLC_MSG_ALLOC_BUFFER in_msg;
	DLC_RESP_ALLOC_BUFFER out_msg;

	DLC_STATUS eStatus;
	unsigned int gem_handle;
	unsigned int fb_id = 0;

	/* Recive command */
	RecieveMessage(client->client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_ALLOC_BUFFER, sizeof(in_msg), CMD_STR(DLC_CMD_ALLOC_BUFFER));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubAllocBuffer(client,
								in_msg.flink_name,
								in_msg.width,
								in_msg.height,
								in_msg.format,
								in_msg.pitch,
								&gem_handle,
								&fb_id);
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_ALLOC_BUFFER;
	out_msg.hdr.status = eStatus;
	out_msg.gem_handle = gem_handle;
	out_msg.fb_id = fb_id;
	SendMessage(client->client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdFreeBuffer(DLCSRV_CLIENT *client)
{
	DLC_MSG_FREE_BUFFER in_msg;
	DLC_RESP_FREE_BUFFER out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client->client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_FREE_BUFFER, sizeof(in_msg), CMD_STR(DLC_CMD_FREE_BUFFER));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubFreeBuffer(client, in_msg.gem_handle, in_msg.fb_id);
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_FREE_BUFFER;
	out_msg.hdr.status = eStatus;
	SendMessage(client->client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

/*
 * CRTC
 */

static DLCSRV_RESULT DLCSRV_CmdAcquireDesktop(int client_fd)
{
	DLC_MSG_ACQUIRE_DESKTOP in_msg;
	DLC_RESP_ACQUIRE_DESKTOP out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_ACQUIRE_DESKTOP, sizeof(in_msg), CMD_STR(DLC_CMD_ACQUIRE_DESKTOP));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubAcquireDesktop(in_msg.crtc_index, in_msg.buffers);
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_ACQUIRE_DESKTOP;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdReleaseDesktop(int client_fd)
{
	DLC_MSG_RELEASE_PLANE in_msg;
	DLC_RESP_RELEASE_PLANE out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_RELEASE_DESKTOP, sizeof(in_msg), CMD_STR(DLC_CMD_RELEASE_DESKTOP));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubReleaseDesktop(in_msg.plane_index);
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_RELEASE_DESKTOP;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdSetMode(int client_fd)
{
	DLC_MSG_SET_CRTC_MODE in_msg;
	DLC_RESP_CRTC_MODE out_msg;

	DLC_STATUS eStatus;
	unsigned int width = 0;
	unsigned int height = 0;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_SET_MODE, sizeof(in_msg), CMD_STR(DLC_CMD_SET_MODE));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubSetMode(in_msg.crtc_index,
						in_msg.connector_index,
						in_msg.fb_id,
						in_msg.hdisplay, in_msg.vdisplay,
						in_msg.src_x, in_msg.src_y);
		if (eStatus == DLC_STS_OK)
		{
			eStatus = DLCSRV_SubGetMode(in_msg.crtc_index, &width, &height);
		}
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_SET_MODE;
	out_msg.hdr.status = eStatus;
	out_msg.hdisplay = width;
	out_msg.vdisplay = height;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdPageFlip(int client_fd)
{
	DLC_MSG_PAGE_FLIP in_msg;
	DLC_RESP_PAGE_FLIP out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_PAGE_FLIP, sizeof(in_msg), CMD_STR(DLC_CMD_PAGE_FLIP));
	if (eStatus == DLC_STS_OK)
	{
		if (in_msg.interval == 0)
		{
			eStatus = DLCSRV_SubPageFlip(in_msg.crtc_index, in_msg.fb_id);
		}
		else
		{
			eStatus = DLCSRV_SubAddSetDesktopQueue(client_fd,
								in_msg.crtc_index, in_msg.fb_id,
								in_msg.interval);
		}
	}

	if ((in_msg.interval == 0) || (eStatus != DLC_STS_OK))
	{
		/* Send response */
		out_msg.hdr.cmd = DLC_CMD_PAGE_FLIP;
		out_msg.hdr.status = eStatus;
		SendMessage(client_fd, &out_msg, sizeof(out_msg));
	}

	return DLCSRV_OK;
}

DLCSRV_RESULT DLCSRV_RespPageFlipComplete(int client_fd)
{
	DLC_RESP_PLANE_INFO out_msg;

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_PAGE_FLIP;
	out_msg.hdr.status = DLCSRV_OK;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

/*
 * Plane
 */
static DLCSRV_RESULT DLCSRV_CmdAcquirePlane(int client_fd)
{
	DLC_MSG_ACQUIRE_PLANE in_msg;
	DLC_RESP_ACQUIRE_PLANE out_msg;

	int plane_index = 0;
	unsigned int plane_id = 0;
	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_ACQUIRE_PLANE, sizeof(in_msg), CMD_STR(DLC_CMD_ACQUIRE_PLANE));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubAcquirePlane(in_msg.crtc_index, in_msg.buffers, &plane_index, &plane_id);
	}

	if (eStatus != DLC_STS_OK)
	{
		DLCSRV_SubAcquireDesktop(in_msg.crtc_index, in_msg.buffers);
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_ACQUIRE_PLANE;
	out_msg.hdr.status = eStatus;
	out_msg.plane_index = plane_index;
	out_msg.plane_id = plane_id;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdReleasePlane(int client_fd)
{
	DLC_MSG_RELEASE_PLANE in_msg;
	DLC_RESP_RELEASE_PLANE out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_RELEASE_PLANE, sizeof(in_msg), CMD_STR(DLC_CMD_RELEASE_PLANE));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubReleasePlane(in_msg.plane_index);
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_RELEASE_PLANE;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdGetPlaneProperty(int client_fd)
{
	DLC_MSG_PLANE_PROPERTY in_msg;
	DLC_RESP_PLANE_PROPERTY out_msg;

	unsigned int value = 0;
	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_GET_PLANE_PROPERTY, sizeof(in_msg), CMD_STR(DLC_CMD_GET_PLANE_PROPERTY));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubGetPlaneProperty(in_msg.plane_index, in_msg.property, &value);
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_GET_PLANE_PROPERTY;
	out_msg.hdr.status = eStatus;
	out_msg.property = in_msg.property;
	out_msg.value = value;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdSetPlaneProperty(int client_fd)
{
	DLC_MSG_PLANE_PROPERTY in_msg;
	DLC_RESP_PLANE_PROPERTY out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_SET_PLANE_PROPERTY, sizeof(in_msg), CMD_STR(DLC_CMD_SET_PLANE_PROPERTY));
	if (eStatus == DLC_STS_OK)
	{
		eStatus = DLCSRV_SubSetPlaneProperty(in_msg.plane_index, in_msg.property, in_msg.value);
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_SET_PLANE_PROPERTY;
	out_msg.hdr.status = eStatus;
	out_msg.property = in_msg.property;
	out_msg.value = in_msg.value;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}


static DLCSRV_RESULT DLCSRV_CmdDrmModeSetPlane(int client_fd)
{
	DLC_MSG_PLANE_INFO in_msg;
	DLC_RESP_PLANE_INFO out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_SET_PLANE, sizeof(in_msg), CMD_STR(DLC_CMD_SET_PLANE));
	if (eStatus == DLC_STS_OK)
	{
		if (in_msg.interval == 0)
		{
			eStatus = DLCSRV_SubSetPlane(in_msg.plane_index, in_msg.crtc_index, in_msg.fb_id,
						in_msg.disp.x, in_msg.disp.y,
						in_msg.disp.w, in_msg.disp.h,
						in_msg.src.x, in_msg.src.y,
						in_msg.src.w, in_msg.src.h);
		}
		else
		{
			/* add setplane queue (delayed setplane and respose) */
			eStatus = DLCSRV_SubAddSetPlaneQueue(client_fd,
								in_msg.plane_index, in_msg.fb_id,
								in_msg.disp.x, in_msg.disp.y,
								in_msg.disp.w, in_msg.disp.h,
								in_msg.src.x, in_msg.src.y,
								in_msg.src.w, in_msg.src.h,
								in_msg.interval);
		}
	}

	if ((in_msg.interval == 0) || (eStatus != DLC_STS_OK))
	{
		/* Send response */
		out_msg.hdr.cmd = DLC_CMD_SET_PLANE;
		out_msg.hdr.status = eStatus;
		SendMessage(client_fd, &out_msg, sizeof(out_msg));
	}

	return DLCSRV_OK;
}

DLCSRV_RESULT DLCSRV_RespDrmModeSetPlaneComplete(int client_fd)
{
	DLC_RESP_PLANE_INFO out_msg;

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_SET_PLANE;
	out_msg.hdr.status = DLCSRV_OK;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}


/*
 * PVR DC module control
 */
static DLCSRV_RESULT DLCSRV_CmdDrmAcquireDeviceDC(int client_fd)
{
	DLC_MSG_ACQUIRE_DEVICE_DC in_msg;
	DLC_RESP_ACQUIRE_DEVICE_DC out_msg;

	DLC_STATUS eStatus;
	unsigned int dc_devid = 0;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = DLC_STS_NOT_SUPPORTED;

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_ACQUIRE_DEVICE_DC;
	out_msg.hdr.status = eStatus;
	out_msg.dc_devid = dc_devid;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdDrmReleaseDeviceDC(int client_fd)
{
	DLC_MSG_RELEASE_DEVICE_DC in_msg;
	DLC_RESP_RELEASE_DEVICE_DC out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = DLC_STS_NOT_SUPPORTED;

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_RELEASE_DEVICE_DC;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdDrmModeSetPlaneDC(int client_fd)
{
	DLC_MSG_PLANE_INFO in_msg;
	DLC_RESP_PLANE_INFO out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = DLC_STS_NOT_SUPPORTED;

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_SET_PLANE_DC;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdPageFlipDC(int client_fd)
{
	DLC_MSG_PAGE_FLIP in_msg;
	DLC_RESP_PAGE_FLIP out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = DLC_STS_NOT_SUPPORTED;

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_PAGE_FLIP_DC;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}


/*
 * DRM-Master commands
 */
static DLCSRV_RESULT DLCSRV_CmdDrmSetMaster(int client_fd)
{
	DLC_MSG_DRM_MASTER in_msg;
	DLC_RESP_DRM_MASTER out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_DRM_SET_MASTER, sizeof(in_msg), CMD_STR(DLC_CMD_DRM_SET_MASTER));
	if (eStatus == DLC_STS_OK)
	{
		if (DLCSRV_SetMaster() != DLCSRV_OK)
		{
			eStatus = DLC_STS_NOT_A_MASTER;
		}
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_DRM_SET_MASTER;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdDrmDropMaster(int client_fd)
{
	DLC_MSG_DRM_MASTER in_msg;
	DLC_RESP_DRM_MASTER out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_DRM_DROP_MASTER, sizeof(in_msg), CMD_STR(DLC_CMD_DRM_DROP_MASTER));
	if (eStatus == DLC_STS_OK)
	{
		DLCSRV_DropMaster();
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_DRM_DROP_MASTER;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

static DLCSRV_RESULT DLCSRV_CmdDrmAuthMagic(int client_fd)
{
	DLC_MSG_DRM_AUTH_MAGIC in_msg;
	DLC_RESP_DRM_AUTH_MAGIC out_msg;

	DLC_STATUS eStatus;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_DRM_AUTH_MAGIC, sizeof(in_msg), CMD_STR(DLC_CMD_DRM_AUTH_MAGIC));
	if (eStatus == DLC_STS_OK)
	{
		if (DLCSRV_AuthMagic(in_msg.magic) != DLCSRV_OK)
		{
			eStatus = DLC_STS_NOT_A_MASTER;
		}
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_DRM_AUTH_MAGIC;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}


/*
 * Server Control
 */

DLCSRV_RESULT DLCSRV_CmdServerTerminate(int client_fd)
{
	DLCSRV_MSG_TERMINATE in_msg;
	DLCSRV_RESP_TERMINATE out_msg;

	DLC_STATUS eStatus;
	int i;

	/* Recive command */
	RecieveMessage(client_fd, &in_msg, sizeof(in_msg));

	eStatus = ValidateMessage(&in_msg.hdr, DLC_CMD_TERMINATE, sizeof(in_msg), CMD_STR(DLC_CMD_TERMINATE));
	if (eStatus == DLC_STS_OK)
	{

		// flush all queue


		/* disable all desktop plane */
		for (i = 0; i < DLCSRV_GetCrtcNum(); i++)
		{
			/* hide desktop plane */
			DLCSRV_SubDisableDesktop(i);
		}

		/* disable all plane */
		for (i = 0; i < DLCSRV_GetPlaneNum(); i++)
		{
			DLCSRV_SubDisablePlane(i);
		}
	}

	/* Send response */
	out_msg.hdr.cmd = DLC_CMD_TERMINATE;
	out_msg.hdr.status = eStatus;
	SendMessage(client_fd, &out_msg, sizeof(out_msg));

	return DLCSRV_OK;
}

/*
 */
DLC_COMMANDS DLCSRV_CheckCommand(int client_fd)
{
	DLC_COMMANDS recv_cmd;
	int ret;

	/* peek a command */
	ret = recv(client_fd, &recv_cmd, sizeof(recv_cmd), MSG_PEEK | MSG_WAITALL);
	if (ret == -1)
	{
		DLCSRV_LOG_ERR("client(%d) error: %s\n", client_fd, strerror(errno));

		return DLC_CMD_DISCONNECT;
	}
	else if (ret == 0)
	{
		return DLC_CMD_DISCONNECT;
	}
	else if (ret == sizeof(recv_cmd))
	{
		/* regular commands */
		DLCSRV_LOG_DEBUG("command = %d\n", recv_cmd);
	}

	return recv_cmd;
}


/*
 * Remote Commands (as client)
 */
DLCSRV_RESULT DLCSRV_RemoteServerTerminate(int socket_fd)
{
	DLCSRV_MSG_TERMINATE out_msg;
	DLCSRV_RESP_TERMINATE in_msg;

	/* Send TERMINATE command */
	out_msg.hdr.cmd = DLC_CMD_TERMINATE;
	out_msg.hdr.len = sizeof(out_msg);
	out_msg.hdr.major_v = DLC_VER_MAJOR;
	out_msg.hdr.minor_v = DLC_VER_MINOR;
	out_msg.hdr.pid = getpid();
	SendMessage(socket_fd, &out_msg, sizeof(out_msg));

	/* Wait a server response */
	RecieveMessage(socket_fd, &in_msg, sizeof(in_msg));
	if (in_msg.hdr.cmd != DLC_CMD_TERMINATE)
	{
		printf("DLC_CMD_TERMINATE: command mismatch\n");
		return DLCSRV_ERROR_COMMAND_MISMATCH;
	}
	if (in_msg.hdr.status != DLC_STS_OK)
	{
		printf("DLC_CMD_TERMINATE: fail\n");
		return DLCSRV_ERROR_INVALID_PARAMS;
	}

	return DLCSRV_OK;
}

/*
 * Command Displatch
 */
void *DLCSRV_CommandThread(void *arg)
{
	DLCSRV_CLIENT *client = (DLCSRV_CLIENT *)arg;
	fd_set read_fds;
	int ret;

	DLCSRV_LOG_DEBUG("client(%d): thread start\n", client->client_fd);

	while (client->terminate == 0)
	{
		FD_ZERO(&read_fds);
		FD_SET(client->client_fd, &read_fds);

		ret = select(client->client_fd + 1, &read_fds, NULL, NULL, NULL);
		if (ret == -1)
		{
#ifdef USE_SIGNAL
			if (errno == EINTR)
			{
				continue;
			}
#endif
			DLCSRV_LOG_ERR("socket: select: %s\n", strerror(errno));
			break;
		}

		if (FD_ISSET(client->client_fd, &read_fds))
		{
			ret = DLCSRV_CheckCommand(client->client_fd);
			if (ret == DLC_CMD_DISCONNECT)
			{
				CloseConnection(client->index);
				client->terminate = 1;
				pthread_detach(pthread_self());
				break;
			}

			switch (ret)
			{
			/* nop */
			case DLC_CMD_NOP:
				DLCSRV_LOG_DEBUG("DLC_CMD_NOP\n");
				DLCSRV_CmdNop(client->client_fd);
				break;

			/* connector commands */
			case DLC_CMD_GET_DPMS_MODE:
				DLCSRV_LOG_DEBUG("DLC_CMD_GET_DPMS_MODE\n");
				DLCSRV_CmdGetDpmsMode(client->client_fd);
				break;
			case DLC_CMD_SET_DPMS_MODE:
				DLCSRV_LOG_DEBUG("DLC_CMD_SET_DPMS_MODE\n");
				DLCSRV_CmdSetDpmsMode(client->client_fd);
				break;

			/* buffer memory commands */
			case DLC_CMD_ALLOC_BUFFER:
				DLCSRV_LOG_DEBUG("DLC_CMD_ALLOC_BUFFER\n");
				DLCSRV_CmdAllocBuffer(client);
				break;
			case DLC_CMD_FREE_BUFFER:
				DLCSRV_LOG_DEBUG("DLC_CMD_FREE_BUFFER\n");
				DLCSRV_CmdFreeBuffer(client);
				break;

			/* crtc commands */
			case DLC_CMD_ACQUIRE_DESKTOP:
				DLCSRV_LOG_DEBUG("DLC_CMD_ACQUIRE_DESKTOP\n");
				DLCSRV_CmdAcquireDesktop(client->client_fd);
				break;
			case DLC_CMD_RELEASE_DESKTOP:
				DLCSRV_LOG_DEBUG("DLC_CMD_RELEASE_DESKTOP\n");
				DLCSRV_CmdReleaseDesktop(client->client_fd);
				break;
			case DLC_CMD_SET_MODE:
				DLCSRV_LOG_DEBUG("DLC_CMD_SET_MODE\n");
				DLCSRV_CmdSetMode(client->client_fd);
				break;
			case DLC_CMD_PAGE_FLIP:
				DLCSRV_LOG_DEBUG("DLC_CMD_PAGE_FLIP\n");
				DLCSRV_CmdPageFlip(client->client_fd);
				break;

			/* plane commands */
			case DLC_CMD_ACQUIRE_PLANE:
				DLCSRV_LOG_DEBUG("DLC_CMD_ACQUIRE_PLANE\n");
				DLCSRV_CmdAcquirePlane(client->client_fd);
				break;
			case DLC_CMD_RELEASE_PLANE:
				DLCSRV_LOG_DEBUG("DLC_CMD_RELEASE_PLANE\n");
				DLCSRV_CmdReleasePlane(client->client_fd);
				break;
			case DLC_CMD_GET_PLANE_PROPERTY:
				DLCSRV_LOG_DEBUG("DLC_CMD_GET_PLANE_PROPERTY\n");
				DLCSRV_CmdGetPlaneProperty(client->client_fd);
				break;
			case DLC_CMD_SET_PLANE_PROPERTY:
				DLCSRV_LOG_DEBUG("DLC_CMD_SET_PLANE_PROPERTY\n");
				DLCSRV_CmdSetPlaneProperty(client->client_fd);
				break;
			case DLC_CMD_SET_PLANE:
				DLCSRV_LOG_DEBUG("DLC_CMD_SET_PLANE\n");
				DLCSRV_CmdDrmModeSetPlane(client->client_fd);
				break;

			/* pvr dc module commands */
			case DLC_CMD_ACQUIRE_DEVICE_DC:
				DLCSRV_LOG_DEBUG("DLC_CMD_ACQUIRE_DEVICE_DC\n");
				DLCSRV_CmdDrmAcquireDeviceDC(client->client_fd);
				break;
			case DLC_CMD_RELEASE_DEVICE_DC:
				DLCSRV_LOG_DEBUG("DLC_CMD_RELEASE_DEVICE_DC\n");
				DLCSRV_CmdDrmReleaseDeviceDC(client->client_fd);
				break;
			case DLC_CMD_SET_PLANE_DC:
				DLCSRV_LOG_DEBUG("DLC_CMD_SET_PLANE_DC\n");
				DLCSRV_CmdDrmModeSetPlaneDC(client->client_fd);
				break;
			case DLC_CMD_PAGE_FLIP_DC:
				DLCSRV_LOG_DEBUG("DLC_CMD_PAGE_FLIP_DC\n");
				DLCSRV_CmdPageFlipDC(client->client_fd);
				break;

			/* DRM-Master commands */
			case DLC_CMD_DRM_SET_MASTER:
				DLCSRV_LOG_DEBUG("DLC_CMD_DRM_SET_MASTER\n");
				DLCSRV_CmdDrmSetMaster(client->client_fd);
				break;
			case DLC_CMD_DRM_DROP_MASTER:
				DLCSRV_LOG_DEBUG("DLC_CMD_DRM_DROP_MASTER\n");
				DLCSRV_CmdDrmDropMaster(client->client_fd);
				break;
			case DLC_CMD_DRM_AUTH_MAGIC:
				DLCSRV_LOG_DEBUG("DLC_CMD_DRM_AUTH_MAGIC\n");
				DLCSRV_CmdDrmAuthMagic(client->client_fd);
				break;

			/* shutdown server */
			case DLC_CMD_TERMINATE:
				DLCSRV_LOG_DEBUG("DLC_CMD_TERMINATE\n");
				DLCSRV_CmdServerTerminate(client->client_fd);
				CloseAllClient();
				break;
			default:
				DLCSRV_LOG_ERR("unsupported command (%d)\n", ret);
				break;
			}
		}
	}

	DLCSRV_LOG_DEBUG("client(%d): thread finish\n", client->client_fd);

	pthread_exit(arg);
	return arg;
}

