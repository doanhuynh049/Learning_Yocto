/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

#ifndef __DLCSRV_SCOPE_H
#define __DLCSRV_SCOPE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef void* SCOPE_HANDLE;

typedef enum {
	SCOPE_FALSE = 0,
	SCOPE_TRUE,
} eScopeBool;


SCOPE_HANDLE DLCScope_Acquire(const char *name, const char *idname, unsigned int id, eScopeBool eSync);
void DLCScope_Release(SCOPE_HANDLE hHandle);
void DLCScope_StartContext(SCOPE_HANDLE hHandle);
void DLCScope_StopContext(SCOPE_HANDLE hHandle);
void DLCScope_UpdateFrame(SCOPE_HANDLE hHandle);
void DLCScope_TimingBegin(SCOPE_HANDLE hHandle, const char *cpTaskName, unsigned int uiPlaneID, unsigned int uiFbID);
void DLCScope_TimingEnd(SCOPE_HANDLE hHandle);
void DLCScope_TimingVSYNC(SCOPE_HANDLE hHandle);

#ifdef __cplusplus
};
#endif

#endif /* __DLCSRV_SCOPE_H */
