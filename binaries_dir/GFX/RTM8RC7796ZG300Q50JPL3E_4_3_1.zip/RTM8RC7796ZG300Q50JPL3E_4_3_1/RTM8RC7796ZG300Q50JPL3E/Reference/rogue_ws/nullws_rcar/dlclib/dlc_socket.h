/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */
#ifndef __DLC_SOCKET_H
#define __DLC_SOCKET_H

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm/drm.h>

int DLC_Socket_GetDpmsMode(int socket_fd, int conn_index, unsigned int *value);
int DLC_Socket_SetDpmsMode(int socket_fd, int conn_index, unsigned int value);

int DLC_Socket_AcquireDesktop(int socket_fd,
				int crtc_index, int buffers);
int DLC_Socket_ReleaseDesktop(int socket_fd, int crtc_index);

int DLC_Socket_SetCrtcMode(int socket_fd, 
				int crtc_index,
				int conn_index,
				unsigned int fb_id,
				unsigned int width, unsigned int height,
				unsigned int src_x, unsigned int src_y);

int DLC_Socket_PageFlip(int socket_fd,
				int crtc_index,
				unsigned int fb_id,
				unsigned int interval);

int DLC_Socket_AllocateFB(int socket_fd,
				unsigned int flink_name,
				unsigned int width,
				unsigned int height,
				unsigned int format,
				unsigned int pitch,
				unsigned int *remote_handle,
				unsigned int *fb_id);
int DLC_Socket_DestroyFB(int socket_fd, unsigned int remote_handle, unsigned int fb_id);

int DLC_Socket_AcquirePlane(int socket_fd,
				int crtc_index, int buffers,
				int *plane_index, unsigned int *plane_id);
int DLC_Socket_ReleasePlane(int socket_fd, int plane_index);

int DLC_Socket_GetPlaneProperty(int socket_fd, int plane_index, DLC_PLANE_PROPERTY prop, unsigned int *value);
int DLC_Socket_SetPlaneProperty(int socket_fd, int plane_index, DLC_PLANE_PROPERTY prop, unsigned int value);

int DLC_Socket_SetPlane(int socket_fd,
				int conn_index,
				int plane_index,
				int crtc_index,
				unsigned int fb_id,
				unsigned int disp_x, unsigned int disp_y,
				unsigned int disp_w, unsigned int disp_h,
				unsigned int src_x, unsigned int src_y,
				unsigned int src_w, unsigned int src_h,
				unsigned int interval);
int DLC_Socket_AcquireDeviceDC(int socket_fd,
				int plane_index,
				int crtc_index,
				unsigned int width,
				unsigned int height,
				unsigned int bytestride,
				unsigned int format,
				unsigned int buffers,
				unsigned long long *vaddr,
				unsigned int *dc_devid);
int DLC_Socket_ReleaseDeviceDC(int socket_fd,int plane_index, int crtc_index);
int DLC_Socket_SetPlaneDC(int socket_fd,
				int conn_index,
				int plane_index,
				int crtc_index,
				unsigned int fb_id,
				unsigned int disp_x, unsigned int disp_y,
				unsigned int disp_w, unsigned int disp_h,
				unsigned int src_x, unsigned int src_y,
				unsigned int src_w, unsigned int src_h,
				unsigned int dc_devid);
int DLC_Socket_PageFlipDC(int socket_fd,
				int crtc_index,
				unsigned int fb_id,
				unsigned int dc_devid);

int DLC_Socket_SvrSetMaster(int socket_fd);
int DLC_Socket_SvrDropMaster(int socket_fd);
int DLC_Socket_SvrAuthMagic(int socket_fd, drm_magic_t magic);

int DLC_ConnectServer(int *socket_fd);
void DLC_DisconnectServer(int socket_fd);

#endif /* __DLC_SOCKET_H */
