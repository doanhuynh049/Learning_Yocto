[Confidential]

1. TARGET SoC

   R8A7795, R8A779M0, R8A779M1,
   R8A7796, R8A779M2, R8A779M3,
   R8A77965, R8A779M4, R8A779M5,
   R8A7799, R8A779M6

2. ENVIRONMENT

   BSP            : R-Car H3/M3/M3N/E3 Yocto recipe package
   ToolChain      : Toolchain included in Yocto SDK 
                    ( refer to the "Yocto recipe Start-Up Guide" provided 
                      by Yocto recipe package for detail)

3. HOW TO BUILD
   1) Get public headers from GitHub
      $ git clone https://github.com/renesas-rcar/wayland-wsegl
      $ cp -r wayland-wsegl/include/powervr $WORK/Reference/rogue_ws/include/

   2) Set environment variables before compilation of wsegl module.
      $ source {$TARGET_DIRECTORY_FOR_SDK}/environment-setup-aarch64-poky-linux

      *)  {$TARGET_DIRECTORY_FOR_SDK} is target directory for SDK. e.g. "/opt/poky/3.1.8".

   3) Build nullws_drm module.
      $ cd $WORK/Reference/rogue_ws/nullws_rcar/client
      $ make

README.TXT / Feb 2024
