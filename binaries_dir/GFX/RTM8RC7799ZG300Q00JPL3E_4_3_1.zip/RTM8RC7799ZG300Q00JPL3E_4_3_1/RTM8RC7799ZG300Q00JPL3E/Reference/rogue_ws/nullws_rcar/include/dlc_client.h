/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor definitions for client
 */
#ifndef __DLC_CLIENT_H
#define __DLC_CLIENT_H

#include "dlc_status.h"

extern DLC_STATUS dlc_status;

#define DLC_MAX_BUFFERS		3

typedef enum DLC_FORMAT_TAG
{
	DLC_FORMAT_UNKNOWN	= 0,
	DLC_FORMAT_RGB565,
	DLC_FORMAT_ARGB1555,
	DLC_FORMAT_ARGB8888,
	DLC_FORMAT_ARGB4444,
	DLC_FORMAT_XRGB8888,

} DLC_FORMAT;

typedef enum DLC_MEMLAYOUT_TAG
{
	DLC_MEMLAYOUT_UNKNOWN	= 0,
	DLC_MEMLAYOUT_STRIDED,
	DLC_MEMLAYOUT_TWIDDLED,
	DLC_MEMLAYOUT_3DTWIDDLED,
	DLC_MEMLAYOUT_TILED,
	DLC_MEMLAYOUT_PAGETILED,

} DLC_MEMLAYOUT;

typedef enum DLC_COMPRESSION_TAG
{
	DLC_COMPRESSION_UNKNOWN	= 0,
	DLC_COMPRESSION_NONE,
	DLC_COMPRESSION_DIRECT_8x8,
	DLC_COMPRESSION_DIRECT_16x4,
	DLC_COMPRESSION_DIRECT_32x2,
	DLC_COMPRESSION_INDIRECT_8x8,
	DLC_COMPRESSION_INDIRECT_16x4,
	DLC_COMPRESSION_INDIRECT_4TILE_8x8,
	DLC_COMPRESSION_INDIRECT_4TILE_16x4,

} DLC_COMPRESSION;

typedef enum DLC_DPMS_MODE_TAG
{
	DLC_MODE_DPMS_ON	= 0,
	DLC_MODE_DPMS_STANDBY	= 1,
	DLC_MODE_DPMS_SUSPEND	= 2,
	DLC_MODE_DPMS_OFF	= 3,

} DLC_DPMS_MODE;

typedef enum DLC_PLANE_PROPERTY_TAG
{
	DLC_PLANE_PROP_UNKNOWN	= 0,
	DLC_PLANE_PROP_ALPHA	= 1,
	DLC_PLANE_PROP_COLORKEY	= 2,
	DLC_PLANE_PROP_PRIORITY	= 3,
	DLC_PLANE_PROP_CHANNEL	= 4,

} DLC_PLANE_PROPERTY;

typedef struct DLC_BUFFER_ATTRIBUTES_TAG
{
	unsigned int		uiHandle;
	unsigned int		uiWidth;
	unsigned int		uiHeight;
	unsigned int		uiMemSize;
	unsigned int		uiStride;
	DLC_FORMAT		ePixelFormat;
	DLC_MEMLAYOUT		eMemLayout;
	DLC_COMPRESSION		eCompression;
	void * 			pvCpuVirtAddr;
} DLC_BUFFER_ATTRIBUTES;

typedef void *	DLC_HANDLE;

typedef enum DLC_BOOL_TAG
{
	DLC_FALSE	= 0,
	DLC_TRUE,
} DLC_BOOL;

/*
 * library init/deinit functions.
 */
extern DLC_STATUS DLC_Init(DLC_HANDLE *phDevice, DLC_BOOL bUseSocket);
extern DLC_STATUS DLC_Exit(DLC_HANDLE hDevice);

/*
 * DRM resource access functions.
 */
extern DLC_STATUS DLC_GetConnectorCount(DLC_HANDLE hDevice, int *connectors);
extern DLC_STATUS DLC_GetConnector(DLC_HANDLE hDevice, int index, DLC_HANDLE *phConnector);
extern DLC_STATUS DLC_FreeConnector(DLC_HANDLE hConnector);
extern DLC_STATUS DLC_GetEncoderCount(DLC_HANDLE hDevice, int *encoders);
extern DLC_STATUS DLC_GetEncoder(DLC_HANDLE hDevice, int index, DLC_HANDLE *phEncoder);
extern DLC_STATUS DLC_GetEncoderFromConnector(DLC_HANDLE hDevice, DLC_HANDLE hConnector, DLC_HANDLE *phEncoder);
extern DLC_STATUS DLC_FreeEncoder(DLC_HANDLE hEncoder);
extern DLC_STATUS DLC_GetCrtcCount(DLC_HANDLE hDevice, int *crtcs);
extern DLC_STATUS DLC_GetCrtc(DLC_HANDLE hDevice, int index, DLC_HANDLE *phCrtc);
extern DLC_STATUS DLC_GetCrtcFromEncoder(DLC_HANDLE hDevice, DLC_HANDLE hEncoder, DLC_HANDLE *phCrtc);
extern DLC_STATUS DLC_FreeCrtc(DLC_HANDLE hCrtc);
extern DLC_STATUS DLC_GetCrtcIndex(DLC_HANDLE hCrtc, unsigned int *index);


/*
 * Layer manupilation functions.
 */
extern DLC_STATUS DLC_GetPlaneCount(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, int *planes);
extern DLC_STATUS DLC_AcquirePlane(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, int buffers, DLC_HANDLE *phPlane);
extern DLC_STATUS DLC_ReleasePlane(DLC_HANDLE hDevice, DLC_HANDLE hPlane);

extern DLC_STATUS DLC_AllocateLocalFB(DLC_HANDLE hDevice, unsigned int width, unsigned int height, unsigned int bpp,
					DLC_FORMAT eFormat, DLC_MEMLAYOUT eMemLayout, DLC_COMPRESSION eFbCompression,
					DLC_HANDLE *phFB);
extern DLC_STATUS DLC_DestroyLocalFB(DLC_HANDLE hDevice, DLC_HANDLE hFB);
extern DLC_STATUS DLC_GetLocalFBVAddr(DLC_HANDLE hFb, void **vaddr);

extern DLC_STATUS DLC_AllocateRemoteFB(DLC_HANDLE hDevice, unsigned int width, unsigned int height, unsigned int bpp,
					DLC_FORMAT eFormat, DLC_MEMLAYOUT eMemLayout, DLC_COMPRESSION eFbCompression,
					DLC_HANDLE *phFB);
extern DLC_STATUS DLC_DestroyRemoteFB(DLC_HANDLE hDevice, DLC_HANDLE hFB);
extern DLC_STATUS DLC_GetRemoteFBVAddr(DLC_HANDLE hFb, void **vaddr);
extern DLC_STATUS DLC_GetBufferAttributes(DLC_HANDLE hFb, DLC_BUFFER_ATTRIBUTES *psAttrib);
extern DLC_STATUS DLC_FBPrimeHandleToFD(DLC_HANDLE hFB, int *prime_fd);

extern DLC_STATUS DLC_GetPlaneProperty(DLC_HANDLE hDevice, DLC_HANDLE hPlane, DLC_PLANE_PROPERTY eProp, unsigned int *value);
extern DLC_STATUS DLC_SetPlaneProperty(DLC_HANDLE hDevice, DLC_HANDLE hPlane, DLC_PLANE_PROPERTY eProp, unsigned int value);

extern DLC_STATUS DLC_SetPlane(DLC_HANDLE hDevice, DLC_HANDLE hPlane, DLC_HANDLE hFB,
					unsigned int pos_x, unsigned int pos_y,
					unsigned int disp_w, unsigned int disp_h,
					unsigned int src_x, unsigned int src_y,
					unsigned int vsync);

/*
 * Connector functions.
 */
extern DLC_STATUS DLC_GetDpmsMode(DLC_HANDLE hDevice, DLC_HANDLE hConnector, DLC_DPMS_MODE *dpms_mode);
extern DLC_STATUS DLC_SetDpmsMode(DLC_HANDLE hDevice, DLC_HANDLE hConnector, DLC_DPMS_MODE dpms_mode);

/*
 * CRTC functions.
 */
extern DLC_STATUS DLC_AcquireDesktop(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, int buffers);
extern DLC_STATUS DLC_ReleaseDesktop(DLC_HANDLE hDevice, DLC_HANDLE hCrtc);
extern DLC_STATUS DLC_QueryCrtcMode(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, unsigned int *width, unsigned int *height);
extern DLC_STATUS DLC_SetCrtcMode(DLC_HANDLE hDevice, DLC_HANDLE hCrtc,
					DLC_HANDLE hFB,
					unsigned int disp_w, unsigned int disp_h,
					unsigned int src_x, unsigned int src_y);
extern DLC_STATUS DLC_WaitForVBlank(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, unsigned int vsync);
extern DLC_STATUS DLC_PageFlip(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, DLC_HANDLE hFB, unsigned int vsync);

/*
 * PVR DisplayClass functions
 */
extern DLC_STATUS DLC_AcquireDeviceDC(DLC_HANDLE hDevice, DLC_HANDLE hPlane,
					DLC_HANDLE hCrtc,
					unsigned int width,
					unsigned int height,
					unsigned int bytestride,
					unsigned int format,
					int buffers,
					unsigned long long *vaddr,
					unsigned int *dc_devid);
extern DLC_STATUS DLC_ReleaseDeviceDC(DLC_HANDLE hDevice, DLC_HANDLE hPlane, DLC_HANDLE hCrtc);
extern DLC_STATUS DLC_SetPlaneDC(DLC_HANDLE hDevice, DLC_HANDLE hPlane, DLC_HANDLE hFB,
					unsigned int pos_x, unsigned int pos_y,
					unsigned int disp_w, unsigned int disp_h,
					unsigned int src_x, unsigned int src_y,
					unsigned int dc_devid);
extern DLC_STATUS DLC_PageFlipDC(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, DLC_HANDLE hFB, unsigned int dc_devid);


#endif /* __DLC_CLIENT_H */
