/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor definitions for client
 *
 *	Status numbers
 */

#ifndef __DLC_STATUS_H
#define __DLC_STATUS_H

extern unsigned int dlc_status;

typedef enum DLC_STATUS_TAG
{
	DLC_STS_OK	= 0,			/* success */

	DLC_STS_NOT_SUPPORTED,			/* requested function or porperty are not supported */


	DLC_STS_INVALID_PARAMS,			/* invalid argument */

	DLC_STS_INVALID_DEVICE,			/* no such drm device */
	DLC_STS_INVALID_CONNECTOR,		/* no such connector index */
	DLC_STS_INVALID_ENCODER,		/* no such encoder index */
	DLC_STS_INVALID_CRTC,			/* no such crtc index */
	DLC_STS_INVALID_PLANE,			/* no such plane number */
	DLC_STS_INVALID_FB,			/* invalid fb id */

	DLC_STS_OUT_OF_MEMORY,			/* not enough space in kernel */
	DLC_STS_TOO_MANY_BUFFERS,		/* requested baffers > 3 */

	DLC_STS_NOT_A_MASTER,			/* other DRM-Master process working */

	DLC_STS_MONITOR_NOT_FOUND,		/* no monitor connnected */
	DLC_STS_CONNECTOR_NOT_FOUND,		/* not found a route fo connector */
	DLC_STS_ENCODER_NOT_FOUND,		/* not found a route of eoncoder */

	DLC_STS_CRTC_NOT_FOUND,			/* not found a route of crtc */
	DLC_STS_CRTC_BUSY,			/* crtc desabled or in interrupt hander */
	DLC_STS_CRTC_BAD_FB_SIZE,		/* fb drawable size is lager than crtc viewport */

	DLC_STS_PLANE_NOT_FOUND,		/* not found an idle plane */
	DLC_STS_PLANE_BUSY,			/* plane is already used by V-IN */
	DLC_STS_PLANE_BAD_SRC_SIZE,		/* plane size is lager than fb */
	DLC_STS_PLANE_BAD_CRTC_SIZE,		/* crtc viwport is lager than system max */

	DLC_STS_FB_BAD_SIZE,			/* fb size is lager than system max */

	DLC_STS_SERVER_NOT_RESPONDED,		/* */
	DLC_STS_CONNECTION_REFUSED,		/* */
	DLC_STS_COMMUNICATION_ERROR,		/* */

	DLC_STS_COMMAND_MISMATCH,		/* */
	DLC_STS_VERSION_MISMATCH,		/* */

} DLC_STATUS;

#endif /* __DLC_STATUS_H */

