/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server
 *	Event handler
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <sys/time.h>
#include <sys/select.h>
#include <signal.h>

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>

#include "dlcsrv_common.h"

extern int drmFd;
extern DLCSRV_DESKTOP_STATUS *desktop_stat;
extern DLCSRV_PLANE_STATUS *plane_stat;

pthread_mutex_t drm_mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct VBLANK_THREAD_INFO_TAG {
	pthread_t	thread;
	int		crtc_index;

	unsigned int	terminate;

	char	vblank_node[64];

	unsigned int vblank_flags;

} VBLANK_THREAD_INFO;


static void UpdateRemoveIndex(DLCSRV_FLIP_QUEUE_INDEX *index, int index_max)
{
	index->current = index->remove;

	index->remove = (index->remove + 1) % index_max;
}

static int check_planes_status(int crtc_index)
{
	int max_plane = DLCSRV_GetPlaneNum();
	int update = 0;

	for (int plane_index = 0; plane_index < max_plane; plane_index++)
	{
		DLCSRV_PLANE_STATUS *plane = &plane_stat[plane_index];
		DLCSRV_FLIP_QUEUE *flip;

		if (plane->crtc_index != crtc_index)
		{
			continue;
		}

		flip = &plane->flip_queue[plane->flip_index.remove];

		if (flip->status != DLCSRV_FLIP_IDLE)
		{
			update++;
		}
	}

	return update;
}

static int check_desktop_status(int crtc_index)
{
	int update = 0;

	DLCSRV_DESKTOP_STATUS *desktop = &desktop_stat[crtc_index];
	DLCSRV_PLANE_STATUS *plane = &desktop->plane;
	DLCSRV_FLIP_QUEUE *flip = &plane->flip_queue[plane->flip_index.remove];

	if (flip->status != DLCSRV_FLIP_IDLE)
	{
		update++;
	}

	return update;
}

static void *DLCSRV_VBlankThread(void *arg)
{
	VBLANK_THREAD_INFO *vbl_thread = (VBLANK_THREAD_INFO *)arg;
	int max_plane = DLCSRV_GetPlaneNum();

	DLCSRV_LOG_DEBUG("CRTC(%d) thread start\n", DLCSRV_CrtcIndexToId(vbl_thread->crtc_index));

	while (!vbl_thread->terminate)
	{
		int plane_update;
		int desktop_update;

		DLCSRV_WaitVBlank(vbl_thread->crtc_index, 1);

		DLCSRV_DRMLog_TimingVSYNC(vbl_thread->crtc_index);

		pthread_mutex_lock(&drm_mutex);
		DLCSRV_SetMaster();

		/* check status */
		plane_update = check_planes_status(vbl_thread->crtc_index);
		desktop_update = check_desktop_status(vbl_thread->crtc_index);

		if (plane_update || desktop_update)
		{
#ifdef USE_DRMATOMIC
			drmModeAtomicReqPtr atomic_req = drmModeAtomicAlloc();
			int plane_commit = -1;
#endif /* USE_DRMATOMIC */

			/* update desktop plane */
			if (desktop_update)
			{
				DLCSRV_DESKTOP_STATUS *desktop = &desktop_stat[vbl_thread->crtc_index];
				DLCSRV_PLANE_STATUS *plane = &desktop->plane;
				DLCSRV_FLIP_QUEUE *flip = &plane->flip_queue[plane->flip_index.remove];

#ifdef USE_DRMATOMIC
				if (flip->status == DLCSRV_FLIP_DONE)
				{
					flip->status = DLCSRV_FLIP_IDLE;

					UpdateRemoveIndex(&plane->flip_index, plane->buffers);

					flip = &plane->flip_queue[plane->flip_index.remove];
				}

				if (flip->status == DLCSRV_FLIP_FLIPPED)
				{
					flip->status = DLCSRV_FLIP_DONE;

					flip = &plane->flip_queue[(plane->flip_index.remove +1) % plane->buffers];
				}
#endif /* USE_DRMATOMIC */

				if (flip->status == DLCSRV_FLIP_PENDING)
				{
					flip->interval--;
					if (flip->interval == 0)
					{
#ifdef USE_DRMATOMIC
						DLCSRV_AtomicAddProperties(desktop->plane_id, flip->fb_id, plane, atomic_req, NULL);
						plane_commit = plane->crtc_index;

						flip->status = DLCSRV_FLIP_FLIPPED;
#else
						DLCSRV_PageFlip(plane->crtc_index, flip->fb_id);

						flip->status = DLCSRV_FLIP_IDLE;
						UpdateRemoveIndex(&plane->flip_index, plane->buffers);
#endif /* USE_DRMATOMIC */
					}
				}
			}

			/* update planes */
			if (plane_update)
			{
				for (int plane_index = 0; plane_index < max_plane; plane_index++)
				{
					DLCSRV_PLANE_STATUS *plane = &plane_stat[plane_index];
					DLCSRV_FLIP_QUEUE *flip;

					if (plane->crtc_index != vbl_thread->crtc_index)
					{
						continue;
					}

					flip = &plane->flip_queue[plane->flip_index.remove];

					if (flip->status == DLCSRV_FLIP_DONE)
					{
						flip->status = DLCSRV_FLIP_IDLE;

						UpdateRemoveIndex(&plane->flip_index, plane->buffers);

						flip = &plane->flip_queue[plane->flip_index.remove];
					}

					if (flip->status == DLCSRV_FLIP_FLIPPED)
					{
						flip->status = DLCSRV_FLIP_DONE;

						flip = &plane->flip_queue[(plane->flip_index.remove +1) % plane->buffers];
					}

					if (flip->status == DLCSRV_FLIP_PENDING)
					{
						flip->interval--;
						if (flip->interval == 0)
						{
#ifdef USE_DRMATOMIC
							DLCSRV_AtomicAddProperties(DLCSRV_PlaneIndexToId(plane_index), flip->fb_id, plane, atomic_req, NULL);
							plane_commit = plane->crtc_index;
#else
							DLCSRV_SetPlane(DLCSRV_PlaneIndexToId(plane_index), plane->crtc_index,
									flip->fb_id,
									plane->crtc_x, plane->crtc_y,
									plane->crtc_w, plane->crtc_h,
									plane->src_x,  plane->src_y,
									plane->src_w,  plane->src_h);
#endif /* USE_DRMATOMIC */

							flip->status = DLCSRV_FLIP_FLIPPED;
						}
					}
				}
			}

#ifdef USE_DRMATOMIC
			if (atomic_req)
			{
				if (plane_commit > -1)
				{
					DLCSRV_AtomicCommit(plane_commit, atomic_req, NULL);
				}
				drmModeAtomicFree(atomic_req);
			}
#endif /* USE_DRMATOMIC */
		}

		DLCSRV_DropMaster();
		pthread_mutex_unlock(&drm_mutex);
	}

	DLCSRV_LOG_DEBUG("CRTC(%d) thread end\n", DLCSRV_CrtcIndexToId(vbl_thread->crtc_index));

	pthread_exit(arg);

	return arg;
}

void *DLCSRV_StartVBlankThread(int crtc_index)
{
	VBLANK_THREAD_INFO *vbl_thread;

	vbl_thread = (VBLANK_THREAD_INFO *)malloc(sizeof(VBLANK_THREAD_INFO));
	if (!vbl_thread)
	{
		return NULL;
	}

	vbl_thread->crtc_index = crtc_index;
	vbl_thread->terminate = 0;

	/* create trehad */
	pthread_create(&vbl_thread->thread, NULL, DLCSRV_VBlankThread, vbl_thread);

	return (void *)vbl_thread;
}

void DLCSRV_StopVBlankThread(void *arg)
{
	VBLANK_THREAD_INFO *vbl_thread = (VBLANK_THREAD_INFO *)arg;

	if (vbl_thread && vbl_thread->thread)
	{
		DLCSRV_LOG_DEBUG("CRTC(%d), thead kill\n", DLCSRV_CrtcIndexToId(vbl_thread->crtc_index));

		pthread_mutex_lock(&drm_mutex);
		vbl_thread->terminate = 1;
		pthread_mutex_unlock(&drm_mutex);

		pthread_join(vbl_thread->thread, NULL);

		pthread_mutex_destroy(&drm_mutex);

		free(vbl_thread);
	}
}

void DLCSRV_WaitVBlank(int crtc_index, unsigned int sequence)
{
	drmVBlank vbl;
	drmVBlankSeqType flags;
	int ret;

	flags = DRM_VBLANK_RELATIVE;
	if (crtc_index == 1)
	{
		flags |= DRM_VBLANK_SECONDARY;
	}
	else if (crtc_index >= 2)
	{
		flags |= (crtc_index << DRM_VBLANK_HIGH_CRTC_SHIFT) & DRM_VBLANK_HIGH_CRTC_MASK;
	}

	vbl.request.type = flags;
	vbl.request.sequence = sequence;

	ret = drmWaitVBlank(drmFd, &vbl);

	if (ret && errno != EBUSY)
	{
#if 0
		DLCSRV_LOG_ERR("CRTC(%d): drmWaitVBlank: %s\n",
				DLCSRV_CrtcIndexToId(vbl_thread->crtc_index), strerror(errno));
#else
		sleep(1);
#endif
	}
}
