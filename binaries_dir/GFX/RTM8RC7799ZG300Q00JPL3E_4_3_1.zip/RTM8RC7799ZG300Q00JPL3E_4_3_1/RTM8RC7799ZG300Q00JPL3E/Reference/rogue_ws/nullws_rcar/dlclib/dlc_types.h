/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor lib internal type definitions.
 */
#ifndef __DLC_TYPES_H
#define __DLC_TYPES_H

#ifndef DLC_UNREFERENCED_PARAMETER
#define DLC_UNREFERENCED_PARAMETER(param) ((void)(param))
#endif

#define DLC_DRM_DEVICE "rcar-du"

typedef void *	DLC_HANDLE;

typedef struct DLC_DRMDEV_TAG
{
	int fd;

	drmModeRes *mode_res;
	drmModePlaneRes *plane_res;
	struct dbm_device *dbm_dev;

	int socket_mode;
	int socket;

} DLC_DRMDEV;

typedef struct DLC_DRMCONNECTOR_TAG
{
	int		index;
	unsigned int	connector_id;	/* DRM ID */
	unsigned int	dpms_id;

} DLC_DRMCONNECTOR;

typedef struct DLC_DRMENCODER_TAG
{
	int		index;
	unsigned int	encoder_id;	/* DRM ID */

	/* related resources info */
	int		connector_index;
	unsigned int	connector_id;
	unsigned int	connector_dpms_id;

} DLC_DRMENCODER;

typedef struct DLC_DRMCRTC_TAG
{
	int		index;
	unsigned int	crtc_id;	/* DRM ID */

	/* related resources info */
	int		connector_index;
	unsigned int	connector_id;
	unsigned int	connector_dpms_id;
	int		encoder_index;
	unsigned int	encoder_id;

	/* old settings */
	unsigned int	old_buf_id;
	unsigned int	old_width;
	unsigned int	old_height;
	unsigned int	old_x;
	unsigned int	old_y;
	drmModeModeInfo	old_mode;

} DLC_DRMCRTC;

typedef struct DLC_FLIP_CHAIN_TAG
{
	int plane_index;
	int count_fbs;
	unsigned int fb_ids[DLC_MAX_BUFFERS];
} DLC_FLIP_CHAIN;

typedef struct DLC_PLANE_TAG
{
	int		index;
	unsigned int	plane_id;	/* DRM ID */

	unsigned int crtc_x, crtc_y;
	unsigned int crtc_w, crtc_h;
	unsigned int src_x, src_y;
	unsigned int src_w, src_h;

	/* related resources info */
	int		connector_index;
	unsigned int	connector_id;
	unsigned int	connector_dpms_id;
	int		encoder_index;
	unsigned int	encoder_id;
	int		crtc_index;
	unsigned int	crtc_id;

	/* flip chain */
	DLC_FLIP_CHAIN hFlipChain;

} DLC_PLANE;

typedef enum DLC_ALLOC_TYPE_TAG
{
	DLC_ALLOC_LOCAL,
	DLC_ALLOC_REMOTE,

} DLC_ALLOC_TYPE;

typedef struct DLC_FB_TAG
{
	DLC_ALLOC_TYPE	eType;		/* Local or Remote */

	struct dbm_buffer *primary_buffer;

	int fb_id;			/* DRM ID */

	/* GEM handle (for Remote) */
	unsigned int remote_handle;

	/* Specifications of dbm_buffer */
	DLC_BUFFER_ATTRIBUTES sAttrib;

} DLC_FB;


#endif /* __DLC_TYPES_H */
