/*************************************************************************/ /*!
@File           null_ws_drm.h
@Title          NULLDRM WSEGL module
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
                Copyright (c) 2014 - 2016  Renesas Electronics Corporation
@License        Strictly Confidential.
*/ /**************************************************************************/

#if !defined(NULL_WS_DRM_H)
#define NULL_WS_DRM_H

#include <powervr/wsegl.h>

#ifdef __cplusplus
extern "C" {
#endif


#define NULLDRM_NUM_DISPLAYS	4

#define NULLDRM_MIN_SWAP_INTERVAL	0
#define NULLDRM_MAX_SWAP_INTERVAL	10

/* Number of buffers for the flipchain, or number of back buffers
   to allocate for blitting */
#define NULLDRM_WSEGL_DRAWABLE_BUFFER_COUNT	4

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(ARR) (sizeof(ARR) / sizeof((ARR)[0]))
#endif

#define NULLDRM_WSEGL_APPHINT_USE_DESKTOP	"UseDesktop"
#define NULLDRM_WSEGL_APPHINT_DEFAULT_DISPLAY	"SetDefaultDisplay"
#define NULLDRM_WSEGL_APPHINT_PRIMARY_SURFACE	"UsePrimarySurface"
#define NULLDRM_WSEGL_APPHINT_DISPLAY_WIDTH	"DisplayWidth"
#define NULLDRM_WSEGL_APPHINT_DISPLAY_HEIGHT	"DisplayHeight"

#define WAIT_FENCE_CLIENT

typedef enum
{
	NULLDRM_WSEGL_PRESENTMODE_FRONT = 0,
	NULLDRM_WSEGL_PRESENTMODE_FLIP,
	NULLDRM_WSEGL_PRESENTMODE_EXTERNAL,
} NULLDRM_WSEGL_PRESENTMODE;

typedef struct NULLDRM_WSEGL_DIMS_TAG
{
	uint32_t			uiWidth;
	uint32_t			uiHeight;
} NULLDRM_WSEGL_DIMS;

typedef struct NULLDRM_WSEGL_RECT_TAG
{
	int32_t				iXOffset;
	int32_t				iYOffset;
	NULLDRM_WSEGL_DIMS	sDims;
} NULLDRM_WSEGL_RECT;

typedef struct NULLDRM_WSEGL_DISPLAY_TAG
{
	uint32_t		uiRefCount;

	int32_t		iConnIndex;

	DLC_HANDLE		hDrmConn;
	DLC_HANDLE		hDrmEnc;
	DLC_HANDLE		hDrmCrtc;

	NULLDRM_WSEGL_DIMS	sDims;

	IMG_MEMLAYOUT		eFBMemLayout;
	IMG_FB_COMPRESSION	eFBCFormat;

} NULLDRM_WSEGL_DISPLAY;

typedef struct NULLDRM_WSEGL_BUFFER_TAG
{
	DLC_HANDLE			hDLCHandle;
	DLC_BUFFER_ATTRIBUTES		sAttribs;

	PVRSRV_MEMDESC			hMemDesc;
	IMG_DEV_VIRTADDR		sDevVirtAddr;

	bool			bFBInUse;

	uint32_t			uiBufferAge;

	/* SUPPORT_NATIVE_FENCE_SYNC */
	PVRSRV_FENCE hFence;	/* from drmAtomic OUT_FENCE (not use in client) */
	PVRSRV_FENCE hReadFence;	/* from GLES to drmAtomic IN_FENCE */

        /* [RELCOMMENT P-0149] Add new Parameter for YUV format. */
        IMG_YUV_COLORSPACE		eYUVColorSpace;
        IMG_YUV_CHROMA_INTERP		eYUVChromaUInterp;
        IMG_YUV_CHROMA_INTERP		eYUVChromaVInterp;

} NULLDRM_WSEGL_BUFFER;

typedef struct NULLDRM_WSEGL_DRAWABLE_TAG
{
	uint32_t			uiType;

	NULLDRM_WSEGL_DISPLAY		*psDisplay;

	NULLDRM_WSEGL_PRESENTMODE	ePresentMode;
	uint32_t			uiSwapInterval;

	/* Handle EGL_SWAP_BEHAVIOR */
	bool			bSwapBehaviourPreserve;
	bool			bFrameStarted;

	NULLDRM_WSEGL_RECT		sPlaneRect;
	int32_t			iPlaneIndex;

	DLC_HANDLE			hDrmPlane;
	DLC_HANDLE			hDrmCrtc;

	pthread_t			hThread;
	bool			bThreadEnd;
	sem_t				hThreadSemWakeup;
	sem_t				hThreadSemComplete;

	uint32_t			uiRemoveBuffer;

	uint32_t			uiNumBuffers;
	uint32_t			uiCurrentBuffer;

	NULLDRM_WSEGL_BUFFER		*apsBuffers[NULLDRM_WSEGL_DRAWABLE_BUFFER_COUNT];
	
	uint32_t			uiDisable_update;

} NULLDRM_WSEGL_DRAWABLE;

typedef struct NULLDRM_WSEGL_INFO_TAG
{
	PVRSRV_DEV_CONNECTION	*psDevConnection;
	PRGX_DEVMEMCONTEXT     hRGXDevMemContext;
	PVRSRV_DEVMEMCTX	hDevMemContext;
	PVRSRV_HEAP		hHeap;
	void *		hEventObject;
	void *		hTransferContext;

} NULLDRM_WSEGL_INFO;

#ifndef D_MASK_FORMAT
#define D_MASK_FORMAT			0x000000FF
#endif
#ifndef D_MASK_YUV_COLORSPACE
#define D_MASK_YUV_COLORSPACE	0x0000FF00
#endif

#ifdef __cplusplus
}
#endif

#endif /* NULL_WS_DRM_H */


/******************************************************************************
   End of file (null_ws_drm.h)
******************************************************************************/
