/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor library API
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/mman.h>

#include <xf86drm.h>
#include <xf86drmMode.h>
#include "powervr/img_drm_fourcc.h"

#include "dbm.h"
#include "dlc_client.h"
#include "dlc_types.h"
#include "dlc_socket.h"

DLC_STATUS dlc_status = DLC_STS_OK;	/* dlc command status for client */

/*
 * Get connector type strings
 */
static char *GetDrmConnectorName(unsigned int ui32ConnType)
{
	char *pszNameStr;

	if (ui32ConnType == DRM_MODE_CONNECTOR_VGA)
	{
		pszNameStr = "VGA";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_DVII)
	{
		pszNameStr = "DVI-I";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_DVID)
	{
		pszNameStr = "DVI-D";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_DVIA)
	{
		pszNameStr = "DVI-A";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_Composite)
	{
		pszNameStr = "Composite";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_SVIDEO)
	{
		pszNameStr = "S-Video";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_LVDS)
	{
		pszNameStr = "LVDS";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_Component)
	{
		pszNameStr = "Component";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_9PinDIN)
	{
		pszNameStr = "9-pin DIN";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_DisplayPort)
	{
		pszNameStr = "DisplayPort";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_HDMIA)
	{
		pszNameStr = "HDMI-A";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_HDMIB)
	{
		pszNameStr = "HDMI-B";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_TV)
	{
		pszNameStr = "TV";
	}
	else if (ui32ConnType == DRM_MODE_CONNECTOR_eDP)
	{
		pszNameStr = "eDP";
	}
	else
	{
		pszNameStr = "unknown";
	}

	return pszNameStr;
}

/*
 * Get display buffer format
 */
static unsigned int DLCPixFmtToDBMPixFmt(DLC_FORMAT ePixelFormat)
{
	switch (ePixelFormat)
	{
	case DLC_FORMAT_RGB565:
		return DRM_FORMAT_RGB565;
	case DLC_FORMAT_ARGB1555:
		return DRM_FORMAT_ARGB1555;
	case DLC_FORMAT_ARGB8888:
		return DRM_FORMAT_ARGB8888;
	case DLC_FORMAT_XRGB8888:
		return DRM_FORMAT_XRGB8888;
	default:
		//assert(!"unsupported pixel format");
		return 0;
	}
}

#if 0
static DLC_FORMAT DBMPixFmtToDLCPixFmt(unsigned int uiPixelFormat)
{
	switch (uiPixelFormat)
	{
	case DRM_FORMAT_RGB565:
		return DLC_FORMAT_RGB565;
	case DRM_FORMAT_ARGB1555:
		return DLC_FORMAT_ARGB1555;
	case DRM_FORMAT_ARGB8888:
		return DLC_FORMAT_ARGB8888;
	case DRM_FORMAT_XRGB8888:
		return DLC_FORMAT_XRGB8888;
	default:
		return DLC_FORMAT_UNKNOWN;
	}
}
#endif


/*
 * library init/deinit functions.
 */

/********************************************************************************
 Function	: DLC_Init
 In		: bUseSocket
 Out		: phDevice
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_Init(DLC_HANDLE *phDevice, DLC_BOOL bUseSocket)
{
	DLC_DRMDEV *psDrmDev;
	DLC_STATUS eStatus = DLC_STS_OK;

	if (!phDevice)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	psDrmDev = (DLC_DRMDEV *)malloc(sizeof(DLC_DRMDEV));
	if (!psDrmDev)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}
	memset(psDrmDev, 0, sizeof(DLC_DRMDEV));

	/*
	 * connect to server
	 */
	if (bUseSocket == DLC_TRUE)
	{
		if (DLC_ConnectServer(&psDrmDev->socket))
		{
			/*
			 * connection refused
			 */
			eStatus = dlc_status;
			goto err_connect_srv;
		}

		psDrmDev->socket_mode = 1;
	}

	/*
	 * initialize local DRM resources
	 */
	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_SvrSetMaster(psDrmDev->socket))
		{
			eStatus = DLC_STS_NOT_A_MASTER;
			goto err_set_master;
		}
	}

	psDrmDev->fd = drmOpen(DLC_DRM_DEVICE, NULL);
	if (psDrmDev->fd < 0)
	{
		fprintf(stderr, "DRM (pid: %d) \"%s\" open failed\n", getpid(), DLC_DRM_DEVICE);

		eStatus = DLC_STS_INVALID_DEVICE;
		goto err_open_drm;
	}

	drmDropMaster(psDrmDev->fd);

	psDrmDev->mode_res = drmModeGetResources(psDrmDev->fd);
	if (!psDrmDev->mode_res)
	{
		eStatus = DLC_STS_OUT_OF_MEMORY;
		goto err_get_drm_res;
	}

	psDrmDev->plane_res = drmModeGetPlaneResources(psDrmDev->fd);
	if (!psDrmDev->plane_res)
	{
		eStatus = DLC_STS_OUT_OF_MEMORY;
		goto err_get_plane_res;
	}

	/* Initialize display buffer manager */
	psDrmDev->dbm_dev = dbm_device_create(psDrmDev->fd);
	if (!psDrmDev->dbm_dev)
	{
		eStatus = DLC_STS_OUT_OF_MEMORY;
		goto err_create_dbm;
	}

	*phDevice = (DLC_HANDLE *)psDrmDev;

	if (psDrmDev->socket_mode)
	{
		drm_magic_t magic;
		if (drmGetMagic(psDrmDev->fd, &magic) == 0)
		{
			DLC_Socket_SvrAuthMagic(psDrmDev->socket, magic);
		}

		DLC_Socket_SvrDropMaster(psDrmDev->socket);
	}

	return DLC_STS_OK;

err_create_dbm:
	drmModeFreePlaneResources(psDrmDev->plane_res);
err_get_plane_res:
	drmModeFreeResources(psDrmDev->mode_res);
err_get_drm_res:
	drmClose(psDrmDev->fd);
err_open_drm:
	if (psDrmDev->socket_mode)
	{
		DLC_Socket_SvrDropMaster(psDrmDev->socket);
err_set_master:
		DLC_DisconnectServer(psDrmDev->socket);
	}
err_connect_srv:
	free(psDrmDev);

	return eStatus;
}

/********************************************************************************
 Function	: DLC_Exit
 In		: hDevice
 Out		: None
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_Exit(DLC_HANDLE hDevice)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;

	if (!psDrmDev)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	/*
	 * release local resources
	 */
	dbm_device_destroy(psDrmDev->dbm_dev);
	drmModeFreePlaneResources(psDrmDev->plane_res);
	drmModeFreeResources(psDrmDev->mode_res);
	drmClose(psDrmDev->fd);

	/*
	 * disconnect to server
	 */
	if (psDrmDev->socket_mode)
	{
		DLC_DisconnectServer(psDrmDev->socket);
	}

	free(psDrmDev);

	return DLC_STS_OK;
}

/*
 * DRM resource access functions.
 */
/********************************************************************************
 Function	: DLC_GetConnectorCount
 In		: hDevice
 Out		: connectors
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetConnectorCount(DLC_HANDLE hDevice, int *connectors)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;

	if (!psDrmDev)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	*connectors = psDrmDev->mode_res->count_connectors;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_GetConnector
 In		: hDevice
		: index
 Out		: phConnector
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetConnector(DLC_HANDLE hDevice, int index, DLC_HANDLE *phConnector)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	drmModeRes *mode_res;
	drmModeConnector *connector;
	int i;

	DLC_DRMCONNECTOR *psDrmConn;

	if (!psDrmDev || !phConnector)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	mode_res = psDrmDev->mode_res;

	if ((index < 0) || (index >= mode_res->count_connectors))
	{
		return DLC_STS_INVALID_PARAMS;
	}

	psDrmConn = (DLC_DRMCONNECTOR *)malloc(sizeof(DLC_DRMCONNECTOR));
	if (!psDrmConn)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	psDrmConn->index = index;
	psDrmConn->connector_id = mode_res->connectors[index];

	connector = drmModeGetConnector(psDrmDev->fd, mode_res->connectors[index]);

	for (i = 0; i < connector->count_props; i++)
	{
		drmModePropertyRes *conn_prop;

		conn_prop = drmModeGetProperty(psDrmDev->fd, connector->props[i]);
		if (!conn_prop)
		{
			break;
		}

		if (!strcmp(conn_prop->name, "DPMS"))
		{
			psDrmConn->dpms_id = connector->props[i];
			drmModeFreeProperty(conn_prop);
			break;
		}

		drmModeFreeProperty(conn_prop);
	}

	drmModeFreeConnector(connector);

	*phConnector = (DLC_HANDLE *)psDrmConn;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_FreeConnector
 In		: hConnector
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_FreeConnector(DLC_HANDLE hConnector)
{
	DLC_DRMCONNECTOR *psDrmConn = (DLC_DRMCONNECTOR *)hConnector;

	if (!psDrmConn)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	free(psDrmConn);

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_GetDpmsMode
 In		: hDevice
		: hConnector
 Out		: dpms_mode
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetDpmsMode(DLC_HANDLE hDevice, DLC_HANDLE hConnector, DLC_DPMS_MODE *dpms_mode)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCONNECTOR *psDrmConn = (DLC_DRMCONNECTOR *)hConnector;

	if (!psDrmDev || !psDrmConn || !dpms_mode)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_GetDpmsMode(psDrmDev->socket,
						psDrmConn->index,
						dpms_mode))
		{
			return dlc_status;
		}
	}
	else
	{
		drmModePropertyRes *conn_prop;

		conn_prop = drmModeGetProperty(psDrmDev->fd, psDrmConn->dpms_id);
		if (!conn_prop)
		{
			return DLC_STS_OUT_OF_MEMORY;
		}

		switch (conn_prop->values[0])
		{
		case DRM_MODE_DPMS_ON:
			*dpms_mode = DLC_MODE_DPMS_ON;
			break;
		case DRM_MODE_DPMS_STANDBY:
			*dpms_mode = DLC_MODE_DPMS_STANDBY;
			break;
		case DRM_MODE_DPMS_SUSPEND:
			*dpms_mode = DLC_MODE_DPMS_SUSPEND;
			break;
		case DRM_MODE_DPMS_OFF:
			*dpms_mode = DLC_MODE_DPMS_OFF;
			break;
		}

		drmModeFreeProperty(conn_prop);
	}

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_SetDpmsMode
 In		: hDevice
		: hConnector
		: dpms_mode
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_SetDpmsMode(DLC_HANDLE hDevice, DLC_HANDLE hConnector, DLC_DPMS_MODE dpms_mode)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCONNECTOR *psDrmConn = (DLC_DRMCONNECTOR *)hConnector;
	unsigned int value;
	DLC_STATUS eStatus = DLC_STS_OK;

	if (!psDrmDev || !psDrmConn)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	switch (dpms_mode)
	{
	case DLC_MODE_DPMS_ON:
		value = DRM_MODE_DPMS_ON;
		break;
	case DLC_MODE_DPMS_STANDBY:
		value = DRM_MODE_DPMS_STANDBY;
		break;
	case DLC_MODE_DPMS_SUSPEND:
		value = DRM_MODE_DPMS_SUSPEND;
		break;
	case DLC_MODE_DPMS_OFF:
		value = DRM_MODE_DPMS_OFF;
		break;
	default:
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_SetDpmsMode(psDrmDev->socket,
						psDrmConn->index,
						value))
		{
			return dlc_status;
		}
	}
	else
	{
		drmSetMaster(psDrmDev->fd);
		if (drmModeConnectorSetProperty(psDrmDev->fd, psDrmConn->connector_id, psDrmConn->dpms_id, value))
		{
			eStatus = DLC_STS_NOT_SUPPORTED;
		}
		drmDropMaster(psDrmDev->fd);
	}

	return eStatus;
}

/********************************************************************************
 Function	: DLC_GetEncoderCount
 In		: hDevice
 Out		: encoders
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetEncoderCount(DLC_HANDLE hDevice, int *encoders)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;

	if (!psDrmDev || !encoders)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	*encoders =  psDrmDev->mode_res->count_encoders;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_GetEncoder
 In		: hDevice
		: index
 Out		: phEncoder
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetEncoder(DLC_HANDLE hDevice, int index, DLC_HANDLE *phEncoder)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	drmModeRes *mode_res;

	DLC_DRMENCODER *psDrmEnc;

	if (!psDrmDev || !phEncoder)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	mode_res = psDrmDev->mode_res;

	if ((index < 0) || (index >= mode_res->count_encoders))
	{
		return DLC_STS_INVALID_PARAMS;
	}

	psDrmEnc = (DLC_DRMENCODER *)malloc(sizeof(DLC_DRMENCODER));
	if (!psDrmEnc)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	psDrmEnc->index = index;
	psDrmEnc->encoder_id = mode_res->encoders[index];

	*phEncoder = (DLC_HANDLE *)psDrmEnc;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_GetEncoderFromConnector
 In		: hDevice
		: hConnector
 Out		: phEncoder
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetEncoderFromConnector(DLC_HANDLE hDevice, DLC_HANDLE hConnector, DLC_HANDLE *phEncoder)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCONNECTOR *psDrmConn = (DLC_DRMCONNECTOR *)hConnector;
	DLC_DRMENCODER *psDrmEnc;

	drmModeRes *mode_res;
	drmModeConnector *mode_conn;
	int i;

	if (!psDrmDev || !psDrmConn || !phEncoder)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	mode_res = psDrmDev->mode_res;

	psDrmEnc = (DLC_DRMENCODER *)malloc(sizeof(DLC_DRMENCODER));
	if (!psDrmEnc)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	mode_conn = drmModeGetConnector(psDrmDev->fd, psDrmConn->connector_id);
	if (!mode_conn)
	{
		free(psDrmEnc);
		return DLC_STS_OUT_OF_MEMORY;
	}

	if (mode_conn->connection != DRM_MODE_CONNECTED)
	{
		drmModeFreeConnector(mode_conn);
		free(psDrmEnc);
		fprintf(stderr, "DRM (pid: %d): Please check the %s-%d connector.\n",
					getpid(),
					GetDrmConnectorName(mode_conn->connector_type),
					mode_conn->connector_type_id);
		return DLC_STS_MONITOR_NOT_FOUND;
	}

	for (i = 0; i < mode_res->count_encoders; i++)
	{
		if (mode_res->encoders[i] == mode_conn->encoder_id)
		{
			break;
		}
	}

	psDrmEnc->index = i;
	psDrmEnc->encoder_id = mode_conn->encoder_id;

	drmModeFreeConnector(mode_conn);

	if (!psDrmEnc->encoder_id || psDrmEnc->index >= mode_res->count_encoders)
	{
		free(psDrmEnc);
		return DLC_STS_ENCODER_NOT_FOUND;
	}

	psDrmEnc->connector_index = psDrmConn->index;
	psDrmEnc->connector_id = psDrmConn->connector_id;
	psDrmEnc->connector_dpms_id = psDrmConn->dpms_id;

	*phEncoder = (DLC_HANDLE *)psDrmEnc;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_FreeEncoder
 In		: hEncoder
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_FreeEncoder(DLC_HANDLE hEncoder)
{
	DLC_DRMENCODER *psDrmEnc = (DLC_DRMENCODER *)hEncoder;

	if (!psDrmEnc)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	free(psDrmEnc);

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_GetCrtcCount
 In		: hDevice
 Out		: crtcs
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetCrtcCount(DLC_HANDLE hDevice, int *crtcs)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;

	if (!psDrmDev)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	*crtcs = psDrmDev->mode_res->count_crtcs;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_GetCrtc
 In		: hDevice
		: index
 Out		: phCrtc
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetCrtc(DLC_HANDLE hDevice, int index, DLC_HANDLE *phCrtc)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCRTC *psDrmCrtc;

	drmModeRes *mode_res;

	if (!psDrmDev || !phCrtc)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	mode_res = psDrmDev->mode_res;

	if ((index < 0) || (index >= mode_res->count_crtcs))
	{
		return DLC_STS_INVALID_PARAMS;
	}

	psDrmCrtc = (DLC_DRMCRTC *)malloc(sizeof(DLC_DRMCRTC));
	if (!psDrmCrtc)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	psDrmCrtc->index = index;
	psDrmCrtc->crtc_id = mode_res->crtcs[index];

	*phCrtc = (DLC_HANDLE *)psDrmCrtc;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_GetCrtcFromEncoder
 In		: hDevice
		: hEncoder
 Out		: phCrtc
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetCrtcFromEncoder(DLC_HANDLE hDevice, DLC_HANDLE hEncoder, DLC_HANDLE *phCrtc)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMENCODER *psDrmEnc = (DLC_DRMENCODER *)hEncoder;
	DLC_DRMCRTC *psDrmCrtc;

	drmModeRes *mode_res;
	drmModeEncoder *mode_enc;
	int i;

	if (!psDrmDev || !psDrmEnc || !phCrtc)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	mode_res = psDrmDev->mode_res;

	psDrmCrtc = (DLC_DRMCRTC *)malloc(sizeof(DLC_DRMCRTC));
	if (!psDrmCrtc)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	mode_enc = drmModeGetEncoder(psDrmDev->fd, psDrmEnc->encoder_id);
	if (!mode_enc)
	{
		free(psDrmCrtc);
		return DLC_STS_OUT_OF_MEMORY;
	}

	for (i = 0; i < mode_res->count_crtcs; i++)
	{
		if (mode_res->crtcs[i] == mode_enc->crtc_id)
		{
			break;
		}
	}

	psDrmCrtc->index = i;
	psDrmCrtc->crtc_id = mode_enc->crtc_id;

	drmModeFreeEncoder(mode_enc);

	if (!psDrmCrtc->crtc_id || psDrmCrtc->index >= mode_res->count_crtcs)
	{
		free(psDrmCrtc);
		return DLC_STS_CRTC_NOT_FOUND;
	}

	psDrmCrtc->connector_index = psDrmEnc->connector_index;
	psDrmCrtc->connector_id = psDrmEnc->connector_id;
	psDrmCrtc->connector_dpms_id = psDrmEnc->connector_dpms_id;
	psDrmCrtc->encoder_index = psDrmEnc->index;
	psDrmCrtc->encoder_id = psDrmEnc->encoder_id;

	*phCrtc = (DLC_HANDLE *)psDrmCrtc;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_FreeCrtc
 In		: hCrtc
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_FreeCrtc(DLC_HANDLE hCrtc)
{
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;

	if (!psDrmCrtc)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	free(psDrmCrtc);

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_GetCrtcIndex
 In		: hCrtc
 Out		: index
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetCrtcIndex(DLC_HANDLE hCrtc, unsigned int *index)
{
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;

	if (!psDrmCrtc || !index)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	*index = psDrmCrtc->index;

	return DLC_STS_OK;
}

/*
 * Layer manupilation functions.
 */
/********************************************************************************
 Function	: DLC_GetPlaneCount
 In		: hDevice
		: hCrtc
 Out		: planes
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetPlaneCount(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, int *planes)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;

	if (!psDrmDev || !planes)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (!hCrtc)
	{
		/* Report all planes */
		*planes = psDrmDev->plane_res->count_planes;
	}
	else
	{
		int i;
		drmModePlane *mode_plane;
		DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;

		/* Report per CRTC's planes */
		*planes = 0;
		for (i = 0; i < (int)psDrmDev->plane_res->count_planes; i++)
		{
			mode_plane = drmModeGetPlane(psDrmDev->fd, psDrmDev->plane_res->planes[i]);
			if (!mode_plane)
			{
				return DLC_STS_OUT_OF_MEMORY;
			}
			if (mode_plane->possible_crtcs & (1 << psDrmCrtc->index))
			{
				*planes += 1;
			}
			drmModeFreePlane(mode_plane);
		}
	}

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_AcquirePlane
 In		: hDevice
		: hCrtc
		: buffers
 Out		: phPlane
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_AcquirePlane(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, int buffers, DLC_HANDLE *phPlane)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;
	DLC_PLANE *psDrmPlane;

	if (!psDrmDev || !psDrmCrtc || !phPlane)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	psDrmPlane = (DLC_PLANE *)malloc(sizeof(DLC_PLANE));
	if (!psDrmPlane)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_AcquirePlane(psDrmDev->socket, psDrmCrtc->index, buffers, &psDrmPlane->index, &psDrmPlane->plane_id))
		{
			free(psDrmPlane);
			return dlc_status;
		}
	}
	else
	{
		int i;
		drmModePlane *mode_plane;
		int found = 0;
		int plane = -1;

		/* search idle plane */
		for (i = 0; i < (int)psDrmDev->plane_res->count_planes; i++)
		{
			mode_plane = drmModeGetPlane(psDrmDev->fd, psDrmDev->plane_res->planes[i]);
			if (!mode_plane)
			{
				free(psDrmPlane);
				return DLC_STS_OUT_OF_MEMORY;
			}
			if ((mode_plane->possible_crtcs & (1 << psDrmCrtc->index)) && !mode_plane->fb_id)
			{
				found++;
			}
			drmModeFreePlane(mode_plane);

			if (found)
			{
				plane = i;
				break;
			}
		}

		if (!found)
		{
			free(psDrmPlane);
			return DLC_STS_PLANE_NOT_FOUND;
		}

		psDrmPlane->index = plane;
		psDrmPlane->plane_id = psDrmDev->plane_res->planes[plane];
	}

	psDrmPlane->connector_index = psDrmCrtc->connector_index;
	psDrmPlane->connector_id = psDrmCrtc->connector_id;
	psDrmPlane->connector_dpms_id = psDrmCrtc->connector_dpms_id;
	psDrmPlane->encoder_index = psDrmPlane->encoder_index;
	psDrmPlane->encoder_id = psDrmPlane->encoder_id;
	psDrmPlane->crtc_index = psDrmCrtc->index;
	psDrmPlane->crtc_id = psDrmCrtc->crtc_id;

	*phPlane = (DLC_HANDLE *)psDrmPlane;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_ReleasePlane
 In		: hDevice
		: hPlane
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_ReleasePlane(DLC_HANDLE hDevice, DLC_HANDLE hPlane)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_PLANE *psDrmPlane = (DLC_PLANE *)hPlane;
	DLC_STATUS eStatus = DLC_STS_OK;

	if (!psDrmDev || !psDrmPlane)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if(DLC_Socket_ReleasePlane(psDrmDev->socket, psDrmPlane->index))
		{
			eStatus = dlc_status;
		}
	}

	free(psDrmPlane);

	return eStatus;
}


/********************************************************************************
 Function	: DLC_AllocateLocalFB
 In		: hDevice
		: width
		: height
		: bpp          : bits per pixel
		: eFormat
		: eMemLayout
		: eCompression
 Out		: pphFB
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_AllocateLocalFB(DLC_HANDLE hDevice, unsigned int width, unsigned int height, unsigned int bpp,
				DLC_FORMAT eFormat, DLC_MEMLAYOUT eMemLayout, DLC_COMPRESSION eCompression,
				DLC_HANDLE *phFB)
{
#if 0
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_FB *psDrmFB;
	DLC_STATUS eStatus;

	unsigned int fb_id;
	void *vaddr;

	struct dbm_buffer *buffer;
	unsigned int dbm_format;
	enum dbm_layout dbm_layout;
	enum dbm_fbc dbm_fbc;
	unsigned int dbm_flags;
	uint32_t dbm_stride;
	size_t dbm_size;

	unsigned int bo_handles[4];
	unsigned int bo_strides[4];
	unsigned int bo_offsets[4];

	memset(bo_handles, 0, sizeof(unsigned int) * 4);
	memset(bo_strides, 0, sizeof(unsigned int) * 4);
	memset(bo_offsets, 0, sizeof(unsigned int) * 4);

	if (!psDrmDev || !phFB)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	dbm_format = DLCPixFmtToDBMPixFmt(eFormat);
	dbm_layout = DLCMemLayoutToDBMLayout(eMemLayout);
	dbm_fbc    = DLCCompressionToDBMFbc(eCompression);
	dbm_flags  = DBM_BUFFER_FLAG_USE_SCANOUT | DBM_BUFFER_FLAG_USE_RENDER;
	if (dbm_format == 0)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	psDrmFB = (DLC_FB *)malloc(sizeof(DLC_FB));
	if (!psDrmFB)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	if (dbm_is_format_and_layout_supported(psDrmDev->dbm_dev,
					       dbm_format,
					       dbm_layout,
					       dbm_flags) != true)
	{
		eStatus = DLC_STS_INVALID_PARAMS;
		goto err_alloc;
	}

	if (dbm_get_buffer_stride_and_size(psDrmDev->dbm_dev,
					   width,
					   height,
					   bpp,
					   dbm_layout,
					   dbm_fbc,
					   dbm_flags,
					   &dbm_stride,
					   &dbm_size))
	{
		eStatus = DLC_STS_INVALID_PARAMS;
		goto err_alloc;
	}

	buffer = dbm_buffer_create(psDrmDev->dbm_dev,
				   dbm_size,
				   dbm_flags);

	vaddr = dbm_buffer_cpu_access_prepare(buffer, true, true);
	if (vaddr == MAP_FAILED)
	{
		dbm_buffer_destroy(buffer);

		eStatus = DLC_STS_OUT_OF_MEMORY;
		goto err_alloc;
	}

	bo_handles[0] = dbm_buffer_get_handle(buffer);	// prime_fd
	bo_strides[0] = dbm_buffer_get_stride(buffer);

	if (drmModeAddFB2(psDrmDev->fd, width, height, dbm_format,
				bo_handles, bo_strides, bo_offsets, &fb_id, 0))
	{
		dbm_buffer_cpu_access_finish(buffer);
		dbm_buffer_destroy(buffer);

		eStatus = (errno == ERANGE) ? DLC_STS_FB_BAD_SIZE : DLC_STS_INVALID_PARAMS;
		goto err_alloc;
	}

	psDrmFB->eType = DLC_ALLOC_LOCAL;
	psDrmFB->primary_buffer = buffer;
	psDrmFB->fb_id = fb_id;
	psDrmFB->vaddr = vaddr;

	*phFB = (DLC_HANDLE *)psDrmFB;

	return DLC_STS_OK;

err_alloc:
	free(psDrmFB);
	return eStatus;
#else
	DLC_UNREFERENCED_PARAMETER(hDevice);
	DLC_UNREFERENCED_PARAMETER(width);
	DLC_UNREFERENCED_PARAMETER(height);
	DLC_UNREFERENCED_PARAMETER(bpp);
	DLC_UNREFERENCED_PARAMETER(eFormat);
	DLC_UNREFERENCED_PARAMETER(eMemLayout);
	DLC_UNREFERENCED_PARAMETER(eCompression);
	DLC_UNREFERENCED_PARAMETER(phFB);

	return DLC_STS_NOT_SUPPORTED;
#endif
}

/********************************************************************************
 Function	: DLC_DestroyLocalFB
 In		: hDevice
		: hFB
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_DestroyLocalFB(DLC_HANDLE hDevice, DLC_HANDLE hFB)
{
#if 0
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_FB *psDrmFB = (DLC_FB *)hFB;

	if (!psDrmDev || !psDrmFB || !psDrmFB->primary_buffer || (psDrmFB->eType != DLC_ALLOC_LOCAL))
	{
		return DLC_STS_INVALID_PARAMS;
	}

	drmModeRmFB(psDrmDev->fd, psDrmFB->fb_id);
	dbm_buffer_cpu_access_finish(psDrmFB->primary_buffer);
	dbm_buffer_destroy(psDrmFB->primary_buffer);

	free(psDrmFB);

	return DLC_STS_OK;
#else
	DLC_UNREFERENCED_PARAMETER(hDevice);
	DLC_UNREFERENCED_PARAMETER(hFB);

	return DLC_STS_NOT_SUPPORTED;
#endif
}

/********************************************************************************
 Function	: DLC_GetLocalFBVAddr
 In		: hFB
 Out		: vaddr
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetLocalFBVAddr(DLC_HANDLE hFB, void **vaddr)
{
#if 0
	DLC_FB *psDrmFB = (DLC_FB *)hFB;

	if (!psDrmFB || (psDrmFB->eType != DLC_ALLOC_LOCAL))
	{
		return DLC_STS_INVALID_PARAMS;
	}

	*vaddr = psDrmFB->vaddr;

	return DLC_STS_OK;
#else
	DLC_UNREFERENCED_PARAMETER(hFB);
	DLC_UNREFERENCED_PARAMETER(vaddr);

	return DLC_STS_NOT_SUPPORTED;
#endif
}

/********************************************************************************
 Function	: DLC_AllocateRemoteFB
 In		: hDevice
		: width
		: height
		: bpp          : bits per pixel
		: eFormat
		: eMemLayout
		: eCompression
 Out		: pphFB
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_AllocateRemoteFB(DLC_HANDLE hDevice, unsigned int width, unsigned int height, unsigned int bpp,
				DLC_FORMAT eFormat, DLC_MEMLAYOUT eMemLayout, DLC_COMPRESSION eCompression,
				DLC_HANDLE *phFB)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_FB *psDrmFB;
	DLC_STATUS eStatus;

	unsigned int gem_handle;
	unsigned int fb_id;
	void *vaddr;

	struct dbm_buffer *buffer;
	unsigned int dbm_format;
	unsigned int dbm_flags;
	uint32_t dbm_stride;
	size_t dbm_size;
	const uint64_t *dbm_mods;
	unsigned int uiNum;

	if (!psDrmDev || !phFB)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	dbm_format = DLCPixFmtToDBMPixFmt(eFormat);
//	dbm_flags  = DBM_BUFFER_FLAG_USE_SCANOUT | DBM_BUFFER_FLAG_USE_RENDER;
	dbm_flags  = DBM_BUFFER_FLAG_USE_RENDER;
	if (dbm_format == 0)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	psDrmFB = (DLC_FB *)malloc(sizeof(DLC_FB));
	if (!psDrmFB)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	if (psDrmDev->socket_mode)
	{
		uiNum = dbm_get_drm_modifiers(psDrmDev->dbm_dev,
						      dbm_format,
						      dbm_flags,
						      &dbm_mods);

		if (uiNum == 0)
		{
			return DLC_STS_INVALID_PARAMS;
		}
		
		if (dbm_get_buffer_stride_and_size(psDrmDev->dbm_dev,
						   width,
						   height,
						   bpp,
						   dbm_mods[0],
						   dbm_flags,
						   &dbm_stride,
						   &dbm_size) != true)
		{
			return DLC_STS_INVALID_PARAMS;
		}

		buffer = dbm_buffer_create(psDrmDev->dbm_dev,
					   dbm_size,
					   dbm_flags);
		if (!buffer)
		{
			return DLC_STS_OUT_OF_MEMORY;
		}

		vaddr = dbm_buffer_cpu_access_prepare(buffer, true, true);
		if (vaddr == MAP_FAILED)
		{
			dbm_buffer_destroy(buffer);

			eStatus = DLC_STS_OUT_OF_MEMORY;
			goto err_alloc;
		}

		if (DLC_Socket_AllocateFB(psDrmDev->socket,
					  dbm_buffer_get_name(buffer),	// flink_name
					  width,
					  height,
					  dbm_format,
					  dbm_stride,
					  &gem_handle,
					  &fb_id))
		{
			dbm_buffer_cpu_access_finish(buffer);
			dbm_buffer_destroy(buffer);

			eStatus = DLC_STS_OUT_OF_MEMORY;
			goto err_alloc;
		}
	}
	else
	{
		eStatus = DLC_STS_COMMUNICATION_ERROR;
		goto err_alloc;
	}

	psDrmFB->eType = DLC_ALLOC_REMOTE;
	psDrmFB->primary_buffer = buffer;
	psDrmFB->fb_id = fb_id;
	psDrmFB->remote_handle = gem_handle;

	psDrmFB->sAttrib.uiHandle      = dbm_buffer_get_handle(psDrmFB->primary_buffer);
	psDrmFB->sAttrib.uiWidth       = width;
	psDrmFB->sAttrib.uiHeight      = height;
	psDrmFB->sAttrib.uiMemSize     = dbm_buffer_get_size(psDrmFB->primary_buffer);
	psDrmFB->sAttrib.uiStride      = dbm_stride;
	psDrmFB->sAttrib.ePixelFormat  = eFormat;
	psDrmFB->sAttrib.eMemLayout    = eMemLayout;
	psDrmFB->sAttrib.eCompression  = eCompression;
	psDrmFB->sAttrib.pvCpuVirtAddr = vaddr;

	*phFB = (DLC_HANDLE *)psDrmFB;

	return DLC_STS_OK;

err_alloc:
	free(psDrmFB);
	return eStatus;
}

/********************************************************************************
 Function	: DLC_DestroyRemoteFB
 In		: hDevice
		: hFB
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_DestroyRemoteFB(DLC_HANDLE hDevice, DLC_HANDLE hFB)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_FB *psDrmFB = (DLC_FB *)hFB;
	DLC_STATUS eStatus = DLC_STS_OK;

	if (!psDrmDev || !psDrmFB || !psDrmFB->primary_buffer || (psDrmFB->eType != DLC_ALLOC_REMOTE))
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_DestroyFB(psDrmDev->socket, psDrmFB->remote_handle, psDrmFB->fb_id))
		{
			eStatus = dlc_status;
		}

		dbm_buffer_cpu_access_finish(psDrmFB->primary_buffer);
		dbm_buffer_destroy(psDrmFB->primary_buffer);
	}
	else
	{
		return DLC_STS_COMMUNICATION_ERROR;
	}

	free(psDrmFB);

	return eStatus;
}

/********************************************************************************
 Function	: DLC_GetRemoteFBVAddr
 In		: hFB
 Out		: vaddr
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetRemoteFBVAddr(DLC_HANDLE hFB, void **vaddr)
{
	DLC_FB *psDrmFB = (DLC_FB *)hFB;

	if (!psDrmFB || (psDrmFB->eType != DLC_ALLOC_REMOTE))
	{
		return DLC_STS_INVALID_PARAMS;
	}

	*vaddr = psDrmFB->sAttrib.pvCpuVirtAddr;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_GetBufferAttributes
 In		: hDevice
 Out		: psAttrib
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetBufferAttributes(DLC_HANDLE hFB, DLC_BUFFER_ATTRIBUTES *psAttrib)
{
	DLC_FB *psDrmFB = (DLC_FB *)hFB;

	if (!psDrmFB)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	*psAttrib = psDrmFB->sAttrib;

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_FBPrimeHandleToFD
 In		: hFB
 Out		: prime_fd
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_FBPrimeHandleToFD(DLC_HANDLE hFB, int *prime_fd)
{
	DLC_FB *psDrmFB = (DLC_FB *)hFB;

	if (!psDrmFB || !psDrmFB->primary_buffer)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	*prime_fd = dbm_buffer_get_fd(psDrmFB->primary_buffer);

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_GetPlaneProperty
 In		: hDevice
		: hPlane
		: eProp
 Out		: value
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_GetPlaneProperty(DLC_HANDLE hDevice, DLC_HANDLE hPlane, DLC_PLANE_PROPERTY eProp, unsigned int *value)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_PLANE *psDrmPlane = (DLC_PLANE *)hPlane;

	if (!psDrmDev || !psDrmPlane || !value)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_GetPlaneProperty(psDrmDev->socket, psDrmPlane->index, eProp, value))
		{
			return dlc_status;
		}
	}
	else
	{
		drmModeObjectProperties *props;
		char *prop_name;
		int i;
		int found = 0;

		if (eProp == DLC_PLANE_PROP_ALPHA)
		{
			prop_name = "alpha";
		}
		else if (eProp == DLC_PLANE_PROP_COLORKEY)
		{
			prop_name = "colorkey";
		}
		else if (eProp == DLC_PLANE_PROP_PRIORITY)
		{
			prop_name = "zpos";
		}
		else if (eProp == DLC_PLANE_PROP_CHANNEL)
		{
			prop_name = "channel";
		}
		else
		{
			return DLC_STS_INVALID_PARAMS;
		}

		props = drmModeObjectGetProperties(psDrmDev->fd, psDrmPlane->plane_id, DRM_MODE_OBJECT_PLANE);
		if (props)
		{
			for (i = 0; i < (int)props->count_props; i++)
			{
				drmModePropertyRes *plane_prop;

				plane_prop = drmModeGetProperty(psDrmDev->fd, props->props[i]);
				if (!strcmp(plane_prop->name, prop_name))
				{
					found = 1;
				}
				drmModeFreeProperty(plane_prop);
				if (found)
				{
					break;
				}

			}
			drmModeFreeObjectProperties(props);

		}

		if (found)
		{
			*value = props->prop_values[i];
		}
	}

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_SetPlaneProperty
 In		: hDevice
		: hPlane
		: eProp
		: value
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_SetPlaneProperty(DLC_HANDLE hDevice, DLC_HANDLE hPlane, DLC_PLANE_PROPERTY eProp, unsigned int value)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_PLANE *psDrmPlane = (DLC_PLANE *)hPlane;

	DLC_STATUS eStatus = DLC_STS_OK;

	if (!psDrmDev || !psDrmPlane)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_SetPlaneProperty(psDrmDev->socket, psDrmPlane->index, eProp, value))
		{
			return dlc_status;
		}
	}
	else
	{
		drmModeObjectProperties *props;
		char *prop_name;
		int i;
		int found = 0;

		if (eProp == DLC_PLANE_PROP_ALPHA)
		{
			prop_name = "alpha";
		}
		else if (eProp == DLC_PLANE_PROP_COLORKEY)
		{
			prop_name = "colorkey";
		}
		else if (eProp == DLC_PLANE_PROP_PRIORITY)
		{
			prop_name = "zpos";
		}
		else if (eProp == DLC_PLANE_PROP_CHANNEL)
		{
			prop_name = "channel";
		}
		else
		{
			return DLC_STS_INVALID_PARAMS;
		}

		props = drmModeObjectGetProperties(psDrmDev->fd, psDrmPlane->plane_id, DRM_MODE_OBJECT_PLANE);
		if (props)
		{
			for (i = 0; i < (int)props->count_props; i++)
			{
				drmModePropertyRes *plane_prop;

				plane_prop = drmModeGetProperty(psDrmDev->fd, props->props[i]);
				if (!strcmp(plane_prop->name, prop_name))
				{
					found = 1;
				}
				drmModeFreeProperty(plane_prop);
				if (found)
				{
					break;
				}
			}
		}

		if (found)
		{
			drmSetMaster(psDrmDev->fd);
			if (drmModeObjectSetProperty(psDrmDev->fd, psDrmPlane->plane_id,
							DRM_MODE_OBJECT_PLANE, props->props[i], value))
			{
				eStatus = DLC_STS_NOT_SUPPORTED;
			}
			drmDropMaster(psDrmDev->fd);
		}
		else
		{
			eStatus = DLC_STS_NOT_SUPPORTED;
		}
		drmModeFreeObjectProperties(props);
	}

	return eStatus;
}

/********************************************************************************
 Function	: DLC_SetPlane
 In		: hDevice
		: hPlane
		: hFB
		: pos_x,  pos_y
		: disp_w, disp_h
		: src_x,  src_y
		: vinterval
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_SetPlane(DLC_HANDLE hDevice, DLC_HANDLE hPlane, DLC_HANDLE hFB,
					unsigned int pos_x, unsigned int pos_y,
					unsigned int disp_w, unsigned int disp_h,
					unsigned int src_x, unsigned int src_y,
					unsigned int vinterval)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_PLANE *psDrmPlane = (DLC_PLANE *)hPlane;
	DLC_FB *psDrmFB = (DLC_FB *)hFB;

	if (!psDrmDev || !psDrmPlane || !psDrmFB)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_SetPlane(psDrmDev->socket,
					psDrmPlane->connector_index,
					psDrmPlane->index,
					psDrmPlane->crtc_index,
					psDrmFB->fb_id,
					pos_x, pos_y,
					disp_w, disp_h,
					src_x, src_y,
					disp_w, disp_h,
					vinterval))
		{
			return dlc_status;
		}
	}
	else
	{
		int ret;

		drmSetMaster(psDrmDev->fd);

		/* show plane */
		ret = drmModeSetPlane(psDrmDev->fd,
						psDrmPlane->plane_id, psDrmPlane->crtc_id,
						psDrmFB->fb_id, 0,
						pos_x, pos_y,
						disp_w, disp_h,
						src_x << 16, src_y << 16,
						disp_w << 16, disp_h << 16);
		drmDropMaster(psDrmDev->fd);

		if (ret)
		{
			switch (errno)
			{
			case ENOENT:
				/* bad fb */
				return DLC_STS_INVALID_FB;
			case EBUSY:
				/* plane is busy (for V-IN ?) */
				return DLC_STS_PLANE_BUSY;
			case ENOSPC:
				/* plane rectangle is lager than fb */
				return DLC_STS_PLANE_BAD_SRC_SIZE;
			case ERANGE:
				/* crtc coordinates is lager than system max */
				return DLC_STS_PLANE_BAD_CRTC_SIZE;
			case EINVAL:
				/* bad combination of plane and crtc */
				/* fall through */
			default:
				return DLC_STS_INVALID_PARAMS;
			}
		}

		if (vinterval > 0)
		{
			unsigned int vbl_flags;
			drmVBlank vbl;

			vbl_flags = DRM_VBLANK_RELATIVE;

			if (psDrmPlane->crtc_index == 1)
			{
				vbl_flags |= DRM_VBLANK_SECONDARY;
			}
			else if (psDrmPlane->crtc_index >= 2)
			{
				vbl_flags |= ((psDrmPlane->crtc_index << DRM_VBLANK_HIGH_CRTC_SHIFT) & DRM_VBLANK_HIGH_CRTC_MASK);
			}

			vbl.request.type = vbl_flags;
			vbl.request.sequence = vinterval;

			(void)drmWaitVBlank(psDrmDev->fd, &vbl);
		}
	}

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_SetPlaneDC
 In		: hDevice
		: hPlane
		: hFB
		: pos_x,  pos_y
		: disp_w, disp_h
		: src_x,  src_y
		: dc_devid
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_SetPlaneDC(DLC_HANDLE hDevice, DLC_HANDLE hPlane, DLC_HANDLE hFB,
					unsigned int pos_x, unsigned int pos_y,
					unsigned int disp_w, unsigned int disp_h,
					unsigned int src_x, unsigned int src_y,
					unsigned int dc_devid)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_PLANE *psDrmPlane = (DLC_PLANE *)hPlane;
	DLC_FB *psDrmFB = (DLC_FB *)hFB;

	if (!psDrmDev || !psDrmPlane || !psDrmFB)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_SetPlaneDC(psDrmDev->socket,
						psDrmPlane->connector_index,
						psDrmPlane->index,
						psDrmPlane->crtc_index,
						psDrmFB->fb_id,
						pos_x, pos_y,
						disp_w, disp_h,
						src_x, src_y,
						disp_w, disp_h,
						dc_devid))
		{
			return dlc_status;
		}
	}

	return DLC_STS_OK;
}

/*
 * CRTC functions.
 */

/********************************************************************************
 Function	: DLC_AcquireDesktop
 In		: hDevice
		: hCrtc
		: buffers
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_AcquireDesktop(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, int buffers)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;

	if (!psDrmDev || !psDrmCrtc)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_AcquireDesktop(psDrmDev->socket, psDrmCrtc->index, buffers))
		{
			return dlc_status;
		}
	}

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_ReleaseDesktop
 In		: hDevice
		: hCrtc
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_ReleaseDesktop(DLC_HANDLE hDevice, DLC_HANDLE hCrtc)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;
	DLC_STATUS eStatus = DLC_STS_OK;

	if (!psDrmDev || !psDrmCrtc)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if(DLC_Socket_ReleaseDesktop(psDrmDev->socket, psDrmCrtc->index))
		{
			eStatus = dlc_status;
		}
	}

	return eStatus;
}

/********************************************************************************
 Function	: DLC_QueryCrtcMode
 In		: hDevice
		: hCrtc
 Out		: width
		: height
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_QueryCrtcMode(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, unsigned int *width, unsigned int *height)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;
	drmModeCrtc *mode_crtc;

	if (!psDrmDev || !psDrmCrtc || !width || !height)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	mode_crtc = drmModeGetCrtc(psDrmDev->fd, psDrmCrtc->crtc_id);
	if (!mode_crtc)
	{
		return DLC_STS_OUT_OF_MEMORY;
	}

	*width = mode_crtc->width;
	*height = mode_crtc->height;

	/* store the previous settings */
	psDrmCrtc->old_buf_id	= mode_crtc->buffer_id;
	psDrmCrtc->old_width	= mode_crtc->width;
	psDrmCrtc->old_height	= mode_crtc->height;
	psDrmCrtc->old_x	= mode_crtc->x;
	psDrmCrtc->old_y	= mode_crtc->y;
	psDrmCrtc->old_mode	= mode_crtc->mode;

	drmModeFreeCrtc(mode_crtc);

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_SetCrtcMode
 In		: hDevice
		: hCrtc
		: hFB
		: disp_w, disp_h
		: src_x, src_y
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_SetCrtcMode(DLC_HANDLE hDevice, DLC_HANDLE hCrtc,
				DLC_HANDLE hFB,
				unsigned int disp_w, unsigned int disp_h,
				unsigned int src_x, unsigned int src_y)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;
	DLC_FB *psDrmFB = (DLC_FB *)hFB;
	unsigned int fb_id;

	if (!psDrmDev || !psDrmCrtc)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmFB)
	{
		fb_id = psDrmFB->fb_id;
	}
	else
	{
		fb_id = psDrmCrtc->old_buf_id;
		disp_w = psDrmCrtc->old_width;
		disp_h = psDrmCrtc->old_height;
		src_x = psDrmCrtc->old_x;
		src_y = psDrmCrtc->old_y;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_SetCrtcMode(psDrmDev->socket,
						psDrmCrtc->index,
						psDrmCrtc->connector_index,
						fb_id,
						disp_w, disp_h,
						src_x, src_y))
		{
			return dlc_status;
		}

		/* DPMS ON */
		if (DLC_Socket_SetDpmsMode(psDrmDev->socket,
						psDrmCrtc->connector_index,
						DRM_MODE_DPMS_ON))
		{
			return dlc_status;
		}
	}
	else
	{
		drmModeConnector *mode_conn;
		drmModeModeInfo *new_mode = NULL;
		int i;
		int ret;

		mode_conn = drmModeGetConnector(psDrmDev->fd, psDrmCrtc->connector_id);

		for (i = 0; i < mode_conn->count_modes; i++)
		{
			if ((mode_conn->modes[i].hdisplay == disp_w) && 
				(mode_conn->modes[i].vdisplay == disp_h)) 
			{ 
				new_mode = &mode_conn->modes[i]; 
				if (mode_conn->modes[i].type & DRM_MODE_TYPE_PREFERRED) 
				{
					break;
				}
			}
		}
		if (!new_mode)
		{
			drmModeFreeConnector(mode_conn);
			return DLC_STS_INVALID_PARAMS;
		}

		drmSetMaster(psDrmDev->fd);

		/* DPMS ON */
		for (i = 0; i < mode_conn->count_props; i++) 
		{ 
			drmModePropertyRes *conn_prop; 

			conn_prop = drmModeGetProperty(psDrmDev->fd, mode_conn->props[i]); 
			if (!conn_prop) 
			{ 
				break; 
			} 
			if (!strcmp(conn_prop->name, "DPMS")) 
			{ 
				int dpms_id = mode_conn->props[i]; 
				drmModeConnectorSetProperty(psDrmDev->fd, psDrmCrtc->connector_id, dpms_id, DRM_MODE_DPMS_ON); 
			} 
			drmModeFreeProperty(conn_prop); 
		} 


		/* setup crtc mode */
		ret = drmModeSetCrtc(psDrmDev->fd, psDrmCrtc->crtc_id,
						   fb_id,
						   src_x, src_y,
						   &psDrmCrtc->connector_id,
						   1,
						   new_mode);
		drmModeFreeConnector(mode_conn);

		drmDropMaster(psDrmDev->fd);

		if (ret)
		{
			switch (errno)
			{
			case EINVAL:
				/* fall through */
			default:
				return DLC_STS_INVALID_PARAMS;
			}
		}

	}

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_WaitForVBlank
 In		: hDevice
		: hCrtc
		: vinterval
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_WaitForVBlank(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, unsigned int vinterval)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;

	if (!psDrmDev || !psDrmCrtc)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (vinterval > 0)
	{
		unsigned int vbl_flags;
		drmVBlank vbl;

		vbl_flags = DRM_VBLANK_RELATIVE;

		if (psDrmCrtc->index == 1)
		{
			vbl_flags |= DRM_VBLANK_SECONDARY;
		}
		else if (psDrmCrtc->index >= 2)
		{
			vbl_flags |= ((psDrmCrtc->index << DRM_VBLANK_HIGH_CRTC_SHIFT) & DRM_VBLANK_HIGH_CRTC_MASK);
		}

		vbl.request.type = vbl_flags;
		vbl.request.sequence = vinterval;

		(void)drmWaitVBlank(psDrmDev->fd, &vbl);
	}

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_PageFlip
 In		: hDevice
		: hCrtc
		: hFB
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_PageFlip(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, DLC_HANDLE hFB,
			unsigned int vinterval)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;
	DLC_FB *psDrmFB = (DLC_FB *)hFB;

	if (!psDrmDev || !psDrmCrtc || !psDrmFB)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_PageFlip(psDrmDev->socket,
						psDrmCrtc->index,
						psDrmFB->fb_id,
						vinterval))
		{
			return dlc_status;
		}
	}
	else
	{
		int ret;

		drmSetMaster(psDrmDev->fd);
		ret = drmModePageFlip(psDrmDev->fd, psDrmCrtc->crtc_id,
					psDrmFB->fb_id, 0, NULL);
		drmDropMaster(psDrmDev->fd);

		if (ret)
		{
			switch (errno)
			{
			case EINVAL:
				/* fall through */
			default:
				return DLC_STS_INVALID_PARAMS;
			}
		}

		if (vinterval > 1)
		{
			unsigned int vbl_flags;
			drmVBlank vbl;

			vbl_flags = DRM_VBLANK_RELATIVE;

			if (psDrmCrtc->index == 1)
			{
				vbl_flags |= DRM_VBLANK_SECONDARY;
			}
			else if (psDrmCrtc->index >= 2)
			{
				vbl_flags |= ((psDrmCrtc->index << DRM_VBLANK_HIGH_CRTC_SHIFT) & DRM_VBLANK_HIGH_CRTC_MASK);
			}

			vbl.request.type = vbl_flags;
			vbl.request.sequence = vinterval-1;

			(void)drmWaitVBlank(psDrmDev->fd, &vbl);
		}
	}

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_PageFlipDC
 In		: hDevice
		: hCrtc
		: hFB
		: dc_devid
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_PageFlipDC(DLC_HANDLE hDevice, DLC_HANDLE hCrtc, DLC_HANDLE hFB, unsigned int dc_devid)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;
	DLC_FB *psDrmFB = (DLC_FB *)hFB;

	if (!psDrmDev || !psDrmCrtc || !psDrmFB)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_PageFlipDC(psDrmDev->socket,
						psDrmCrtc->index,
						psDrmFB->fb_id,
						dc_devid))
		{
			return dlc_status;
		}
	}

	return DLC_STS_OK;
}



/********************************************************************************
 Function	: DLC_AcquireDeviceDC
 In		: hDevice
		: hPlane
		: hCrtc
		: width, height
		: bytestride
		: format
		: buffers
 Out		: vaddr
		: dc_devid
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_AcquireDeviceDC(DLC_HANDLE hDevice, DLC_HANDLE hPlane,
					DLC_HANDLE hCrtc,
					unsigned int width,
					unsigned int height,
					unsigned int bytestride,
					unsigned int format,
					int buffers,
					unsigned long long *vaddr,
					unsigned int *dc_devid)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_PLANE *psDrmPlane = (DLC_PLANE *)hPlane;
	DLC_PLANE *psDrmCrtc = (DLC_PLANE *)hCrtc;

	unsigned int plane_index = 0xFFFFFFFFUL;
	unsigned int crtc_index = 0xFFFFFFFFUL;

	if (!psDrmDev || (!psDrmPlane && !psDrmCrtc) || !vaddr || !dc_devid)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmPlane)
	{
		plane_index = psDrmPlane->index;
		crtc_index = psDrmPlane->crtc_index;
	}
	else
	{
		crtc_index = psDrmCrtc->index;
	}

	if (buffers > DLC_MAX_BUFFERS)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_AcquireDeviceDC(psDrmDev->socket,
						plane_index,
						crtc_index,
						width, height,
						bytestride, format,
						buffers,
						vaddr,
						dc_devid))
		{
			return dlc_status;
		}
	}
	else
	{
		return DLC_STS_COMMUNICATION_ERROR;
	}

	return DLC_STS_OK;
}

/********************************************************************************
 Function	: DLC_ReleaseDeviceDC
 In		: hDevice
		: hPlane
		: hCrtc
 Out		: 
 Result		: Error code
 Description	:
 ********************************************************************************/
DLC_STATUS DLC_ReleaseDeviceDC(DLC_HANDLE hDevice, DLC_HANDLE hPlane, DLC_HANDLE hCrtc)
{
	DLC_DRMDEV *psDrmDev = (DLC_DRMDEV *)hDevice;
	DLC_PLANE *psDrmPlane = (DLC_PLANE *)hPlane;
	DLC_DRMCRTC *psDrmCrtc = (DLC_DRMCRTC *)hCrtc;

	unsigned int plane_index = 0xFFFFFFFFUL;
	unsigned int crtc_index = 0xFFFFFFFFUL;

	if (!psDrmDev || (!psDrmPlane && !psDrmCrtc))
	{
		return DLC_STS_INVALID_PARAMS;
	}

	if (psDrmPlane)
	{
		plane_index = psDrmPlane->index;
	}
	else
	{
		crtc_index = psDrmCrtc->index;
	}

	if (psDrmDev->socket_mode)
	{
		if (DLC_Socket_ReleaseDeviceDC(psDrmDev->socket,
						plane_index, crtc_index))
		{
			return dlc_status;
		}
	}
	else
	{
		return DLC_STS_COMMUNICATION_ERROR;
	}

	return DLC_STS_OK;
}

