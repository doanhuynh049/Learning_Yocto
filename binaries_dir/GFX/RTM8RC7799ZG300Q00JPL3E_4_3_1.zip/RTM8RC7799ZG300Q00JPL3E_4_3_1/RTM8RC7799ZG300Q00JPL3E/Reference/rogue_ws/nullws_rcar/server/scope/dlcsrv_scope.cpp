/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <PVRScopeComms.h>
#include "dlcsrv_scope.h"


//#define USE_COUNTER_TABLE
//#define USE_REMOTE_EDITOR


#define ARRAY_SIZE(array) (sizeof(array) / sizeof((array)[0]))


#if defined(USE_COUNTER_TABLE)
enum DLCScopeCustomCounters {
	eCounter,
	eNumCounter
};
unsigned int newValueArray[eNumCounter] = { 0 };
unsigned int frameCounter = 0;
#endif /* USE_COUNTER_TABLE */

#if defined(USE_REMOTE_EDITOR)
enum DLCScopeEditableInts {
	eCrtc,
	ePlane,
	eFb,
	eNumInts
};
unsigned int numEditableItems = (unsigned int)eNumInts;
#endif /* USE_REMOTE_EDITOR */


typedef struct DLCSRV_SCOPE_TAG
{
	char acContextName[64];
	char acFrameName[64];
	unsigned int uiFrameNum;
	int iFrameNum;
	eScopeBool eFrameStart;

	unsigned int uiRetainCount;

	char acIdName[64];
	unsigned int id;

	struct SSPSCommsData* DLCScopeComms;

#if defined(USE_REMOTE_EDITOR)
	struct SSPSCommsLibraryItem editableItemArray[3];
	struct SSPSCommsLibraryTypeInt scopeCrtc;
	struct SSPSCommsLibraryTypeInt scopePlane;
	struct SSPSCommsLibraryTypeInt scopeFb;
#endif /* USE_REMOTE_EDITOR */

} DLCSRV_SCOPE;


/***********************************************************************************
 Function Name      : DLCScope_Acquire
 Inputs             : name, idname, id, eSync
 Outputs            : None
 Returns            : SCOPE_HANDLE
 Description        : 
************************************************************************************/
SCOPE_HANDLE DLCScope_Acquire(const char *name, const char *idname, unsigned int id, eScopeBool eSync)
{
	DLCSRV_SCOPE *pvContext;
	pvContext = (DLCSRV_SCOPE *)calloc(1, sizeof(DLCSRV_SCOPE));
	if (!pvContext)
	{
		return NULL;
	}

	strncpy(pvContext->acIdName, idname, (strlen(idname) <= ARRAY_SIZE(pvContext->acIdName) ? strlen(idname) : ARRAY_SIZE(pvContext->acIdName)));
	pvContext->id = id;

	// Initialise the communication with PVRTune.
	snprintf(pvContext->acContextName, ARRAY_SIZE(pvContext->acContextName), "%s(%s %d)", name, idname, id);
	pvContext->DLCScopeComms = pplInitialise(pvContext->acContextName, strlen(pvContext->acContextName));

	if (eSync == SCOPE_TRUE)
	{
		int isConnected = 0;
		// data connection to PVRPerfServer
		// Send the mark to PVRTune
		pplSendMark(pvContext->DLCScopeComms, "lost", 4);
		pplWaitForConnection(pvContext->DLCScopeComms, &isConnected, 1, 100);
	}

#if defined (USE_COUNTER_TABLE)
	{
		newValueArray[0] = 0;
		frameCounter = 0;

		// Create a Custom Counter
		struct SSPSCommsCounterDef DLCScopeCustomCounterArray[eNumCounter];
		DLCScopeCustomCounterArray[0].pszName = pvContext->acContextName;
		DLCScopeCustomCounterArray[0].nNameLength = strlen(pvContext->acContextName);

		// Submit and initial value the Custom Counter to PVRTune
		pplCountersCreate(pvContext->DLCScopeComms, DLCScopeCustomCounterArray, (unsigned int)eNumCounter);
		pplCountersUpdate(pvContext->DLCScopeComms, newValueArray);
	}
#endif /* USE_COUNTER_TABLE */

#if defined(USE_REMOTE_EDITOR)
	{
		int i;

		// Create default values for Editable items
		for (i = 0; i < (int)numEditableItems; i++)
		{
			switch (i)
			{
			case eCrtc:
				pvContext->editableItemArray[i].pszName = "crtc";
				pvContext->editableItemArray[i].eType = eSPSCommsLibTypeInt;
				pvContext->scopeCrtc.nCurrent = 33;
				pvContext->scopeCrtc.nMin = 0;
				pvContext->scopeCrtc.nMax = 100;
				pvContext->editableItemArray[i].pData = (const char*)&pvContext->scopeCrtc;
				pvContext->editableItemArray[i].nDataLength = sizeof(pvContext->scopeCrtc);
				break;
			case ePlane:
				pvContext->editableItemArray[i].pszName = "plane";
				pvContext->editableItemArray[i].eType = eSPSCommsLibTypeInt;
				pvContext->scopePlane.nCurrent = 3;
				pvContext->scopePlane.nMin = 0;
				pvContext->scopePlane.nMax = 10;
				pvContext->editableItemArray[i].pData = (const char*)&pvContext->scopePlane;
				pvContext->editableItemArray[i].nDataLength = sizeof(pvContext->scopePlane);
				break;
			case eFb:
				pvContext->editableItemArray[i].pszName = "fb";
				pvContext->editableItemArray[i].eType = eSPSCommsLibTypeInt;
				pvContext->scopeFb.nCurrent = 33;
				pvContext->scopeFb.nMin = 0;
				pvContext->scopeFb.nMax = 100;
				pvContext->editableItemArray[i].pData = (const char*)&pvContext->scopeFb;
				pvContext->editableItemArray[i].nDataLength = sizeof(pvContext->scopeFb);
				break;
			default:
				break;
			}
			pvContext->editableItemArray[i].nNameLength = (unsigned int)strlen(pvContext->editableItemArray[i].pszName);
		}

		// Submit the array of editable items to PVRTune
		pplLibraryCreate(pvContext->DLCScopeComms, pvContext->editableItemArray, numEditableItems);
	}
#endif /* USE_REMOTE_EDITOR */

	return (SCOPE_HANDLE)pvContext;
}

/***********************************************************************************
 Function Name      : DLCScope_Release
 Inputs             : hHandle
 Outputs            : None
 Returns            : None
 Description        : Shutdown DLCScopeComms
************************************************************************************/
void DLCScope_Release(SCOPE_HANDLE hHandle)
{
	DLCSRV_SCOPE *pvContext = (DLCSRV_SCOPE *)hHandle;
	if (pvContext)
	{
		pplShutdown(pvContext->DLCScopeComms);
		free(pvContext);
	}
}

/***********************************************************************************
 Function Name      : DLCScope_StartContext / DLCScope_StopContext
 Inputs             : hHandle
 Outputs            : None
 Returns            : None
 Description        : Logging start / stop
************************************************************************************/
void DLCScope_StartContext(SCOPE_HANDLE hHandle)
{
	DLCSRV_SCOPE *pvContext = (DLCSRV_SCOPE *)hHandle;
	if (pvContext)
	{
		if (pvContext->uiRetainCount == 0)
		{
			pvContext->eFrameStart = SCOPE_TRUE;
			pvContext->iFrameNum = -1;
		}
		pvContext->uiRetainCount++;
	}
}

void DLCScope_StopContext(SCOPE_HANDLE hHandle)
{
	DLCSRV_SCOPE *pvContext = (DLCSRV_SCOPE *)hHandle;
	if (pvContext)
	{
		pvContext->uiRetainCount = pvContext->uiRetainCount > 0 ? pvContext->uiRetainCount -1 : 0;
		if (pvContext->uiRetainCount == 0)
		{
			pvContext->eFrameStart = SCOPE_FALSE;
			pvContext->iFrameNum = -1;
		}
	}
}

/***********************************************************************************
 Function Name      : DLCScope_UpdateFrame
 Inputs             : hHandle
 Outputs            : None
 Returns            : None
 Description        : Updating and Sending the Counter Value
************************************************************************************/
void DLCScope_UpdateFrame(SCOPE_HANDLE hHandle)
{
	DLCSRV_SCOPE *pvContext = (DLCSRV_SCOPE *)hHandle;
	if (!pvContext)
	{
		return;
	}

	// update frame counters
	if (pvContext->eFrameStart == SCOPE_TRUE)
	{
		pvContext->iFrameNum += 1;
	}

#if defined(USE_REMOTE_EDITOR)
	if (pvContext->DLCScopeComms)
	{
		unsigned int itemNum = 0;
		unsigned int itemLength = 0;
		int newGetArray[3] = {0};
		const char* itemData = NULL;
		const struct SSPSCommsLibraryTypeInt* newItemData;

		// Retrieve the updated items from PVRTune
		while (pplLibraryDirtyGetFirst(pvContext->DLCScopeComms, &itemNum, &itemLength, &itemData))
		{
			switch (itemNum)
			{
			case eCrtc:
				if (itemLength == sizeof(struct SSPSCommsLibraryTypeInt))
				{
					newItemData = (struct SSPSCommsLibraryTypeInt *)itemData;
					newGetArray[eCrtc] = newItemData->nCurrent;
				}
				break;
			case ePlane:
				if (itemLength == sizeof(struct SSPSCommsLibraryTypeInt))
				{
					newItemData = (struct SSPSCommsLibraryTypeInt*)itemData;
					newGetArray[ePlane] = newItemData->nCurrent;
				}
				break;
			case eFb:
				if (itemLength == sizeof(struct SSPSCommsLibraryTypeInt))
				{
					newItemData = (struct SSPSCommsLibraryTypeInt*)itemData;
					newGetArray[eFb] = newItemData->nCurrent;
				}
				break;
			default:
				break;
			}
		}
	}
#endif /* USE_REMOTE_EDITOR */

#if defined (USE_COUNTER_TABLE)
	if (pvContext->DLCScopeComms)
	{
		newValueArray[0] = frameCounter;

		// Submit counters for transmission
		pplCountersUpdate(pvContext->DLCScopeComms, newValueArray);
	}

	// update some counters
	frameCounter += 1;
#endif /* USE_COUNTER_TABLE */
}

/***********************************************************************************
 Function Name      : DLCScope_TimingBegin
 Inputs             : hHandle, cpTaskName, uiCrtcID, uiPlaneID, uiFbID
 Outputs            : None
 Returns            : None
 Description        : Starting a Timing Block
************************************************************************************/
void DLCScope_TimingBegin(SCOPE_HANDLE hHandle, const char *cpTaskName, unsigned int uiPlaneID, unsigned int uiFbID)
{
	DLCSRV_SCOPE *pvContext = (DLCSRV_SCOPE *)hHandle;
	int len = 0;
	unsigned int uiFrameNum = 0;

	if (pvContext)
	{
		len = snprintf(&pvContext->acFrameName[len], ARRAY_SIZE(pvContext->acFrameName)-len, cpTaskName);
		if (uiPlaneID > 0)
		{
			len += snprintf(&pvContext->acFrameName[len], ARRAY_SIZE(pvContext->acFrameName)-len, ": Plane %u", uiPlaneID);
		}
		if (uiFbID > 0)
		{
			len += snprintf(&pvContext->acFrameName[len], ARRAY_SIZE(pvContext->acFrameName)-len, ": FB %u", uiFbID);
		}

		if (pvContext->iFrameNum >= 0)
		{
			uiFrameNum = (unsigned int)pvContext->iFrameNum;
		}
		pplSendProcessingBegin(pvContext->DLCScopeComms, pvContext->acFrameName, strlen(pvContext->acFrameName), uiFrameNum);
	}
}

/***********************************************************************************
 Function Name      : DLCScope_TimingEnd
 Inputs             : hHandle
 Outputs            : None
 Returns            : None
 Description        : Ending a Timing Block
************************************************************************************/
void DLCScope_TimingEnd(SCOPE_HANDLE hHandle)
{
	DLCSRV_SCOPE *pvContext = (DLCSRV_SCOPE *)hHandle;
	if (pvContext)
	{
		pplSendProcessingEnd(pvContext->DLCScopeComms);
	}
}

/***********************************************************************************
 Function Name      : DLCScope_TimingVSYNC
 Inputs             : hHandle
 Outputs            : None
 Returns            : None
 Description        : 
************************************************************************************/
void DLCScope_TimingVSYNC(SCOPE_HANDLE hHandle)
{
	unsigned int uiFrameNum = 0;
	DLCSRV_SCOPE *pvContext = (DLCSRV_SCOPE *)hHandle;
	if (pvContext)
	{
		if (pvContext->eFrameStart == SCOPE_TRUE)
		{
			if (pvContext->iFrameNum >= 0)
			{
				uiFrameNum = (unsigned int)pvContext->iFrameNum;
			}
			pplSendProcessingEnd(pvContext->DLCScopeComms);
			pplSendProcessingBegin(pvContext->DLCScopeComms, "VBlank", strlen("VBlank"), uiFrameNum);
		}
	}
}
