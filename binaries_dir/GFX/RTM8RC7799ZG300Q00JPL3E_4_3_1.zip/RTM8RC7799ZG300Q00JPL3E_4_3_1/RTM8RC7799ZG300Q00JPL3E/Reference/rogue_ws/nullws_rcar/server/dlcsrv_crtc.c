/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

/*
 * DRM Layer Compositor Server
 *
 *      libdrm access functions
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>

#include "dlcsrv_common.h"

extern int drmFd;
extern drmModeRes *mode_res;
extern drmModePlaneRes *plane_univ_res;

extern DLCSRV_DESKTOP_STATUS *desktop_stat;

extern pthread_mutex_t drm_mutex;

static inline unsigned int CrtcIndexToID(int index)
{
	if (index >= mode_res->count_crtcs)
	{
		return 0;
	}

	return mode_res->crtcs[index];
}

static inline unsigned int ConnectorIndexToID(int index)
{
	if (index >= mode_res->count_connectors)
	{
		return 0;
	}

	return mode_res->connectors[index];
}

DLC_STATUS DLCSRV_SubAcquireDesktop(int crtc_index, int buffers)
{
#ifdef USE_DRMATOMIC
	DLCSRV_DESKTOP_STATUS *desktop = &desktop_stat[crtc_index];
	DLCSRV_PLANE_STATUS *plane = &desktop->plane;
	unsigned int fb_id;
	int i;
	drmModePlane *mode_plane;
	int found = 0;
	DLCSRV_PROPEATY_ID property_id;

	DLC_STATUS eStatus = DLC_STS_OK;

	if (buffers > DLCSRV_MAX_BUFFERS)
	{
		return DLC_STS_TOO_MANY_BUFFERS;
	}

	pthread_mutex_lock(&drm_mutex);

	/* search primary plane */
	for (i = 0; i < (int)plane_univ_res->count_planes; i++)
	{
		mode_plane = drmModeGetPlane(drmFd, plane_univ_res->planes[i]);
		if (!mode_plane)
		{
			if (errno == ENOMEM)
			{
				eStatus = DLC_STS_OUT_OF_MEMORY;
			}
			else
			{
				eStatus = DLC_STS_INVALID_PARAMS;
			}
			break;
		}

		if (mode_plane->possible_crtcs & (1 << crtc_index))
		{
			unsigned int value;

			DLCSRV_SubGetUniversalPlaneProperty(i, DLC_PLANE_PROPERTY_TYPE, &value);
			if (value != DRM_PLANE_TYPE_PRIMARY)
			{
				continue;
			}

			if (DLCSRV_SetMaster() == DLCSRV_OK)
			{
				eStatus = DLCSRV_GetPlaneProperties(plane_univ_res->planes[i], &property_id);
				DLCSRV_DropMaster();

				if  (eStatus != DLC_STS_OK)
				{
					continue;
				}
			}

			fb_id = mode_plane->fb_id;
			found++;
		}
		drmModeFreePlane(mode_plane);

		if (found)
		{
			desktop->plane_index = i; /* universal plane index */
			desktop->plane_id = plane_univ_res->planes[i];
			desktop->old_fb_id = fb_id;

			plane->in_use = 1;
			plane->crtc_index = crtc_index;

			plane->crtc_x = 0;
			plane->crtc_y = 0;
			plane->src_x = 0;
			plane->src_y = 0;
			DLCSRV_SubGetMode(crtc_index, &plane->crtc_w, &plane->crtc_h);
			DLCSRV_SubGetMode(crtc_index, &plane->src_w, &plane->src_h);

			plane->flip_index.insert = 0;
			plane->flip_index.remove = 0;
			plane->flip_index.current = 0;

			plane->buffers = buffers;
			plane->property_id = property_id;

			DLCSRV_DRMLog_StartContext(plane->crtc_index);

			break;
		}
	}

	pthread_mutex_unlock(&drm_mutex);

	if (!found)
	{
		eStatus = DLC_STS_PLANE_NOT_FOUND;
	}

	return eStatus;
#else
	DLC_UNREFERENCED_PARAMETER(crtc_index);
	DLC_UNREFERENCED_PARAMETER(buffers);

	return DLC_STS_OK;
#endif /* USE_DRMATOMIC */
}

DLC_STATUS DLCSRV_SubReleaseDesktop(int crtc_index)
{
	DLCSRV_DESKTOP_STATUS *desktop;
	DLCSRV_PLANE_STATUS *plane;

	if (crtc_index >= (int)mode_res->count_crtcs)
	{
		return DLC_STS_INVALID_CRTC;
	}

	desktop = &desktop_stat[crtc_index];
	plane = &desktop->plane;

#ifdef USE_DRMATOMIC
	DLCSRV_SubDisableDesktop(crtc_index);

	DLCSRV_DRMLog_StopContext(plane->crtc_index);
#endif /* USE_DRMATOMIC */

	pthread_mutex_lock(&drm_mutex);
	plane->in_use = 0;
	pthread_mutex_unlock(&drm_mutex);

	return DLC_STS_OK;
}

DLC_STATUS DLCSRV_SubDisableDesktop(int crtc_index)
{
#ifdef USE_DRMATOMIC
	DLCSRV_DESKTOP_STATUS *desktop;
	DLCSRV_PLANE_STATUS *plane;

	if (crtc_index >= (int)mode_res->count_crtcs)
	{
		return DLC_STS_INVALID_CRTC;
	}

	desktop = &desktop_stat[crtc_index];
	plane = &desktop->plane;

	pthread_mutex_lock(&drm_mutex);
	DLCSRV_SetMaster();
	if (plane->in_use)
	{
		DLCSRV_LOG_DEBUG("PLANE(id=%d): OFF\n", DLCSRV_UniversalPlaneIndexToId(desktop->plane_index));

		drmModeSetPlane(drmFd, DLCSRV_UniversalPlaneIndexToId(desktop->plane_index),
				DLCSRV_CrtcIndexToId(crtc_index), desktop->old_fb_id, 0,
				plane->crtc_x, plane->crtc_y, plane->crtc_w, plane->crtc_h,
				plane->src_x << 16, plane->src_y << 16, plane->src_w << 16, plane->src_h << 16);
	}
	DLCSRV_DropMaster();
	pthread_mutex_unlock(&drm_mutex);
#else
	DLC_UNREFERENCED_PARAMETER(crtc_index);
#endif /* USE_DRMATOMIC */

	return DLC_STS_OK;
}

DLC_STATUS DLCSRV_SubGetMode(int crtc_index, unsigned int *width, unsigned int *height)
{
	unsigned int crtc_id;
	drmModeCrtc *mode_crtc;

	if (!width || !height)
	{
		return DLC_STS_INVALID_PARAMS;
	}

	crtc_id = CrtcIndexToID(crtc_index);
	if (!crtc_id)
	{
		return DLC_STS_INVALID_CRTC;
	}

	mode_crtc = drmModeGetCrtc(drmFd, crtc_id);
	if (!mode_crtc)
	{
		return DLC_STS_INVALID_CRTC;
	}

	*width = mode_crtc->width;
	*height = mode_crtc->height;

	return DLC_STS_OK;
}

DLC_STATUS DLCSRV_SubSetMode(int crtc_index, int conn_index,
				unsigned int fb_id,
                                unsigned int width, unsigned int height,
                                unsigned int src_x, unsigned int src_y)
{
	unsigned int crtc_id;
	unsigned int conn_id;
	DLC_STATUS eStatus = DLC_STS_OK;
	drmModeConnector *mode_conn; 
	drmModeModeInfo *new_mode = NULL; 
	int i;

	crtc_id = CrtcIndexToID(crtc_index);
	if (!crtc_id)
	{
		return DLC_STS_INVALID_CRTC;
	}

	conn_id = ConnectorIndexToID(conn_index);
	if (!conn_id)
	{
		return DLC_STS_INVALID_CONNECTOR;
	}

	mode_conn = drmModeGetConnector(drmFd, conn_id);
	if (!mode_conn)
	{
		return DLC_STS_INVALID_CONNECTOR;
	}

	for (i = 0; i < mode_conn->count_modes; i++)
	{
		if ((mode_conn->modes[i].hdisplay == width) && 
			(mode_conn->modes[i].vdisplay == height))
		{
			new_mode = &mode_conn->modes[i];
			if (mode_conn->modes[i].type & DRM_MODE_TYPE_PREFERRED)
			{
				break;
			}
		}
	}

	if (!new_mode)
	{
		eStatus = DLC_STS_INVALID_PARAMS;
	}
	else
	{
		(void)DLCSRV_SetMaster();
		if (drmModeSetCrtc(drmFd, crtc_id, fb_id, src_x, src_y, &conn_id, 1, new_mode))
		{
			switch (errno)
			{
			case EBUSY:
				eStatus = DLC_STS_CRTC_BUSY;
				break;
			case ENOSPC:
				/* crtc viewport size is lager than fb size */
				eStatus = DLC_STS_CRTC_BAD_FB_SIZE;
				break;
			case ENOMEM:
				/* cannot allocate any crtc resouces */
				eStatus = DLC_STS_OUT_OF_MEMORY;
				break;
			case EINVAL:
				/* fall through */
			default:
				eStatus = DLC_STS_INVALID_PARAMS;
				break;
			}
		}
		(void)DLCSRV_DropMaster();
	}

        drmModeFreeConnector(mode_conn);

        return eStatus;

}

DLC_STATUS DLCSRV_PageFlip(int crtc_index, unsigned int fb_id)
{
	DLC_STATUS eStatus = DLC_STS_OK;

	DLCSRV_DRMLog_TimingBegin(crtc_index, "PageFlip", 0, fb_id, false);

	if (drmModePageFlip(drmFd, CrtcIndexToID(crtc_index), fb_id, 0, NULL))
	{
		DLCSRV_LOG_ERR("Flip-CRTC(%d): %s\n", CrtcIndexToID(crtc_index), strerror(errno));

		switch (errno)
		{
		case EBUSY:
			eStatus = DLC_STS_CRTC_BUSY;
			break;
		case ENOSPC:
			/* crtc viewport size is lager than fb size */
			eStatus = DLC_STS_CRTC_BAD_FB_SIZE;
			break;
		case ENOMEM:
			/* cannot allocate any crtc resouces */
			eStatus = DLC_STS_OUT_OF_MEMORY;
			break;
		case EINVAL:
			/* fall through */
		default:
			eStatus = DLC_STS_INVALID_PARAMS;
			break;
		}
	}

	DLCSRV_DRMLog_TimingEnd(crtc_index);

	return eStatus;
}

DLC_STATUS DLCSRV_SubPageFlip(int crtc_index, unsigned int fb_id)
{
	unsigned int crtc_id;
	DLC_STATUS eStatus = DLC_STS_OK;

	crtc_id = CrtcIndexToID(crtc_index);
	if (!crtc_id)
	{
		return DLC_STS_INVALID_CRTC;
	}

	if (!fb_id)
	{
		return DLC_STS_INVALID_FB;
	}

	pthread_mutex_lock(&drm_mutex);
	if (DLCSRV_SetMaster() == DLCSRV_OK)
	{
		eStatus = DLCSRV_PageFlip(crtc_index, fb_id);
		(void)DLCSRV_DropMaster();
	}
	else
	{
		eStatus = DLC_STS_NOT_A_MASTER;
	}
	pthread_mutex_unlock(&drm_mutex);

	return eStatus;
}

static void UpdateInsertIndex(DLCSRV_PLANE_STATUS *plane)
{
	plane->flip_index.insert++;

	if (plane->flip_index.insert >= plane->buffers)
	{
		plane->flip_index.insert = 0;
	}
}

DLC_STATUS DLCSRV_SubAddSetDesktopQueue(int client_fd, int crtc_index, unsigned int fb_id,
					unsigned int vinterval)
{
	DLCSRV_DESKTOP_STATUS *desktop;
	DLCSRV_PLANE_STATUS *plane;
	DLCSRV_FLIP_QUEUE *flip;

	if (crtc_index >= (int)mode_res->count_crtcs)
	{
		return DLC_STS_INVALID_CRTC;
	}

	desktop = &desktop_stat[crtc_index];
	plane = &desktop->plane;

	if (!plane->in_use)
	{
		/* Not support the vinterval */
		/* when not acquire the desktop */
		DLCSRV_PageFlip(crtc_index, fb_id);
		return DLC_STS_OK;
	}

	pthread_mutex_lock(&drm_mutex);

	flip = &plane->flip_queue[plane->flip_index.insert];

	flip->fb_id = fb_id;
	flip->status = DLCSRV_FLIP_PENDING;
	flip->interval = vinterval;

	plane->client_fd = client_fd;

	UpdateInsertIndex(plane);

	pthread_mutex_unlock(&drm_mutex);

	/* check overtake */
	while (plane->flip_index.insert == plane->flip_index.current)
	{
		usleep(10);
	}

	/* send response to client */
	DLCSRV_RespPageFlipComplete(plane->client_fd);

	return DLC_STS_OK;
}

