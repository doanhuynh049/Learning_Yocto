/*
 * Copyright(c) 2014-2016 Renesas Electronics Corporation
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY.
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation. No part of this
 * program may be reproduced or disclosed to others, in any
 * form, without the prior written permission of Renesas Electronics
 * Corporation.
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include "dlc_scope.h"

static const SCOPE_FUNCTION_TABLE sFunctionTable = {
	.pfnAcquire      = DLCScope_Acquire,
	.pfnRelease      = DLCScope_Release,
	.pfnStartContext = DLCScope_StartContext,
	.pfnStopContext  = DLCScope_StopContext,
	.pfnUpdateFrame  = DLCScope_UpdateFrame,
	.pfnTimingBegin  = DLCScope_TimingBegin,
	.pfnTimingEnd    = DLCScope_TimingEnd,
	.pfnTimingVSYNC  = DLCScope_TimingVSYNC,
};

/***********************************************************************************
 Function Name      : DLCScope_GetProcAddress
 Inputs             : None
 Outputs            : None
 Returns            : SCOPE_FUNCTION_TABLE*
 Description        : 
************************************************************************************/
const SCOPE_FUNCTION_TABLE *DLCScope_GetProcAddress(void)
{
	return &sFunctionTable;
}
