#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <stdarg.h>
#include <ctype.h>
#include <math.h>
#include <errno.h>
#include <assert.h>
#include <alsa/asoundlib.h>
#include <sys/poll.h>
#include <stdint.h>

#define MAX_LENGTH					    	(1000)
#define XA_REL_EQZ_FILTER_NUM				(9)				/**< number of filter */
#define XA_REL_EQZ_GRAPHIC_BAND_NUM			(5)				/**< number of graphic band */
#define MAX_PARAM_NUM                       (55)
enum eqz_parametric_type {
	XA_REL_EQZ_TYPE_THROUGH = 0,
	XA_REL_EQZ_TYPE_PEAK	= 1,
	XA_REL_EQZ_TYPE_BASS	= 2,
	XA_REL_EQZ_TYPE_TREBLE	= 3
};

enum eqz_graphic_type {
	XA_REL_EQZ_TYPE_PARAMETRIC	= 0,
	XA_REL_EQZ_TYPE_GRAPHIC		= 1
};

/* ...Equalizer's parameters */
typedef struct equalizer {
    int 	type;
    int 	filter_type[9];
    int 	frequency_center[9];
    double 	band_width[9];
    double 	gain[9];
    double 	gain_base[9];
    double 	graphic_gain[5];
} equalizer;

typedef struct eqz_parametric_param {
    unsigned int                                     Type[9];            /**< 9 Types of filter */
    unsigned int                                     FreqCenter[9];      /**< Center frequency of each filter */
    unsigned int                                     Gain[9];            /**< Gain of each filter */
    unsigned int                                     BandWidth[9];       /**< Bandwitdth of each filter */
    unsigned int                                     GainBase[9];        /**< Gain base of each filter */ 
} eqz_parametric_param;

typedef struct eqz_graphic_param {
    unsigned int                                     Gain_g[5];          /**< Gain of graphic equalizer */     
} eqz_graphic_param;

typedef struct eqz_parameter {
    unsigned int eqz_type;
    eqz_parametric_param peqz;
    eqz_graphic_param geqz;
} eqz_parameter;

static char card[64] = "default";

static void error(const char *fmt,...)
{
	va_list va;

	va_start(va, fmt);
	fprintf(stderr, "amixer: ");
	vfprintf(stderr, fmt, va);
	fprintf(stderr, "\n");
	va_end(va);
}
static void export_eqz_param_to_file_config(eqz_parameter *eqz_params, char *file_name);
static int get_eqz_param_from_control(eqz_parameter  *eqz_params, snd_ctl_elem_value_t *control, snd_ctl_elem_info_t *info)
{
	snd_ctl_elem_type_t type;
	unsigned int count;
	int i, filter_index;
        int param[MAX_PARAM_NUM]; 
    
	type = snd_ctl_elem_info_get_type(info);
	count = snd_ctl_elem_info_get_count(info);
	if (type == SND_CTL_ELEM_TYPE_INTEGER)
    {
        for (i = 0; i < count; i++) {
        param[i] = snd_ctl_elem_value_get_integer(control, i);
		}
    }
   
    eqz_params->eqz_type = param[0]; 

    /* get parameters' value from Equalizer plugin */
    if (eqz_params->eqz_type == XA_REL_EQZ_TYPE_PARAMETRIC)
    {
        for (i = 0, filter_index = 0; filter_index <= (XA_REL_EQZ_FILTER_NUM - 1); i++, filter_index++)
        {
            /* get frequency centre */
            eqz_params->peqz.FreqCenter[filter_index] = param[(i * 6) + 2];
                    
            /* get bandwidth */
            eqz_params->peqz.BandWidth[filter_index] = param[(i * 6) + 3];

            /* get filter type */
            eqz_params->peqz.Type[filter_index] = param[(i * 6) + 4];

            /* get gain base */
            eqz_params->peqz.GainBase[filter_index] = param[(i * 6) + 5];

            /* get gain */
            eqz_params->peqz.Gain[filter_index] = param[(i * 6) + 6];
        }
    }
    else
    {
        for (i = 0, filter_index = 0; filter_index <= (XA_REL_EQZ_GRAPHIC_BAND_NUM - 1); i++, filter_index++)
        {
            /* get graphic gain */
            eqz_params->geqz.Gain_g[filter_index] = param[(i * 2) + 2];
        }
    } 
	return 0;
}

static void export_eqz_param_to_file_config(eqz_parameter *eqz_params, char *file_name)
{
    FILE *export_file = NULL;
    int i;
    char filter_type_name;
    export_file = fopen(file_name, "w");
    if(eqz_params->eqz_type == XA_REL_EQZ_TYPE_PARAMETRIC)
    {

        fprintf (export_file, "Parametric\n");
        for(i = 0; i <= (XA_REL_EQZ_FILTER_NUM - 1); i++) {
            switch(eqz_params->peqz.Type[i]){
            
                case XA_REL_EQZ_TYPE_THROUGH:
                    {
                    printf("filter tyep Through\n");
                    filter_type_name = 'T';
                    break; 
                    }
                case XA_REL_EQZ_TYPE_TREBLE:
                    {
                    printf("filter tyep Treble\n");
                    filter_type_name = 'R';
                    break; 
                    }
                case XA_REL_EQZ_TYPE_PEAK:
                    {
                    printf("filter tyep Peak\n");
                    filter_type_name = 'P';
                    break; 
                    }
                default:
                    {
                    printf("filter tyep Bass\n");
                    filter_type_name = 'B';
                    break; 
                    }
            }

//            fprintf (export_file, "%c %d %d %d %d\n",filter_type_name, eqz_params->peqz.FreqCenter[i], 
//                    (1000 * eqz_params->peqz.BandWidth[i]) >> 27, 1000 * log10(eqz_params->peqz.GainBase[i] >> 28) * 20, 1000 * log10(eqz_params->peqz.Gain[i] >> 28) * 20);
       
            fprintf (export_file, "%c %d %d %d %d\n",filter_type_name, eqz_params->peqz.FreqCenter[i], 
                    eqz_params->peqz.BandWidth[i], eqz_params->peqz.GainBase[i], eqz_params->peqz.Gain[i]);
	    printf("filter[%d], TYPE = %d, FC =  %d, BW =  %d, GB =  %d, G =  %d\n", i, eqz_params->peqz.Type[i],
		eqz_params->peqz.FreqCenter[i], eqz_params->peqz.BandWidth[i], 
				eqz_params->peqz.GainBase[i], eqz_params->peqz.Gain[i]);
	 } 
    }
    else
    {
        fprintf (export_file, "Graphic\n");
        for(i = 0; i <= (XA_REL_EQZ_GRAPHIC_BAND_NUM - 1); i++){
            fprintf (export_file, "%d\n", eqz_params->geqz.Gain_g[i]);
        }
    }
    fclose(export_file);
}
static int convert_eqz_param_to_string(unsigned int eqz_type, void *eqz_params, char *param_)
{

    char param_string[MAX_LENGTH] = {0};
    int n = 0;
    int i = 0;
    char tmp[MAX_LENGTH] = {0};

    if (eqz_type == XA_REL_EQZ_TYPE_PARAMETRIC) 
    {
        eqz_parametric_param *eqz_p = (eqz_parametric_param *) eqz_params;  

        sprintf(tmp, "%d", eqz_type);
        strcpy(param_string, tmp); 

        for (n = 0; n <  XA_REL_EQZ_FILTER_NUM; n++)
        {
            sprintf(tmp, ",%d", n+1);
            strcat(param_string, tmp); 

            sprintf(tmp, ",%d", eqz_p->FreqCenter[n]);
            strcat(param_string, tmp);

            sprintf(tmp, ",%d", eqz_p->BandWidth[n]);
            strcat(param_string, tmp);

            sprintf(tmp, ",%d", eqz_p->Type[n]);
            strcat(param_string, tmp);

            sprintf(tmp, ",%d", eqz_p->GainBase[n]);
            strcat(param_string, tmp);

            sprintf(tmp, ",%d", eqz_p->Gain[n]);
            strcat(param_string, tmp);
        }
    }
    else 
    {
        eqz_graphic_param *eqz_g = (eqz_graphic_param *) eqz_params;  

        sprintf(tmp, "%d", eqz_type);
        strcpy(param_string,tmp); 

        for (n= 0; n < XA_REL_EQZ_GRAPHIC_BAND_NUM; n++)
        {
            sprintf(tmp, ",%d", n+1);
            strcat(param_string, tmp); 

            sprintf(tmp, ",%d", eqz_g->Gain_g[n]);
            strcat(param_string, tmp); 
        }

        for (i = n; i < ((XA_REL_EQZ_FILTER_NUM * 6) + 1); i++)
        {
            sprintf(tmp, ",%d", 0xffff);
            strcat(param_string, tmp); 
        }
    }

    /* assign the end string */
    strcat(param_string, "\0");

    memcpy(param_, &param_string, MAX_LENGTH);
    
    return 0;
}

static int get_EQZ_param_from_file(char *file_name, char *eqz_config_string)
{
    FILE *config_file = NULL;
    char filter_type_temp[16] = {0};
    equalizer eqz = {0};
    char buf[MAX_LENGTH] = {0};
    int i = 0;

    config_file = fopen(file_name, "r");
    if (config_file == NULL)
    {
        printf("Cannot open equalizer configuration file\n");
        return -1;
    }

    /** get each line in file and process */
    while (NULL != fgets(buf, MAX_LENGTH, config_file))
    {
        if (*buf == '#') continue;

        if (!strcmp(buf, "Parametric\n") || !strcmp(buf, "Parametric\r\n") ||
            !strcmp(buf, "Graphic\n") || !strcmp(buf, "Graphic\r\n"))
        {
            if(!strcmp(buf, "Parametric\n") || !strcmp(buf, "Parametric\r\n"))
            {
                eqz.type = XA_REL_EQZ_TYPE_PARAMETRIC;
            }
            else
            {
                eqz.type = XA_REL_EQZ_TYPE_GRAPHIC;
            }

            continue;
        }

        if ( (eqz.type == XA_REL_EQZ_TYPE_PARAMETRIC) )
        {
            /* check the filter count */
            if (i >= XA_REL_EQZ_FILTER_NUM) break;

            sscanf(buf, "%c %d %lf %lf %lf",
                &filter_type_temp[i],
                &eqz.frequency_center[i],
                &eqz.band_width[i],
                &eqz.gain[i],
                &eqz.gain_base[i]);

            switch (filter_type_temp[i])
            {
                case 'P':
                {
                    eqz.filter_type[i] = XA_REL_EQZ_TYPE_PEAK;
                    break;
                }
                case 'T':
                {
                    eqz.filter_type[i] = XA_REL_EQZ_TYPE_THROUGH;
                    break;
                }
                case 'B':
                {
                    eqz.filter_type[i] = XA_REL_EQZ_TYPE_BASS;
                    break;
                }
                case 'R':
                {
                    eqz.filter_type[i] = XA_REL_EQZ_TYPE_TREBLE;
                    break;
                }
                default:
                {
                    printf("Unrecognized equalizer type!\n");
                    return -1;
                }
            }
        }
        else if( (eqz.type == XA_REL_EQZ_TYPE_GRAPHIC) )
        {
            /* check the filter count */
            if (i >= XA_REL_EQZ_GRAPHIC_BAND_NUM) break;

            sscanf(buf, "%lf", &eqz.graphic_gain[i]);
        }

        i++;
    }

    fclose(config_file);

    /* convert EQZ param to format fixed point */
    if( eqz.type == XA_REL_EQZ_TYPE_PARAMETRIC )
    {
        eqz_parametric_param eqz_params = {0};

        for (i = 0; i < XA_REL_EQZ_FILTER_NUM; i++)
        {
            eqz_params.Type[i] = eqz.filter_type[i];
            eqz_params.FreqCenter[i] = eqz.frequency_center[i];
            eqz_params.BandWidth[i] = (unsigned int)(eqz.band_width[i] * (1 << 27));
            eqz_params.Gain[i] = (unsigned int)(pow(10, eqz.gain[i] / 20) * (1 << 28));
            eqz_params.GainBase[i] = (unsigned int)(pow(10, eqz.gain_base[i] / 20) * (1 << 28));

            printf("Filter[%d], Type[%d], FreqCenter[%d], BandWidth[%d], Gain[%d], GainBase[%d]\n", i, eqz_params.Type[i],
                    eqz_params.FreqCenter[i], eqz_params.BandWidth[i], eqz_params.Gain[i], eqz_params.GainBase[i]);
        }

        /* convert EQZ param to command string */
        convert_eqz_param_to_string(eqz.type, &eqz_params, eqz_config_string);
    }
    else
    {
        eqz_graphic_param eqz_params = {0};

        for (i = 0; i < XA_REL_EQZ_GRAPHIC_BAND_NUM; i++)
        {
            eqz_params.Gain_g[i] = (unsigned int)(pow(10, eqz.graphic_gain[i] / 20) * (1 << 28));
        }

        /* convert EQZ param to command string */
        convert_eqz_param_to_string(eqz.type, &eqz_params, eqz_config_string);
    } 

    printf("Command string: %s\n",eqz_config_string);

    return 0;
}

static int cset(int argc, char *argv[], int roflag)
{
	int err;
	static snd_ctl_t *handle = NULL;
	snd_ctl_elem_info_t *info;
	snd_ctl_elem_id_t *id;
	snd_ctl_elem_value_t *control;

	snd_ctl_elem_info_alloca(&info);
	snd_ctl_elem_id_alloca(&id);
	snd_ctl_elem_value_alloca(&control);
    char param[MAX_LENGTH];
    eqz_parameter eqz_params;

	if (argc < 1) {
		fprintf(stderr, "Specify a full control identifier: [[iface=<iface>,][name='name',][index=<index>,][device=<device>,][subdevice=<subdevice>]]|[numid=<numid>]\n");
		return -EINVAL;
	}

	if (snd_ctl_ascii_elem_id_parse(id, argv[0])) {
		fprintf(stderr, "Wrong control identifier: %s\n", argv[0]);
		return -EINVAL;
	}

	if (handle == NULL &&
	    (err = snd_ctl_open(&handle, card, 0)) < 0) {
		error("Control %s open error: %s\n", card, snd_strerror(err));
		return err;
	}

	snd_ctl_elem_info_set_id(info, id);
	if ((err = snd_ctl_elem_info(handle, info)) < 0) {
		error("Cannot find the given element from control %s\n", card);
	    snd_ctl_close(handle);
		handle = NULL;
		return err;
	}

	snd_ctl_elem_info_get_id(info, id);

	if (!roflag) {
		snd_ctl_elem_value_set_id(control, id);
		if ((err = snd_ctl_elem_read(handle, control)) < 0) {
			error("Cannot read the given element from control %s\n", card);
			snd_ctl_close(handle);
			handle = NULL;
			return err;
		}

        get_EQZ_param_from_file(argv[1], (char *)&param);

		err = snd_ctl_ascii_value_parse(handle, control, info, (char *)&param);
		if (err < 0) {
			error("Control %s parse error: %s\n", card, snd_strerror(err));
			snd_ctl_close(handle);
			handle = NULL;
			return err;
		}

		if ((err = snd_ctl_elem_write(handle, control)) < 0) {
			error("Control %s element write error: %s\n", card, snd_strerror(err));
			snd_ctl_close(handle);
			handle = NULL;
			return err;
		}
    }
    else {
    
		snd_ctl_elem_value_set_id(control, id);
   		if ((err = snd_ctl_elem_read(handle, control)) < 0) {
	    	error("Cannot read the given element from control %s\n", card);
		    snd_ctl_close(handle);
		    handle = NULL;
		    return err;
        }
        get_eqz_param_from_control((eqz_parameter*)&eqz_params, control, info);
        export_eqz_param_to_file_config((eqz_parameter*)&eqz_params, argv[1]);
    }

	snd_ctl_close(handle);
	handle = NULL;
	return 0;
}

int main(int argc, char *argv[])
{
    static const struct option long_option[] =
	{
		{"card", 1, NULL, 'c'},
		{"device", 1, NULL, 'D'},
		{"config", 1, NULL, 'f'},
	};

	while (1) {

        int c;

		if ((c = getopt_long(argc, argv, "c:D:f", long_option, NULL)) < 0)
			break;
		switch (c) {
		case 'c':
			{
				int i;
				i = snd_card_get_index(optarg);
				if (i >= 0 && i < 32)
					sprintf(card, "hw:%i", i);
				else {
					fprintf(stderr, "Invalid card number.\n");
				}
			}
			break;
		case 'D':
            {
                strncpy(card, optarg, sizeof(card)-1);
			    card[sizeof(card)-1] = '\0';
			    break;
            }
		default:
			fprintf(stderr, "Invalid switch or option needs an argument.\n");
		}
	}

    if (!strcmp(argv[optind], "cset")) {
		return cset(argc - optind - 1, argc - optind > 1 ? argv + optind + 1 : NULL, 0) ? 1 : 0;
	} else if (!strcmp(argv[optind], "cget")) {
		return cset(argc - optind - 1, argc - optind > 1 ? argv + optind + 1 : NULL, 1) ? 1 : 0;
	} else {
		fprintf(stderr, "amixer: Unknown command '%s'...\n", argv[optind]);
	}

    return 0;
}
