/*******************************************************************************
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 ******************************************************************************/

/*******************************************************************************
 * omx-decoder-mp3.c
 *
 * OMX IL component for Xtensa HiFi2 MP3 decoder
 ******************************************************************************/

#define MODULE_TAG                      XA_MP3DEC

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xf-ap.h"
#include "omx-codec-base.h"
#include "audio/xa_mp3_dec_api.h"

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(INIT, 1);

/*******************************************************************************
 * Local typedefs
 ******************************************************************************/

typedef struct XAOMXMp3Decoder
{
    /* ...generic codec structure */
    XAOMXCodecBase                  base;

    /* ...MP3-specific parameters (input port) */
    OMX_AUDIO_PARAM_MP3TYPE         sMP3;

    /* ...PCM-specific parameters (output port) */
    OMX_AUDIO_PARAM_PCMMODETYPE     sPCM;

}   XAOMXMp3Decoder;

/*******************************************************************************
 * Local constants definitions
 ******************************************************************************/

/* ...total amount of input buffers */
#define NUM_INPUT_BUFFERS               4

/* ...default input buffer length */
#define INPUT_BUFFER_LENGTH             4096

/* ...total amount of output buffers */
#define NUM_OUTPUT_BUFFERS              8

/* ...default output buffer length */
#define OUTPUT_BUFFER_LENGTH            4608

/* ...required data alignment */
#define BUFFER_ALIGNMENT                32

/*******************************************************************************
 * Low-level codec commands (called from component thread context)
 ******************************************************************************/

/* ...prepare codec setup parameters */
static int MP3DEC_CodecSetup(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg)
{
    XAOMXMp3Decoder    *pData = (XAOMXMp3Decoder *) pBase;

    TRACE(INIT, _b("Configured stream parameters: f=%u, c=%u"), pData->sMP3.nSampleRate, pData->sMP3.nChannels);
    
    /* ...prepare parameters to set */
    msg->item[0].id = XA_MP3DEC_CONFIG_PARAM_PCM_WDSZ;
    msg->item[0].value = 16;

    /* ...return number of parameters we want to set */
    return XF_SET_PARAM_CMD_LEN(1);
}

/* ...codec runtime initialization hook */
static int MP3DEC_CodecRuntimeInit(XAOMXCodecBase *pBase, xf_start_msg_t *msg)
{
    XAOMXMp3Decoder    *pData = (XAOMXMp3Decoder *)pBase;
    xf_get_param_msg_t *get = (xf_get_param_msg_t *)msg;

    TRACE(INIT, _b("MP3 stream prepared: f=%u, c=%u, w=%u, i=%u, o=%u"), msg->sample_rate, msg->channels, msg->pcm_width, msg->input_length, msg->output_length);
    
    /* ...update parameters requiring port reconfiguration */
    pData->sPCM.nSamplingRate = msg->sample_rate;
    pData->sPCM.nChannels = msg->channels;

    /* ...retrieve other relevant parameters from codec */
    get->c.id[0] = XA_MP3DEC_CONFIG_PARAM_BITRATE;

    /* ...return number of parameters we are querying */
    return XF_GET_PARAM_CMD_LEN(1);
}

/* ...process output stream parameters */
static int MP3DEC_CodecGetParam(XAOMXCodecBase *pBase, xf_get_param_msg_t *msg, u32 length)
{
    XAOMXMp3Decoder    *pData = (XAOMXMp3Decoder *) pBase;

    /* ...check the message length is correct */
    XF_CHK_ERR(length == XF_GET_PARAM_RSP_LEN(1), -EBADF);

    /* ...set new bitrate (no reconfiguration required) */
    pData->sMP3.nBitRate = msg->r.value[0];

    /* ...dump effective stream parameters */
    TRACE(INIT, _b("MP3 stream parameters"));
    TRACE(INIT, _b("Bitrate:            %u"), pData->sMP3.nBitRate);
    TRACE(INIT, _b("Sampling rate:      %u"), pData->sPCM.nSamplingRate);
    TRACE(INIT, _b("Number of channels: %u"), pData->sPCM.nChannels);
    
    return 0;
}

/* ...timestamp advance function */
static void MP3DEC_CodecTimeStamp(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    XAOMXMp3Decoder    *pData = (XAOMXMp3Decoder *) pBase;
    u32                 length = pBufHdr->nFilledLen;
    u32                 n = (length * 8) / (pData->sPCM.nChannels * pData->sPCM.nBitPerSample);

    /* ...add current timestamp to the output buffer */
    pBufHdr->nTimeStamp = pBase->nTimeStamp;

    /* ...advance timestamp for the next buffer (very basic and inaccurate way) */
    pBase->nTimeStamp += (n * 1000000) / pData->sPCM.nSamplingRate;
}

/*******************************************************************************
 * Codec-specific OMX IL interface
 ******************************************************************************/

/* ...get parameter */
static OMX_ERRORTYPE MP3DEC_GetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXMp3Decoder    *pData = (XAOMXMp3Decoder *) pBase;

    switch(nIndex) {
    case OMX_IndexParamAudioMp3:
    {
        /* ...gets OMX_AUDIO_MP3TYPE structure */
        OMX_AUDIO_PARAM_MP3TYPE *param = (OMX_AUDIO_PARAM_MP3TYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sMP3.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sMP3, sizeof(*param));

        TRACE(INIT, _b("MP3 parameters get: %lX, %lX, %lX, %lX, %d, %d"),
              pData->sMP3.nChannels,
              pData->sMP3.nBitRate,
              pData->sMP3.nSampleRate,
              pData->sMP3.nAudioBandWidth,
              pData->sMP3.eChannelMode,
              pData->sMP3.eFormat);

        return OMX_ErrorNone;
    }

    case OMX_IndexParamAudioPcm:
    {
        /* ...gets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sPCM, sizeof(*param));

        return OMX_ErrorNone;
    }

    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }
}

/* ...set parameter */
static OMX_ERRORTYPE MP3DEC_SetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXMp3Decoder    *pData = (XAOMXMp3Decoder *) pBase;

    switch(nIndex) {
    case OMX_IndexParamAudioMp3:
    {
        /* ...sets OMX_AUDIO_PARAM_MP3TYPE structure */
        OMX_AUDIO_PARAM_MP3TYPE    *param = (OMX_AUDIO_PARAM_MP3TYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sMP3.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(&pData->sMP3, param, sizeof(*param));

        TRACE(INIT, _b("MP3 parameters set"));
        TRACE(INIT, _b("Number of channels: %lu"), pData->sMP3.nChannels);
        TRACE(INIT, _b("Bitrate:            %lu"), pData->sMP3.nBitRate);
        TRACE(INIT, _b("Sampling rate:      %lu"), pData->sMP3.nSampleRate);
        TRACE(INIT, _b("Audio bandwidth:    %lu"), pData->sMP3.nAudioBandWidth);
        TRACE(INIT, _b("Channel mode:       %u"),  pData->sMP3.eChannelMode);
        TRACE(INIT, _b("Format:             %u"),  pData->sMP3.eFormat);

        return OMX_ErrorNone;
    }

    case OMX_IndexParamAudioPcm:
    {
        /* ...sets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(&pData->sPCM, param, sizeof(*param));

        TRACE(INIT, _b("PCM parameters set"));
        TRACE(INIT, _b("Number of channels: %lu"), pData->sPCM.nChannels);
        TRACE(INIT, _b("Sampling rate:      %lu"), pData->sPCM.nSamplingRate);
        TRACE(INIT, _b("Sample width:       %lu"), pData->sPCM.nBitPerSample);

        return OMX_ErrorNone;
    }

    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }
}

/*******************************************************************************
 * MP3DEC_ComponentDeInit
 *
 * Destroy MP3 decoder component
 ******************************************************************************/

static OMX_ERRORTYPE MP3DEC_ComponentDeInit(OMX_HANDLETYPE hComponent)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXMp3Decoder    *pData = (XAOMXMp3Decoder *) pComp->pComponentPrivate;

    /* ...destroy base component */
    XAOMX_CHK_API(XAOMX_ComponentDeInit(hComponent));

    /* ...destroy private data */
    free(pData);

    /* ...destroy component data itself (component ceases to exist) */
    free(pComp);

    TRACE(INIT, _b("MP3 decoder component destroyed"));

    return OMX_ErrorNone;
}

/*******************************************************************************
 * Functions definitions
 ******************************************************************************/

static OMX_ERRORTYPE MP3DEC_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXMp3Decoder    *pData = (XAOMXMp3Decoder *)pComp->pComponentPrivate;

    /* ...initialize base codec interface */
    XAOMX_CHK_API(XAOMX_ComponentInit(proxy, hComponent, pAppData, pCallbacks, "audio_decoder.mp3", "audio-decoder/mp3"));

    /* ...set codec-specific callbacks */
    pData->base.pComponentName = "OMX.xa.mp3.decoder";
    pData->base.SetParameter = MP3DEC_SetParameter;
    pData->base.GetParameter = MP3DEC_GetParameter;
    pData->base.CodecSetup = MP3DEC_CodecSetup;
    pData->base.CodecRuntimeInit = MP3DEC_CodecRuntimeInit;
    pData->base.CodecGetParam = MP3DEC_CodecGetParam;
    pData->base.CodecTimeStamp = MP3DEC_CodecTimeStamp;

    /* ...override component interface */
    //pComp->GetComponentVersion = MP3DEC_GetComponentVersion;
    pComp->ComponentDeInit = MP3DEC_ComponentDeInit;

    /* ...initialize the audio parameters for input port */
    pData->base.sPortDef[0].nBufferCountActual = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferCountMin = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferSize = INPUT_BUFFER_LENGTH;
    pData->base.sPortDef[0].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[0].format.audio.eEncoding = OMX_AUDIO_CodingMP3;
    pData->base.sPortDef[0].format.audio.cMIMEType = (OMX_STRING) "audio/mpeg";
    pData->base.sPortDef[0].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[0].format.audio.bFlagErrorConcealment = OMX_TRUE;

    /* ...initialize the compression format for input port */
    pData->base.sPortFormat[0].nIndex = OMX_IndexParamAudioMp3;
    pData->base.sPortFormat[0].eEncoding = OMX_AUDIO_CodingMP3;

    /* ...initialize the audio parameters for output port */
    pData->base.sPortDef[1].nBufferCountMin = NUM_OUTPUT_BUFFERS;
    pData->base.sPortDef[1].nBufferCountActual = NUM_OUTPUT_BUFFERS;
    pData->base.sPortDef[1].nBufferSize = OUTPUT_BUFFER_LENGTH;
    pData->base.sPortDef[1].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[1].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[1].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[1].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[1].format.audio.bFlagErrorConcealment = OMX_FALSE;

    /* ...initialize the compression format for output port */
    pData->base.sPortFormat[1].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[1].eEncoding = OMX_AUDIO_CodingPCM;

    /* ...MP3 format defaults */
    XAOMX_INIT_STRUCT(&pData->sMP3, OMX_AUDIO_PARAM_MP3TYPE);
    pData->sMP3.nPortIndex = 0;
    pData->sMP3.nChannels = 2;
    pData->sMP3.nSampleRate = 44100;
    pData->sMP3.eChannelMode = OMX_AUDIO_ChannelModeStereo;
    pData->sMP3.nAudioBandWidth = 0;
    pData->sMP3.eFormat = OMX_AUDIO_MP3StreamFormatMP1Layer3;

    /* ...PCM format defaults */
    XAOMX_INIT_STRUCT(&pData->sPCM, OMX_AUDIO_PARAM_PCMMODETYPE);
    pData->sPCM.nPortIndex = 1;
    pData->sPCM.nChannels = 2;
    pData->sPCM.nSamplingRate = 44100;
    pData->sPCM.nBitPerSample = 16;
    pData->sPCM.eNumData = OMX_NumericalDataSigned;
    pData->sPCM.eEndian = OMX_EndianLittle;
    pData->sPCM.bInterleaved = OMX_TRUE;
    pData->sPCM.ePCMMode = OMX_AUDIO_PCMModeLinear;
    pData->sPCM.eChannelMapping[0] = OMX_AUDIO_ChannelLF;
    pData->sPCM.eChannelMapping[1] = OMX_AUDIO_ChannelRF;

    TRACE(INIT, _b("Decoder instantiated"));

    return OMX_ErrorNone;
}

/*******************************************************************************
 * Entry points
 ******************************************************************************/

OMX_ERRORTYPE MP3DEC_ComponentCreate(xf_proxy_t *proxy, OMX_HANDLETYPE *hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE  *pComp;
    XAOMXMp3Decoder    *pData;
    OMX_ERRORTYPE       eError = OMX_ErrorInsufficientResources;

    /* ...create the base component */
    if ((pComp = calloc(1, sizeof(*pComp))) == NULL)
        goto error;

    /* ...set component version */
    XAOMX_INIT_STRUCT(pComp, OMX_COMPONENTTYPE);

    /* ...allocate private memory */
    if ((pData = calloc(1, sizeof(*pData))) == NULL)
        goto error1;

    /* ...set private data handle */
    pComp->pComponentPrivate = (OMX_PTR) pData;

    /* ...initialize component */
    if ((eError = MP3DEC_ComponentInit(proxy, (OMX_HANDLETYPE)pComp, pAppData, pCallbacks)) != OMX_ErrorNone)
        goto error2;

    TRACE(INIT, _b("MP3 decoder initialized"));

    /* ...return component handle */
    *hComponent = (OMX_HANDLETYPE)pComp;

    return OMX_ErrorNone;

error2:
    /* ...deallocate all component resources */
    MP3DEC_ComponentDeInit((OMX_HANDLETYPE)pComp);

    goto error;

error1:
    /* ...destroy component handle data */
    free(pComp);

error:
    TRACE(INIT, _b("MP3 decoder component creation failed: %X"), eError);

    return eError;
}
