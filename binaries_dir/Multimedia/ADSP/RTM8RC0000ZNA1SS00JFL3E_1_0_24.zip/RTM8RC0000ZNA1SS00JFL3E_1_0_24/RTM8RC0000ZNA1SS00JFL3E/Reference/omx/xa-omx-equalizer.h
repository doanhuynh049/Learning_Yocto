/** *****************************************************************************
  \file       xa-omx-equalizer.h
  \brief      Header file of ADSP Equalizer Interface
  \addtogroup ADSP Interface
 ********************************************************************************
  \date       Mar. 02, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information
   of Renesas Electronics Corporation. They must be used and modified solely for
   the purpose for which it was furnished by Renesas Electronics Corporation.
   All part of them must not be reproduced nor disclosed to others in any form,
   without the prior written permission of Renesas Electronics Corporation.
 ********************************************************************************/

#ifndef __XA_OMX_EQUALIZER_H__
#define __XA_OMX_EQUALIZER_H__

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xa-omx-base.h"

/*******************************************************************************
 * Extension index
 ******************************************************************************/

enum {
    XAOMX_IndexVendorBaseDspEqualizer  = (XAOMX_IndexVendorBaseDsp + 0x1000)  /* Equalizer domain */
};

enum {
    XAOMX_IndexParamAudioEqualizer = (XAOMX_IndexVendorBaseDspEqualizer + 0x0200)  /* OMX.RENESAS.INDEX.PARAM.AUDIO.DSP.EQUALIZER */
};

/*******************************************************************************
 * Equalizer structure declarations
 ******************************************************************************/

/** \struct XAOMX_AUDIO_PARAM_PARAMETRIC_EQUALIZER
    \brief  Parametric Equalizer Settings Structure
 */
typedef struct XAOMX_AUDIO_PARAM_PARAMETRIC_EQUALIZER {
    OMX_U32                                     nSize;              /**< Size of this structure, in Bytes */
    OMX_VERSIONTYPE                             nVersion;           /**< OMX specification version information */
    OMX_S32                                     Type[9];            /**< 9 Types of filter */
    OMX_S32                                     FreqCenter[9];      /**< Center frequency of each filter */
    OMX_S32                                     Gain[9];            /**< Gain of each filter */
    OMX_S32                                     BandWidth[9];       /**< Bandwitdth of each filter */
    OMX_S32                                     GainBase[9];        /**< Gain base of each filter */
} XAOMX_AUDIO_PARAM_PARAMETRIC_EQUALIZER;

/** \struct XAOMX_AUDIO_PARAM_GRAPHIC_EQUALIZER
    \brief  Graphic Equalizer Settings Structure
 */
typedef struct XAOMX_AUDIO_PARAM_GRAPHIC_EQUALIZER {
    OMX_U32                                     nSize;              /**< Size of this structure, in Bytes */
    OMX_VERSIONTYPE                             nVersion;           /**< OMX specification version information */
    OMX_S32                                     Gain_g[5];          /**< Gain of graphic equalizer */     
} XAOMX_AUDIO_PARAM_GRAPHIC_EQUALIZER;

/** \struct XAOMX_AUDIO_PARAM_EQUALIZER
    \brief  Equalizer characteristics
 */
typedef struct XAOMX_AUDIO_PARAM_EQUALIZER {
    OMX_U32                                     nSize;              /**< Size of this structure, in Bytes */
    OMX_VERSIONTYPE                             nVersion;           /**< OMX specification version information */
    OMX_S32                                     Eqz_type;           /**< Equalizer type */
    XAOMX_AUDIO_PARAM_PARAMETRIC_EQUALIZER      stEqCoef;           /**< Parameters of parametric equalizer */
    XAOMX_AUDIO_PARAM_GRAPHIC_EQUALIZER         stEqGCoef;          /**< Parameters of graphic equalizer */
} XAOMX_AUDIO_PARAM_EQUALIZER;

#endif /* __XA_OMX_EQUALIZER_H__ */
