/*
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

/*****************************************************************************/
/*                                                                           */
/*                            Audio Standards                                */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/

/*****************************************************************************/
/*                                                                           */
/*  File Name        : xa_ctenhaacplus_enc_config_params.h                   */
/*                                                                           */
/*  Description      : Configuration parameters list                         */
/*                                                                           */
/*  List of Functions: None                                                  */
/*                                                                           */
/*  Issues / Problems: None                                                  */
/*                                                                           */
/*  Revision History :                                                       */
/*                                                                           */
/*        DD MM YYYY       Author                Changes                     */
/*                                                                           */
/*****************************************************************************/

#ifndef __XA_AAC_ENC_CONFIG_PARAMS_H__
#define __XA_AAC_ENC_CONFIG_PARAMS_H__

/* aac_enc-specific configuration parameters */
enum xa_config_param_aac_enc {
  XA_AACENC_CONFIG_PARAM_SAMP_FREQ = 0,
  XA_AACENC_CONFIG_PARAM_NUM_CHANNELS = 1,
  XA_AACENC_CONFIG_PARAM_BITRATE = 2,
  XA_AACENC_CONFIG_PARAM_CHMODE = 3,
  XA_AACENC_CONFIG_PARAM_AAC_CLASSIC = 4,
  XA_AACENC_CONFIG_PARAM_USE_SPEECH_CONF = 5,
  XA_AACENC_CONFIG_PARAM_PCM_WDSZ = 6,
  XA_AACENC_CONFIG_PARAM_USE_ADIF = 7,
  XA_AACENC_CONFIG_PARAM_USE_CRC = 8,
  XA_AACENC_CONFIG_PARAM_USE_STEREO_PRE_PRO = 9,
  XA_AACENC_CONFIG_PARAM_QUALITY_LEVEL = 10,
  XA_AACENC_CONFIG_PARAM_USE_PNS = 11,
  XA_AACENC_CONFIG_PARAM_USE_TNS = 12,
  XA_AACENC_CONFIG_PARAM_DNSAMP_FLAG = 13
};

/* commands */
#include "xa_apicmd_standards.h"

/* aac_enc-specific commands */
/* (none) */

/* aac_enc-specific command types */
/* (none) */

/* error codes */
#include "xa_error_standards.h"

#define XA_CODEC_AAC_ENC   4

/* aac_enc-specific error codes */
/*****************************************************************************/
/* Class 0: API Errors                                                       */
/*****************************************************************************/
/* Nonfatal Errors */
enum xa_error_nonfatal_api_aac_enc {
    XA_AACENC_API_NONFATAL_CRC_DEACTIVATED   = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_api, XA_CODEC_AAC_ENC, 0),
    XA_AACENC_API_NONFATAL_AACPLUS_NOT_AVAIL = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_api, XA_CODEC_AAC_ENC, 1)
};

/* Fatal Errors */
enum xa_error_fatal_api_aac_enc {
    XA_AACENC_API_FATAL_DNSAMP_INIT_FAILED = XA_ERROR_CODE(xa_severity_fatal, xa_class_api, XA_CODEC_AAC_ENC, 4),
    XA_AACENC_API_FATAL_AAC_INIT_FAILED    = XA_ERROR_CODE(xa_severity_fatal, xa_class_api, XA_CODEC_AAC_ENC, 5)
};

/*****************************************************************************/
/* Class 1: Configuration Errors                                             */
/*****************************************************************************/
/* Nonfatal Errors */
enum xa_error_nonfatal_config_aac_enc {
  XA_AACENC_CONFIG_NONFATAL_PNS_NOT_ENABLED = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_AAC_ENC, 0)
};

/* Fatal Errors */
enum xa_error_fatal_config_aac_enc {
    XA_AACENC_CONFIG_FATAL_BITRATE            = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 0),
    XA_AACENC_CONFIG_FATAL_CHMODE             = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 1),
    XA_AACENC_CONFIG_FATAL_AAC_CLASSIC        = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 2),
    XA_AACENC_CONFIG_FATAL_USE_SPEECH_CONF    = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 3),
    XA_AACENC_CONFIG_FATAL_USE_ADIF           = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 4),
    XA_AACENC_CONFIG_FATAL_USE_CRC            = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 5),
    XA_AACENC_CONFIG_FATAL_USE_STEREO_PRE_PRO = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 6),
    XA_AACENC_CONFIG_FATAL_QUALITY_LEVEL      = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 7),
    XA_AACENC_CONFIG_FATAL_USE_PNS            = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 8),
    XA_AACENC_CONFIG_FATAL_USE_TNS            = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 9),
    XA_AACENC_CONFIG_FATAL_SAMP_FREQ          = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 10),
    XA_AACENC_CONFIG_FATAL_NUM_CHANNELS       = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 11),
    XA_AACENC_CONFIG_FATAL_PCM_WDSZ           = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_AAC_ENC, 12)
};

/*****************************************************************************/
/* Class 2: Execution Class Errors                                           */
/*****************************************************************************/
/* Nonfatal Errors */
enum xa_error_nonfatal_execute_aac_enc {
    XA_AACENC_EXECUTE_NONFATAL_NEED_MORE = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_AAC_ENC, 0)
};

/* Fatal Errors */
/* (none) */

#include "xa_type_def.h"

#if defined(__cplusplus)
extern "C" {
#endif /* __cplusplus */
xa_codec_func_t xa_aac_enc;
#if defined(__cplusplus)
}
#endif /* __cplusplus */
#endif /* __XA_AAC_ENC_CONFIG_PARAMS_H__ */
