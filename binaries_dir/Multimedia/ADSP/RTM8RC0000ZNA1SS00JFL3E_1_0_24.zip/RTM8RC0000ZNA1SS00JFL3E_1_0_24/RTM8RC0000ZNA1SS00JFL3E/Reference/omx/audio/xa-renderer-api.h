/*******************************************************************************
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 ******************************************************************************/


/*******************************************************************************
 * xa-renderer-api.h
 *
 * Renderer component API
 ******************************************************************************/

#ifndef __XA_RENDERER_API_H__
#define __XA_RENDERER_API_H__

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xa_type_def.h"
#include "xa_error_standards.h"
#include "xa_apicmd_standards.h"
#include "xa_memory_standards.h"

/*******************************************************************************
 * Constants definitions
 ******************************************************************************/

/* ...renderer-specific configuration parameters */
enum xa_config_param_renderer {
    XA_RDR_CONFIG_PARAM_STATE            = 0,
    XA_RDR_CONFIG_PARAM_PCM_WIDTH        = 1,
    XA_RDR_CONFIG_PARAM_CHANNELS         = 2,
    XA_RDR_CONFIG_PARAM_SAMPLE_RATE      = 3,
    XA_RDR_CONFIG_PARAM_FRAME_SIZE       = 4,
    XA_RDR_CONFIG_PARAM_OUTPUT1          = 5,
    XA_RDR_CONFIG_PARAM_DMACHANNEL1      = 6,
    XA_RDR_CONFIG_PARAM_OUTPUT2          = 7,
    XA_RDR_CONFIG_PARAM_DMACHANNEL2      = 8,
    XA_RDR_CONFIG_PARAM_OUT_SAMPLE_RATE  = 9,
    XA_RDR_CONFIG_PARAM_VOLUME_RATE      = 10,
    XA_RDR_CONFIG_PARAM_OUT_CHANNELS     = 11,
    XA_RDR_CONFIG_PARAM_MIX_CONTROL      = 12,
    XA_RDR_CONFIG_PARAM_NUM              = 13
};

/* ...XA_RENDERER_CONFIG_PARAM_CB: compound parameters data structure */
typedef struct xa_renderer_cb_s {
    /* ...input buffer completion callback */
    void      (*cb)(struct xa_renderer_cb_s *, WORD32 idx);

}   xa_renderer_cb_t;
    

/* ...renderer states  */
enum xa_randerer_state {
    XA_RENDERER_STATE_IDLE  = 0,
    XA_RENDERER_STATE_RUN   = 1,
    XA_RENDERER_STATE_PAUSE = 2
};
    
/* ...component identifier (informative) */
#define XA_CODEC_RENDERER               2

/*******************************************************************************
 * Class 0: API Errors
 ******************************************************************************/

#define XA_RENDERER_API_NONFATAL(e)     \
    XA_ERROR_CODE(xa_severity_nonfatal, xa_class_api, XA_CODEC_RENDERER, (e))

#define XA_RENDERER_API_FATAL(e)        \
    XA_ERROR_CODE(xa_severity_fatal, xa_class_api, XA_CODEC_RENDERER, (e))

enum xa_error_nonfatal_api_renderer {
    XA_RENDERER_API_NONFATAL_MAX = XA_RENDERER_API_NONFATAL(0)
};

enum xa_error_fatal_api_renderer {
    XA_RENDERER_API_FATAL_MAX = XA_RENDERER_API_FATAL(0)
};

/*******************************************************************************
 * Class 1: Configuration Errors
 ******************************************************************************/

#define XA_RENDERER_CONFIG_NONFATAL(e)  \
    XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_RENDERER, (e))

#define XA_RENDERER_CONFIG_FATAL(e)     \
    XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_RENDERER, (e))

enum xa_error_nonfatal_config_renderer {
	XA_RENDERER_CONFIG_NONFATAL_ERR_PCM_WIDTH		= XA_RENDERER_CONFIG_NONFATAL(0),
	XA_RENDERER_CONFIG_NONFATAL_ERR_CHANNELS		= XA_RENDERER_CONFIG_NONFATAL(1),
	XA_RENDERER_CONFIG_NONFATAL_ERR_SAMPLE_RATE		= XA_RENDERER_CONFIG_NONFATAL(2),
	XA_RENDERER_CONFIG_NONFATAL_ERR_FRAME_SIZE		= XA_RENDERER_CONFIG_NONFATAL(3),
	XA_RENDERER_CONFIG_NONFATAL_ERR_SOURCE			= XA_RENDERER_CONFIG_NONFATAL(4),
	XA_RENDERER_CONFIG_NONFATAL_ERR_DMACHANNEL		= XA_RENDERER_CONFIG_NONFATAL(5),
	XA_RENDERER_CONFIG_NONFATAL_MAX					= XA_RENDERER_CONFIG_NONFATAL(6)
};

enum xa_error_fatal_config_renderer {
    XA_RENDERER_CONFIG_FATAL_HW                     = XA_RENDERER_CONFIG_FATAL(0),
    XA_RENDERER_CONFIG_FATAL_STATE                  = XA_RENDERER_CONFIG_FATAL(1),
    XA_RENDERER_CONFIG_FATAL_RANGE                  = XA_RENDERER_CONFIG_FATAL(2),
    XA_RENDERER_CONFIG_FATAL_ERR_MONO_24BIT         = XA_RENDERER_CONFIG_FATAL(3),
    XA_RENDERER_CONFIG_FATAL_MAX					= XA_RENDERER_CONFIG_FATAL(4)
};

/*******************************************************************************
 * Class 2: Execution Class Errors
 ******************************************************************************/

#define XA_RENDERER_EXEC_NONFATAL(e)    \
    XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_RENDERER, (e))

#define XA_RENDERER_EXEC_FATAL(e)       \
    XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_RENDERER, (e))

enum xa_error_nonfatal_execute_renderer {
    XA_RENDERER_EXEC_NONFATAL_STATE     = XA_RENDERER_EXEC_NONFATAL(0),
    XA_RENDERER_EXEC_NONFATAL_INPUT     = XA_RENDERER_EXEC_NONFATAL(1),
    XA_RENDERER_EXEC_NONFATAL_MAX       = XA_RENDERER_EXEC_NONFATAL(2)
};

enum xa_error_fatal_execute_renderer {
    XA_RENDERER_EXEC_FATAL_HW           = XA_RENDERER_EXEC_FATAL(0),
    XA_RENDERER_EXEC_FATAL_STATE        = XA_RENDERER_EXEC_FATAL(1),
    XA_RENDERER_EXEC_FATAL_INPUT        = XA_RENDERER_EXEC_FATAL(2),
    XA_RENDERER_EXEC_FATAL_MAX          = XA_RENDERER_EXEC_FATAL(3)
};

/*******************************************************************************
 * API entry point
 ******************************************************************************/
XA_ERRORCODE xa_rel_renderer(xa_codec_handle_t p_xa_module_obj, WORD32 i_cmd, WORD32 i_idx, pVOID pv_value);

/*******************************************************************************
 * API function definition (tbd)
 ******************************************************************************/

#if defined(USE_DLL) && defined(_WIN32)
#define DLL_SHARED __declspec(dllimport)
#elif defined (_WINDLL)
#define DLL_SHARED __declspec(dllexport)
#else
#define DLL_SHARED
#endif

#if defined(__cplusplus)
extern "C" {
#endif  /* __cplusplus */
DLL_SHARED xa_codec_func_t xa_rel_rdr;
#if defined(__cplusplus)
}
#endif  /* __cplusplus */

#endif /* __XA_RENDERER_API_H__ */
