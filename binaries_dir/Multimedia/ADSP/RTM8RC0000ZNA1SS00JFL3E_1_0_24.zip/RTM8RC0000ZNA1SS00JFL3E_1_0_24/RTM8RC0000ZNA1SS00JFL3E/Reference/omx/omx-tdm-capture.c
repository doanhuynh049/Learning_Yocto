/** *****************************************************************************
  \file       omx-tdm-capture.c
  \brief      ADSP Capture Interface
  \addtogroup ADSP Interface
 ********************************************************************************
  \date       Mar. 02, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information
   of Renesas Electronics Corporation. They must be used and modified solely for
   the purpose for which it was furnished by Renesas Electronics Corporation.
   All part of them must not be reproduced nor disclosed to others in any form,
   without the prior written permission of Renesas Electronics Corporation.
 ********************************************************************************/

/*******************************************************************************
 * omx-tdm-capture.c
 *
 * OMX IL component for ADSP TDM capture
 ******************************************************************************/

#define MODULE_TAG                      TDM_CAPTURE_INTERFACE

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xf-ap.h"
#include "omx-tdm-codec-base.h"
#include "audio/xa-tdm-capture-api.h"
#include "xa-omx-tdm-renderer.h"

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(INIT, 1);

/*******************************************************************************
 * Local typedefs
 ******************************************************************************/

/** \struct XAOMX_TDM_CAP
    \brief  TDM Capture Structure
 */
typedef struct _XAOMX_TDM_CAP
{
    /** ...generic codec structure */
    XAOMXTDMCodecBase                   base;
   
    /** ...PCM-specific parameters (output port) */
    OMX_AUDIO_PARAM_PCMMODETYPE         sPCM;

    /** ...TDM Capture parameters */
    XAOMX_AUDIO_PARAM_TDM_CAPTURE      sTDM_CAPTURE;

} XAOMX_TDM_CAP;

/*******************************************************************************
 * Local constants definitions
 ******************************************************************************/

/** \def NUM_OUTPUT_BUFFERS
    ...total amount of output buffers
 */
#define NUM_OUTPUT_BUFFERS              (4)

/** \def OUTPUT_BUFFER_LENGTH
    ...default output buffer length
 */
#define OUTPUT_BUFFER_LENGTH            (4096)

/** \def BUFFER_ALIGNMENT
    ...required data alignment
 */
#define BUFFER_ALIGNMENT                (32)

/*******************************************************************************
 * Function declarations
 ******************************************************************************/
static s32 TDM_CAPTURE_Setup(XAOMXTDMCodecBase *pBase, xf_set_param_msg_t *msg);
static s32 TDM_CAPTURE_RuntimeInit(XAOMXTDMCodecBase *pBase, xf_start_msg_t *msg);
static s32 TDM_CAPTURE_GetParam(XAOMXTDMCodecBase *pBase, xf_get_param_msg_t *msg, u32 length);
static void TDM_CAPTURE_TimeStamp(XAOMXTDMCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr);
static OMX_ERRORTYPE TDM_CAPTURE_GetParameter(XAOMXTDMCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE TDM_CAPTURE_SetParameter(XAOMXTDMCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE TDM_CAPTURE_ComponentDeInit(OMX_HANDLETYPE hComponent);
static OMX_ERRORTYPE TDM_CAPTURE_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks);

/*******************************************************************************
 * Low-level codec commands (called from component thread context)
 ******************************************************************************/

/** **************************************************************************
    \brief        TDM Capture prepare codec setup parameters

    \param[in]      *pBase      Pointer to pComponentPrivate of TDM Capture component
    \param[in]      *msg        Message send to TDM Capture plugin
    \retval         length      Number of parameters want to set for TDM Capture plugin
 *****************************************************************************/
static s32 TDM_CAPTURE_Setup(XAOMXTDMCodecBase *pBase, xf_set_param_msg_t *msg)
{
    XAOMX_TDM_CAP    *pData = (XAOMX_TDM_CAP *) pBase;    /* PRQA S 0310 *//* We confirmed pointer casting is correct. Oct 14, 2016 */
    s32                 i = 0;

    TRACE(INIT, _b("TDM CAPTURE stream set parameters"));
    TRACE(INIT, _b("PCM width:          %lu"), pData->sPCM.nBitPerSample);
    TRACE(INIT, _b("Channel mode:       %lu"), pData->sTDM_CAPTURE.nPCM_channel_mode);
    TRACE(INIT, _b("In sampling rate:   %lu"), pData->sTDM_CAPTURE.nPCM_in_sample_rate);
    TRACE(INIT, _b("Out sampling rate:  %lu"), pData->sTDM_CAPTURE.nPCM_out_sample_rate);
    TRACE(INIT, _b("PCM frame size:     %lu"), pData->sTDM_CAPTURE.nPCM_frame_size);
    TRACE(INIT, _b("Input1:             %lu"), pData->sTDM_CAPTURE.nPCM_input1);
    TRACE(INIT, _b("DMA channel1:       %lu"), pData->sTDM_CAPTURE.nPCM_dma_channel1);
    TRACE(INIT, _b("Input2:             %lu"), pData->sTDM_CAPTURE.nPCM_input2);
    TRACE(INIT, _b("DMA channel2:       %lu"), pData->sTDM_CAPTURE.nPCM_dma_channel2);
    TRACE(INIT, _b("Volume rate:        %lu"), pData->sTDM_CAPTURE.nPCM_volume_rate);
    
    /* ...prepare parameters to set */
    msg->item[i].id = XA_TDM_CAP_CONFIG_PARAM_PCM_WIDTH;
    msg->item[i++].value = pData->sPCM.nBitPerSample;

    msg->item[i].id = XA_TDM_CAP_CONFIG_PARAM_CHANNEL_MODE;
    msg->item[i++].value = pData->sTDM_CAPTURE.nPCM_channel_mode;
    
    msg->item[i].id = XA_TDM_CAP_CONFIG_PARAM_IN_SAMPLE_RATE;
    msg->item[i++].value = pData->sTDM_CAPTURE.nPCM_in_sample_rate;
	
    msg->item[i].id = XA_TDM_CAP_CONFIG_PARAM_OUT_SAMPLE_RATE;
    msg->item[i++].value = pData->sTDM_CAPTURE.nPCM_out_sample_rate;

    msg->item[i].id = XA_TDM_CAP_CONFIG_PARAM_FRAME_SIZE;
    msg->item[i++].value = pData->sTDM_CAPTURE.nPCM_frame_size;
	
    msg->item[i].id = XA_TDM_CAP_CONFIG_PARAM_INPUT1;
    msg->item[i++].value = pData->sTDM_CAPTURE.nPCM_input1;

    msg->item[i].id = XA_TDM_CAP_CONFIG_PARAM_DMACHANNEL1;
    msg->item[i++].value = pData->sTDM_CAPTURE.nPCM_dma_channel1;
	
    msg->item[i].id = XA_TDM_CAP_CONFIG_PARAM_INPUT2;
    msg->item[i++].value = pData->sTDM_CAPTURE.nPCM_input2;

    msg->item[i].id = XA_TDM_CAP_CONFIG_PARAM_DMACHANNEL2;
    msg->item[i++].value = pData->sTDM_CAPTURE.nPCM_dma_channel2;

    msg->item[i].id = XA_TDM_CAP_CONFIG_PARAM_VOLUME_RATE;
    msg->item[i++].value = pData->sTDM_CAPTURE.nPCM_volume_rate;

    /* ...return number of parameters we want to set */
    return XF_SET_PARAM_CMD_LEN(i);
}

/** **************************************************************************
    \brief        TDM Capture runtime initialization hook

    \param[in]      *pBase      Pointer to pComponentPrivate of TDM Capture component
    \param[in]      *msg        Message send to TDM Capture plugin
    \retval         length      Number of parameters want to get from TDm Capture plugin
 *****************************************************************************/
static s32 TDM_CAPTURE_RuntimeInit(XAOMXTDMCodecBase *pBase, xf_start_msg_t *msg)  /* PRQA S 3206 *//* Confirm function definition is correct. Oct 14, 2016 */
{
    xf_get_param_msg_t *get = (xf_get_param_msg_t *)msg;    /* PRQA S 0310 *//* Confirmed pointer casting is correct. Oct 14, 2016 */

    /* ...update parameters requiring port reconfiguration */
    get->c.id[0] = XA_TDM_CAP_CONFIG_PARAM_DMACHANNEL1;

    /* ...return number of parameters we are querying */
    return XF_GET_PARAM_CMD_LEN(1);
}

/** **************************************************************************
    \brief        TDM Capture process output stream parameters

    \param[in]      *pBase      Pointer to pComponentPrivate of TDM Capture component
    \param[in]      *msg        Message receive from TDM Capture plugin
    \param[in]      length      Length of message 
    \retval         0           Success
 *****************************************************************************/
static s32 TDM_CAPTURE_GetParam(XAOMXTDMCodecBase *pBase, xf_get_param_msg_t *msg, u32 length) /* PRQA S 3673, 3206 *//* Confirm function definition and usage is correct. Oct 14, 2016 */
{
    XAOMX_TDM_CAP    *pData = (XAOMX_TDM_CAP *) pBase;    /* PRQA S 0310 *//* Confirmed pointer casting is correct. Oct 14, 2016 */

    /* ...check the message length is correct */
    XF_CHK_ERR(length == XF_GET_PARAM_RSP_LEN(1), -EBADF);

    /* ...set ADMA-pp channel usage */
    pData->sTDM_CAPTURE.nPCM_dma_channel1 = msg->r.value[0];

    TRACE(INIT, _b("TDM CAPTURE parameters"));
    TRACE(INIT, _b("DMA channel:     %u"), pData->sTDM_CAPTURE.nPCM_dma_channel1);

    return 0;
}

/** **************************************************************************
    \brief        TDM Capture timestamp advance function

    \param[in]      *pBase      Pointer to pComponentPrivate of TDM Capture component
    \param[in]      *pBufHdr    Output buffer  
 *****************************************************************************/
static void TDM_CAPTURE_TimeStamp(XAOMXTDMCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    XAOMX_TDM_CAP    *pData = (XAOMX_TDM_CAP *) pBase;        /* PRQA S 0310 *//* Confirmed pointer casting is correct. Oct 14, 2016 */
    u32                 length = pBufHdr->nFilledLen;
    u32                 n = (length * 8) / (pData->sPCM.nChannels * pData->sPCM.nBitPerSample);

    /* ...add current timestamp to the output buffer */
    pBufHdr->nTimeStamp = pBase->nTimeStamp;

    /* ...advance timestamp for the next buffer (very basic and inaccurate way) */
    pBase->nTimeStamp += (n * 1000000) / pData->sPCM.nSamplingRate;
}

/*******************************************************************************
 * Codec-specific OMX IL interface
 ******************************************************************************/

/** **************************************************************************
    \brief        TDM Capture get parameter

    \param[in]      *pBase                       Pointer to pComponentPrivate of TDM Capture component
    \param[in]      nIndex                       Index of parameter structure
    \param[in]      pParam                       Pointer to parameter structure want to get
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE TDM_CAPTURE_GetParameter(XAOMXTDMCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMX_TDM_CAP    *pData = (XAOMX_TDM_CAP *) pBase;        /* PRQA S 0310 *//* Confirmed pointer casting is correct. Oct 14, 2016 */

    switch(nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...gets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sPCM, sizeof(*param));        /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        break;
    }
    case XAOMX_IndexParamAudioTDMCapture:      /* PRQA S 1460 *//* Confirmed extension enum value is correct. Oct 14, 2016 */
    {
        /* ...gets XAOMX_AUDIO_PARAM_TDM_CAPTURE structure */
        XAOMX_AUDIO_PARAM_TDM_CAPTURE    *param = (XAOMX_AUDIO_PARAM_TDM_CAPTURE *) pParam;

        memcpy(param, &pData->sTDM_CAPTURE, sizeof(*param));    /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        break;
    }
    case OMX_IndexParamCompBufferSupplier:
    {
        /* ...gets OMX_PARAM_BUFFERSUPPLIERTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_BUFFERSUPPLIERTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort == 1, OMX_ErrorBadPortIndex);

        memcpy(pParam, &pData->base.sSupplier[nPort], sizeof(OMX_PARAM_BUFFERSUPPLIERTYPE));    /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        break;
    }
    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        TDM Capture Set parameter

    \param[in]      *pBase                       Pointer to pComponentPrivate of TDM Capture component
    \param[in]      nIndex                       Index of parameter structure
    \param[in]      pParam                       Pointer to parameter structure want to set
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE TDM_CAPTURE_SetParameter(XAOMXTDMCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMX_TDM_CAP    *pData = (XAOMX_TDM_CAP *) pBase;    /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */

    switch(nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...sets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(&pData->sPCM, param, sizeof(*param));    /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        TRACE(INIT, _b("PCM parameters set"));
        TRACE(INIT, _b("Number of channels: %lu"), pData->sPCM.nChannels);
        TRACE(INIT, _b("Sampling rate:      %lu"), pData->sPCM.nSamplingRate);
        TRACE(INIT, _b("Sample width:       %lu"), pData->sPCM.nBitPerSample);

        break;
    }
    case XAOMX_IndexParamAudioTDMCapture:      /* PRQA S 1460 *//* Confirm extension enum value is correct. Oct 14, 2016 */
    {
        /* ...sets XAOMX_AUDIO_PARAM_TDM_CAPTURE structure */
        XAOMX_AUDIO_PARAM_TDM_CAPTURE    *param = (XAOMX_AUDIO_PARAM_TDM_CAPTURE *) pParam;

        memcpy(&pData->sTDM_CAPTURE, param, sizeof(*param));    /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        break;
    }
    case OMX_IndexParamCompBufferSupplier:
    {
        /* ...gets OMX_PARAM_BUFFERSUPPLIERTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_BUFFERSUPPLIERTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort == 1, OMX_ErrorBadPortIndex);

        memcpy(&pData->base.sSupplier[nPort], pParam, sizeof(OMX_PARAM_BUFFERSUPPLIERTYPE));    /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        TRACE(INIT, _b("Buffer supplier [%d]: %d"), nPort, pData->base.sSupplier[nPort].eBufferSupplier);

        break;
    }
    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        TDM_CAPTURE_ComponentDeInit

    \param[in]      hComponent                   Pointer to TDM Capture component handle
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
static OMX_ERRORTYPE TDM_CAPTURE_ComponentDeInit(OMX_HANDLETYPE hComponent)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMX_TDM_CAP    *pData = (XAOMX_TDM_CAP *) pComp->pComponentPrivate;

    /* ...destroy base component */
    XAOMX_CHK_API(XAOMXTDM_ComponentDeInit(hComponent));

    /* ...destroy private data */
    free(pData);        /* PRQA S 5118 *//* Confirm free usage is follow original framework. Oct 14, 2016 */

    /* ...destroy component data itself (component ceases to exist) */
    free(pComp);        /* PRQA S 5118 *//* Confirm free usage is follow original framework. Oct 14, 2016 */

    TRACE(INIT, _b("TDM CAPTURE component destroyed"));

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        TDM CAPTURE_ComponentInit

    \param[in]      *proxy                       OpenMAX interface proxy
    \param[in]      hComponent                   Pointer to TDM Capture component handle
    \param[in]      pAppData                     Pointer to pAppData of TDM Capture component
    \param[in]      *pCallbacks                  Pointer to Callbacks of TDM Capture component
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
static OMX_ERRORTYPE TDM_CAPTURE_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE   *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMX_TDM_CAP       *pData = (XAOMX_TDM_CAP *)pComp->pComponentPrivate;
    s32                 i;

    /* ...initialize base codec interface */
    XAOMX_CHK_API(XAOMXTDM_ComponentInit(proxy, hComponent, pAppData, pCallbacks, "audio_tdm_capture.pcm", "tdm-capture"));

    /* ...set codec-specific callbacks */
    pData->base.pComponentName = "OMX.RENESAS.AUDIO.DSP.TDMCAPTURE";
    pData->base.SetParameter = &TDM_CAPTURE_SetParameter;       /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.GetParameter = &TDM_CAPTURE_GetParameter;       /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecSetup = &TDM_CAPTURE_Setup;                /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecRuntimeInit = &TDM_CAPTURE_RuntimeInit;    /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecGetParam = &TDM_CAPTURE_GetParam;          /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecTimeStamp = &TDM_CAPTURE_TimeStamp;        /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */

    /* ...override component interface */
    pComp->ComponentDeInit = &TDM_CAPTURE_ComponentDeInit;

    /* ...initialize the audio parameters for fake input port */
	pData->base.sPortDef[0].nBufferCountMin = 1;
	pData->base.sPortDef[0].nBufferCountActual = 1;
	pData->base.sPortDef[0].nBufferSize = 1;
	pData->base.sPortDef[0].nBufferAlignment = BUFFER_ALIGNMENT;
	pData->base.sPortDef[0].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
	pData->base.sPortDef[0].format.audio.cMIMEType = (OMX_STRING) "raw";
	pData->base.sPortDef[0].format.audio.pNativeRender = NULL;
	pData->base.sPortDef[0].format.audio.bFlagErrorConcealment = OMX_FALSE;

    pData->base.sPortDef[0].nPortIndex = 0;
    pData->base.sPortDef[0].eDir = OMX_DirInput;

	/* ...initialize the compression format for fake input port */
	pData->base.sPortFormat[0].nIndex = OMX_IndexParamAudioPcm;
	pData->base.sPortFormat[0].eEncoding = OMX_AUDIO_CodingPCM;

	for (i = 0; i < XAOMX_PORT_MAX; i++)
	{
        /* ...initialize the audio parameters for output port */
        pData->base.sPortDef[1 + i].nBufferCountMin = NUM_OUTPUT_BUFFERS;
        pData->base.sPortDef[1 + i].nBufferCountActual = NUM_OUTPUT_BUFFERS;
        pData->base.sPortDef[1 + i].nBufferSize = OUTPUT_BUFFER_LENGTH;
        pData->base.sPortDef[1 + i].nBufferAlignment = BUFFER_ALIGNMENT;
        pData->base.sPortDef[1 + i].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
        pData->base.sPortDef[1 + i].format.audio.cMIMEType = (OMX_STRING) "raw";
        pData->base.sPortDef[1 + i].format.audio.pNativeRender = NULL;
        pData->base.sPortDef[1 + i].format.audio.bFlagErrorConcealment = OMX_FALSE;

        pData->base.sPortDef[1 + i].nPortIndex = 1 + i;
        pData->base.sPortDef[1 + i].eDir = OMX_DirOutput;

        /* ...initialize the compression format for output port */
        pData->base.sPortFormat[1 + i].nIndex = OMX_IndexParamAudioPcm;
        pData->base.sPortFormat[1 + i].eEncoding = OMX_AUDIO_CodingPCM;
	}

    /* ...PCM format defaults */
    XAOMX_INIT_STRUCT(&pData->sPCM, OMX_AUDIO_PARAM_PCMMODETYPE);
    pData->sPCM.nPortIndex = XAOMX_PORT_MAX;
    pData->sPCM.nChannels = 2;
    pData->sPCM.nSamplingRate = 44100;
    pData->sPCM.nBitPerSample = 16;
    pData->sPCM.eNumData = OMX_NumericalDataSigned;
    pData->sPCM.eEndian = OMX_EndianLittle;
    pData->sPCM.bInterleaved = OMX_TRUE;
    pData->sPCM.ePCMMode = OMX_AUDIO_PCMModeLinear;
    pData->sPCM.eChannelMapping[0] = OMX_AUDIO_ChannelLF;
    pData->sPCM.eChannelMapping[1] = OMX_AUDIO_ChannelRF;

    /* ...TDM capture format defaults */
    XAOMX_INIT_STRUCT(&pData->sTDM_CAPTURE, XAOMX_AUDIO_PARAM_TDM_CAPTURE);
    pData->sTDM_CAPTURE.nPCM_frame_size = 1024;
    pData->sTDM_CAPTURE.nPCM_channel_mode = 0;
    pData->sTDM_CAPTURE.nPCM_in_sample_rate = 0;
    pData->sTDM_CAPTURE.nPCM_out_sample_rate = 44100;
    pData->sTDM_CAPTURE.nPCM_input1 = SSI10;
    pData->sTDM_CAPTURE.nPCM_dma_channel1 = ADMACPP_CH00;
    pData->sTDM_CAPTURE.nPCM_input2 = NONCONFIG;
    pData->sTDM_CAPTURE.nPCM_dma_channel2 = ADMACPP_CH01;
    pData->sTDM_CAPTURE.nPCM_volume_rate = 0xFFFFFFFF;

    TRACE(INIT, _b("TDM CAPTURE instantiated"));

    return OMX_ErrorNone;
}

/*******************************************************************************
 * Entry points
 ******************************************************************************/

/** **************************************************************************
    \brief     TDM CAPTURE_ComponentCreate

    \param[in]      *proxy                       OpenMAX interface proxy
    \param[in]      *hComponent                  Pointer to TDM Capture component handle
    \param[in]      pAppData                     Pointer to pAppData of TDM Capture component
    \param[in]      *pCallbacks                  Pointer to Callbacks of TDM Capture component
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
OMX_ERRORTYPE TDM_CAPTURE_ComponentCreate(xf_proxy_t *proxy, OMX_HANDLETYPE *hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)    /* PRQA S 1503, 3408 *//* Confirm prototype and usage is correct. Oct 14, 2016 */
{
    OMX_COMPONENTTYPE   *pComp;
    XAOMX_TDM_CAP       *pData;
    OMX_ERRORTYPE       eError = OMX_ErrorInsufficientResources;

    /* ...create the base component */
    pComp = calloc(1, sizeof(*pComp));      /* PRQA S 5118 *//* Confirm memory allocation is correct. Oct 14, 2016 */
    if (pComp == NULL) {
        goto error;         /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    /* ...set component version */
    XAOMX_INIT_STRUCT(pComp, OMX_COMPONENTTYPE);

    /* ...allocate private memory */
    pData = calloc(1, sizeof(*pData));      /* PRQA S 5118 *//* Confirm memory allocation is correct. Oct 14, 2016 */
    if (pData == NULL) {
        goto error1;        /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    /* ...set private data handle */
    pComp->pComponentPrivate = (OMX_PTR) pData;

    /* ...initialize component */
    eError = TDM_CAPTURE_ComponentInit(proxy, (OMX_HANDLETYPE)pComp, pAppData, pCallbacks);
    if (eError != OMX_ErrorNone) {
        goto error1;        /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    TRACE(INIT, _b("TDM CAPTURE initialized"));

    /* ...return component handle */
    *hComponent = (OMX_HANDLETYPE)pComp;

    return OMX_ErrorNone;

error1:
    /* ...destroy component handle data */
    free(pComp);    /* PRQA S 5118 *//* Confirm memory free is correct. Oct 14, 2016 */

error:
    TRACE(INIT, _b("TDM CAPTURE component creation failed: %X"), eError);

    return eError;
}
