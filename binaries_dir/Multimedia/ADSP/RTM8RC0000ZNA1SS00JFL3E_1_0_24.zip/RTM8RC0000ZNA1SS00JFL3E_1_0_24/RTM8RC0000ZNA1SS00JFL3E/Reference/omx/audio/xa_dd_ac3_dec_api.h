/*
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

#ifndef __XA_DD_AC3_DEC_API_H__
#define __XA_DD_AC3_DEC_API_H__

/*****************************************************************************/
/* Dolby Digital (AC-3) Decoder specific API definitions                     */
/*****************************************************************************/


#define XA_DD_AC3DEC_BLOCKS_PER_FRAME 6
#define XA_DD_AC3DEC_SYNC_WORD 0x0B77
#define XA_DD_AC3DEC_NCHANS                  6                       /* max # channels */
#define XA_DD_AC3DEC_NFCHANS                 5                       /* max # full bw channels */
#define XA_DD_AC3DEC_NREMATBNDS              4                       /* max # rematrixing bands */
#define XA_DD_AC3DEC_NDELTS                  8                       /* max # delta bit alloc segments */
#define XA_DD_AC3DEC_NCPLBNDS                18                      /* max # coupling bands */


/* ac3_dec-specific configuration parameters */
enum xa_config_param_ac3_dec {
  XA_DD_AC3DEC_CONFIG_PARAM_KARAC               = 0,
  XA_DD_AC3DEC_CONFIG_PARAM_DYNRNG_MODE         = 1,
  XA_DD_AC3DEC_CONFIG_PARAM_LFE_OUT             = 2,
  XA_DD_AC3DEC_CONFIG_PARAM_OCFG                = 3,
  XA_DD_AC3DEC_CONFIG_PARAM_NUM_OCH             = 4,
  XA_DD_AC3DEC_CONFIG_PARAM_PCM_SCALE           = 5,
  XA_DD_AC3DEC_CONFIG_PARAM_STEREO_MODE         = 6,
  XA_DD_AC3DEC_CONFIG_PARAM_MONO_REP            = 7,
  XA_DD_AC3DEC_CONFIG_PARAM_DYN_CUT_HI          = 8,
  XA_DD_AC3DEC_CONFIG_PARAM_DYN_BOOST_LO        = 9,
  XA_DD_AC3DEC_CONFIG_PARAM_CHAN_MAP            = 10,
  XA_DD_AC3DEC_CONFIG_PARAM_EXT_DNMIXTAB        = 11,
  XA_DD_AC3DEC_CONFIG_PARAM_BLOCK_REPEAT        = 12,
  XA_DD_AC3DEC_CONFIG_PARAM_SAMP_FREQ           = 13,
  XA_DD_AC3DEC_CONFIG_PARAM_DATA_RATE           = 14,
  XA_DD_AC3DEC_CONFIG_PARAM_ACMOD               = 15,
  XA_DD_AC3DEC_CONFIG_PARAM_LFE_PRESENT         = 16,
  XA_DD_AC3DEC_CONFIG_PARAM_AC3BSWAP            = 17,
  XA_DD_AC3DEC_CONFIG_PARAM_ERRCONCEAL          = 18,
  XA_DD_AC3DEC_CONFIG_PARAM_KARAC_PARAMPTR      = 19,
  XA_DD_AC3DEC_CONFIG_PARAM_DSUREXMOD           = 20,
  XA_DD_AC3DEC_CONFIG_PARAM_BSI                 = 21     /* Returns pointer to the BSI structure in the bitstream */ 
};

/* commands */
#include "xa_apicmd_standards.h"

/* ac3_dec-specific commands */
/* (none) */

/* ac3_dec-specific command types */
/* (none) */

/* error codes */
#include "xa_error_standards.h"

#define XA_CODEC_DD_AC3_DEC     8

/* ac3_dec-specific error codes */
/*****************************************************************************/
/* Class 0: API Errors                                                       */
/*****************************************************************************/
/* Non Fatal Errors */
/* Fatal Errors */
/* (none) */

/*****************************************************************************/
/* Class 1: Configuration Errors                                             */
/*****************************************************************************/
/* Nonfatal Errors */
enum xa_error_nonfatal_config_ac3_dec {
  XA_DD_AC3DEC_CONFIG_NONFATAL_KARAC_3                  = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 0),
  XA_DD_AC3DEC_CONFIG_NONFATAL_DYNRNG_MODE_2            = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 1),
  XA_DD_AC3DEC_CONFIG_NONFATAL_LFE_OUT_1                = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 2),
  XA_DD_AC3DEC_CONFIG_NONFATAL_OCFG_7                   = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 3),
  XA_DD_AC3DEC_CONFIG_NONFATAL_NUM_OCH_6                = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 4),
  XA_DD_AC3DEC_CONFIG_NONFATAL_PCM_SCALE_ONE            = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 5),
  XA_DD_AC3DEC_CONFIG_NONFATAL_STEREO_MODE_0            = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 6),
  XA_DD_AC3DEC_CONFIG_NONFATAL_MONO_REP_0               = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 7),
  XA_DD_AC3DEC_CONFIG_NONFATAL_DYN_CUT_HI_ONE           = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 8),
  XA_DD_AC3DEC_CONFIG_NONFATAL_DYN_BOOST_LO_ONE         = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 9),
  XA_DD_AC3DEC_CONFIG_NONFATAL_CHMAP_0L_1C_2R_3l_4r_5s  = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 10),
  XA_DD_AC3DEC_CONFIG_NONFATAL_DNMIXTAB_INTERNAL        = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 11),
  XA_DD_AC3DEC_CONFIG_NONFATAL_BLOCK_REPEAT_MINUS_1     = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 12),
  XA_DD_AC3DEC_CONFIG_NONFATAL_INVALID_GEN_STRM_POS      = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DD_AC3_DEC, 13)
};
/* Fatal Errors */
/*****************************************************************************/
/* Class 2: Execution Class Errors                                           */
/*****************************************************************************/
/* Nonfatal Errors */
enum xa_error_nonfatal_execute_ac3_dec {
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_SYNC                         = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 0),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_CRC_FAILED                   = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 1),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_INSUFFICIENT_HEADER_DATA     = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 2),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_INSUFFICIENT_FRAME_DATA      = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 3),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_REUSE_COUPLE_STRAT_BLOCK0    = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 4),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_COUPLED_DUAL_MONO_MODE       = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 5),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_REUSE_REMATRIX_BLOCK0        = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 6),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_REUSE_COUPLED_EXP_STRAT_BLOCK0= XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC,7),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_REUSE_EXP_STRAT_BLOCK0       = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 8),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_REUSE_LFE_EXP_STRAT_BLOCK0   = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 9),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_INVALID_CHBWCOD              = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 10),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_REUSE_BITALLOCINFO_BLOCK0    = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 11),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_REUSE_SNR_OFFSETS_BLOCK0     = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 12),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_REUSE_CPL_LEAK_TERMS_BLOCK0  = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 13),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_MUTE                         = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 14),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_SKIPPED_ADDITIONAL_BSI       = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 15),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_BLK5_EXCEEDS_3BY8_FRAME      = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 16),
 XA_DD_AC3DEC_EXECUTE_NONFATAL_ERR_BLK01_EXCEEDS_5BY8_FRAME     = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 17),
};

/* Fatal Errors */
enum xa_error_fatal_execute_ac3_dec {
 XA_DD_AC3DEC_EXECUTE_FATAL_ERR_REVISION                        = XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 0),
 XA_DD_AC3DEC_EXECUTE_FATAL_ERR_SAMPRATE                        = XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 1),
 XA_DD_AC3DEC_EXECUTE_FATAL_ERR_DATARATE                        = XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 2),
 XA_DD_AC3DEC_EXECUTE_FATAL_ERR_DELTA_BIT_ALLOC_OVERFLOW        = XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 3),
 XA_DD_AC3DEC_EXECUTE_FATAL_ERR_INVALID_PHSCOR_TAB_INDEX        = XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_DD_AC3_DEC, 4)
};

#include "xa_type_def.h"

typedef struct{
        WORD16          xbsi1e;                         /* extra BSI1 info exists               */
        WORD16          compre;                         /* channel 3 comp word exists           */
        WORD16          compr;                          /* channel 3 comp word                  */
        WORD16          compr2e;                        /* channel 3 comp word #2 exists        */
        WORD16          compr2;                         /* channel 3 comp word #2               */
        WORD16          rematflg[XA_DD_AC3DEC_NREMATBNDS];              /* rematrixing flags    */
        WORD16          phsoutmod;                      /* phscor encoder correction factor     */
        WORD16          chdeltnseg[XA_DD_AC3DEC_NFCHANS]; /* channel delta # of segments        */
        WORD16          cpldeltnseg;                    /* coupling delta # of segments         */
        WORD16          sdcycod;                        /* slow decay code                      */
        WORD16          fdcycod;                        /* fast decay code                      */
        WORD16          sgaincod;                       /* slow gain code                       */
        WORD16          dbpbcod;                        /* db-per-bit code                      */
        WORD16          floorcod;                       /* floor code                           */
        WORD16          cplfgaincod;                    /* coupling fast gain code              */
        WORD16          fgaincod[XA_DD_AC3DEC_NFCHANS]; /* channel fast gain code               */
        WORD16          lfefgaincod;                    /* lfe fast gain code                   */
        WORD16          cplleake;                       /* coupling leak terms exist flag       */
        WORD16          cplfleak;                       /* coupling fast leak term              */
        WORD16          cplsleak;                       /* coupling slow leak term              */
        WORD16          rematstr;                       /* rematrixing strategy                 */
        WORD16          csnroffst;                      /* coarse snr offset                    */
        WORD16          cplfsnroffst;                   /* coupling fine snr offset             */
        WORD16          fsnroffst[XA_DD_AC3DEC_NFCHANS]; /* channel fine snr offset             */
        WORD16          lfefsnroffst;                   /* lfe fine snr offset                  */
        WORD16          cpldeltoffst[XA_DD_AC3DEC_NDELTS]; /* coupling delta offset             */
        WORD16          cpldeltlen[XA_DD_AC3DEC_NDELTS];   /* coupling delta length             */
        WORD16          cpldeltba[XA_DD_AC3DEC_NDELTS];    /* coupling delta bit alloc          */
        WORD16          chdeltoffst[XA_DD_AC3DEC_NFCHANS][XA_DD_AC3DEC_NDELTS]; /* channel delta offset     */
        WORD16          chdeltlen[XA_DD_AC3DEC_NFCHANS][XA_DD_AC3DEC_NDELTS];   /* channel delta length     */
        WORD16          chdeltba[XA_DD_AC3DEC_NFCHANS][XA_DD_AC3DEC_NDELTS];    /* channel delta bit alloc  */
        WORD16          cplcoexp[XA_DD_AC3DEC_NFCHANS][XA_DD_AC3DEC_NCPLBNDS];  /* coupling coordinate exps */
        WORD16          gainrng[XA_DD_AC3DEC_NFCHANS];          /* gain ranging word            */
        WORD16          appgainrng[XA_DD_AC3DEC_NCHANS]; /* applied gain ranging word           */
        WORD16          cplexpstr;                      /* coupling exponent strategy           */
        WORD16          chexpstr[XA_DD_AC3DEC_NFCHANS];         /* channel exponent strategy    */
        WORD16          lfeexpstr;                      /* lfe exponent strategy                */
        WORD16          deltbaie;                       /* delta bit alloc info exists flag     */
        WORD16          cpldeltbae;                     /* coupling delta bit alloc exists      */
        WORD16          deltbae[XA_DD_AC3DEC_NFCHANS];  /* channel delta bit alloc exists       */
        WORD16          baie;                           /* bit alloc information exists         */
        WORD16          snroffste;                      /* snr offsets exist flag               */
        WORD16          chbwcod[XA_DD_AC3DEC_NFCHANS];  /* channel bandwidth code               */
        WORD16          phsflg;                         /* coupling coordinate phase flag       */
        WORD16          skiple;                         /* skip length exists flag              */
        WORD16          skipl;                          /* skip length                          */
        WORD16          phscore;                        /* phase corelation info exist flag     */
        WORD16          phscorstr;                      /* phscor strategy: per band or not     */
        WORD16          phscor[XA_DD_AC3DEC_NCPLBNDS];  /* phscor coefficients                  */
        WORD16          cplcoe[XA_DD_AC3DEC_NFCHANS];   /* coupling coordinates exist flag      */
        WORD16          mstrcplco;                      /* master coupling coordinate           */
        /*      Sync info */
        WORD16          syncword;                       /* synchronization word                 */
        WORD16          crc1;                           /* first CRC word (start of frame)      */
        WORD16          fscod;                          /* sampling frequency code              */
        WORD16          frmsizecod;                     /* frame size code                      */
        /*      Bit stream info */
        WORD16          bsid;                           /* bitstream identification             */
        WORD16          bsmod;                          /* bitstream mode                       */
        WORD16          acmod;                          /* audio coding mode                    */
        WORD16          dsurmod;                        /* Dolby surround mode                  */
        WORD16          dialnorm;                       /* dialog normalization word            */
        WORD16          langcode;                       /* language code exists                 */
        WORD16          langcod;                        /* language code                        */
        WORD16          audprodie;                      /* audio production info exists         */
        WORD16          mixlevel;                       /* mixing level                         */
        WORD16          roomtyp;                        /* room type                            */
        WORD16          dialnorm2;                      /* dialog normalization word #2         */
        WORD16          langcod2e;                      /* language code #2 exists              */
        WORD16          langcod2;                       /* language code #2                     */
        WORD16          audprodi2e;                     /* audio production info #2 exists      */
        WORD16          mixlevel2;                      /* mixing level #2                      */
        WORD16          roomtyp2;                       /* room type #2                         */
        WORD16          copyrightb;                     /* copyright bit                        */
        WORD16          origbs;                         /* original bitstream flag              */
        WORD16          timecod1e;                      /* time code first half exists          */
        WORD16          timecod1;                       /* time code first half                 */
        WORD16          timecod2e;                      /* time code second half exists         */
        WORD16          timecod2;                       /* time code second half                */
        WORD16          addbsie;                        /* additional BSI exists                */
        WORD16          addbsil;                        /* additional BSI length                */
        /*  Extended Bitstream Parameters */
        WORD16          dmixmod;                        /* preferred downmix mode               */
        WORD16          xbsi2e;                         /* extra BSI2 info exists               */
        WORD16          dsurexmod;                      /* Surround EX mode flag                */
        WORD16          dheadphonmod;                   /* Dolby Headphone encoded flag         */
        WORD16          adconvtyp;                      /* Advanced converter flag              */
        WORD16          xbsi2;                          /* Reserved BSI parameters              */
        WORD16          encinfo;                        /* Encoder Information bit              */
        /*      Audio block */
        WORD16          blksw[XA_DD_AC3DEC_NFCHANS];    /* block switch flags                   */
        WORD16          dithflag[XA_DD_AC3DEC_NFCHANS]; /* dither flags                         */
        /*      Coupling strategy */
        WORD16          cplstre;                        /* coupling strategy exists             */
        WORD16          cplinu;                         /* coupling in use flag                 */
        WORD16          chincpl[XA_DD_AC3DEC_NFCHANS];  /* channel in coupling flags            */
        WORD16          phsflginu;                      /* phase flags in use flag              */
        WORD16          cplbegf;                        /* coupling begin frequency code        */
        WORD16          cplendf;                        /* coupling end frequency code          */
        WORD16          cplbndstrc[XA_DD_AC3DEC_NCPLBNDS]; /* coupling band structure           */

        WORD16          cmixlev;
        WORD16          surmixlev;
        WORD16          ltrtcmixlev;                    /* ltrt downmix center mix level        */
        WORD16          ltrtsurmixlev;                  /* ltrt downmix surround mix level      */
        WORD16          lorocmixlev;                    /* loro downmix center mix level        */
        WORD16          lorosurmixlev;                  /* loro downmix surround mix level      */

        WORD16          lfeon;
        WORD16          dynrnge;                        /* dynamic range word exists            */
        WORD16          dynrng;                         /* dynamic range word                   */
        WORD16          dynrng2e;                       /* dynamic range word #2 exists         */
        WORD16          dynrng2;                        /* dynamic range word #2                */
} xa_dd_ac3_dec_bitstream_var_t;



#if defined(__cplusplus)
extern "C" {
#endif  /* __cplusplus */

xa_codec_func_t xa_dd_ac3_dec;

#if defined(__cplusplus)
}
#endif  /* __cplusplus */

#endif /* __XA_AC3_DEC_API_H__ */
