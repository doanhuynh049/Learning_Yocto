/*
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

#ifndef __XA_DAP_API_H__
#define __XA_DAP_API_H__

#include "xa_apicmd_standards.h"
#include "xa_error_standards.h"
#include "xa_type_def.h"

#define XA_CODEC_DAP  (0)

enum xa_config_param_dap {
    XA_DAP_CONFIG_PARAM_BVER    =   0   ,
    XA_DAP_CONFIG_PARAM_VER     =   1   ,
    XA_DAP_CONFIG_PARAM_BNDL    =   4   ,
    XA_DAP_CONFIG_PARAM_E_ARE_HIGH      =   102 ,
    XA_DAP_CONFIG_PARAM_E_ARE_COMG      =   103 ,
    XA_DAP_CONFIG_PARAM_E_ARE_PWR   =   104 ,
    XA_DAP_CONFIG_PARAM_ENDP    =   134 ,
    XA_DAP_CONFIG_PARAM_OCF     =   135 ,
    XA_DAP_CONFIG_PARAM_PREG    =   136 ,
    XA_DAP_CONFIG_PARAM_PSTG    =   137 ,
    XA_DAP_CONFIG_PARAM_VOL     =   138 ,
    XA_DAP_CONFIG_PARAM_VDHE    =   139 ,
    XA_DAP_CONFIG_PARAM_VSPE    =   140 ,
    XA_DAP_CONFIG_PARAM_DHSB    =   141 ,
    XA_DAP_CONFIG_PARAM_DHRG    =   142 ,
    XA_DAP_CONFIG_PARAM_DSSB    =   143 ,
    XA_DAP_CONFIG_PARAM_DSSA    =   144 ,
    XA_DAP_CONFIG_PARAM_DSSF    =   145 ,
    XA_DAP_CONFIG_PARAM_SCPE    =   146 ,
    XA_DAP_CONFIG_PARAM_DVLA    =   147 ,
    XA_DAP_CONFIG_PARAM_DVLI    =   148 ,
    XA_DAP_CONFIG_PARAM_DVLO    =   149 ,
    XA_DAP_CONFIG_PARAM_DVLE    =   150 ,
    XA_DAP_CONFIG_PARAM_DVMC    =   151 ,
    XA_DAP_CONFIG_PARAM_DVME    =   152 ,
    XA_DAP_CONFIG_PARAM_IENB    =   153 ,
    XA_DAP_CONFIG_PARAM_IEBF    =   154 ,
    XA_DAP_CONFIG_PARAM_IEBT    =   155 ,
    XA_DAP_CONFIG_PARAM_IEON    =   156 ,
    XA_DAP_CONFIG_PARAM_IEA     =   157 ,
    XA_DAP_CONFIG_PARAM_DEON    =   158 ,
    XA_DAP_CONFIG_PARAM_DEA     =   159 ,
    XA_DAP_CONFIG_PARAM_DED     =   160 ,
    XA_DAP_CONFIG_PARAM_NGON    =   161 ,
    XA_DAP_CONFIG_PARAM_GEON    =   162 ,
    XA_DAP_CONFIG_PARAM_GENB    =   163 ,
    XA_DAP_CONFIG_PARAM_GEBF    =   164 ,
    XA_DAP_CONFIG_PARAM_GEBG    =   165 ,
    XA_DAP_CONFIG_PARAM_AOCC    =   166 ,
    XA_DAP_CONFIG_PARAM_AONB    =   167 ,
    XA_DAP_CONFIG_PARAM_AOBF    =   168 ,
    XA_DAP_CONFIG_PARAM_AOBG    =   169 ,
    XA_DAP_CONFIG_PARAM_AOON    =   170 ,
    XA_DAP_CONFIG_PARAM_ARNB    =   171 ,
    XA_DAP_CONFIG_PARAM_ARBF    =   172 ,
    XA_DAP_CONFIG_PARAM_ARBI    =   173 ,
    XA_DAP_CONFIG_PARAM_ARBL    =   174 ,
    XA_DAP_CONFIG_PARAM_ARBH    =   175 ,
    XA_DAP_CONFIG_PARAM_AROD    =   176 ,
    XA_DAP_CONFIG_PARAM_ARTP    =   177 ,
    XA_DAP_CONFIG_PARAM_PLB     =   178 ,
    XA_DAP_CONFIG_PARAM_PLMD    =   179 ,
    XA_DAP_CONFIG_PARAM_TEST    =   180 ,
    XA_DAP_CONFIG_PARAM_VEN     =   181 ,
    XA_DAP_CONFIG_PARAM_VNNB    =   182 ,
    XA_DAP_CONFIG_PARAM_VNBF    =   183 ,
    XA_DAP_CONFIG_PARAM_VNBG    =   184 ,
    XA_DAP_CONFIG_PARAM_VNBE    =   185 ,
    XA_DAP_CONFIG_PARAM_VCNB    =   186 ,
    XA_DAP_CONFIG_PARAM_VCBF    =   187 ,
    XA_DAP_CONFIG_PARAM_VCBG    =   188 ,
    XA_DAP_CONFIG_PARAM_VCBE    =   189 ,
    XA_DAP_CONFIG_PARAM_VMON    =   190 ,
    XA_DAP_CONFIG_PARAM_VMB     =   191 ,

    XA_DAP_CONFIG_PARAM_AUDIO_CONFIG    =   195 ,

    XA_DAP_CONFIG_PARAM_UNKNOWN = 0xFFFF,
};


/* DAP specific error codes */
/****************************************************************************************************
  Class 0: API Errors
 ***************************************************************************************************/
/* Non Fatal Errors */
/* (none) */
/* Fatal Errors */
/* (none) */

/****************************************************************************************************
  Class 1: Configuration Errors
 ***************************************************************************************************/
/* Nonfatal Errors */
enum xa_error_nonfatal_config_dap {
    XA_DAP_CONFIG_NONFATAL_ERR_INVALID_CONFIG = XA_ERROR_CODE(xa_severity_nonfatal, \
                                                        xa_class_config, XA_CODEC_DAP, 0),
    XA_DAP_CONFIG_NONFATAL_ERR_PARAM_NOT_SET  = XA_ERROR_CODE(xa_severity_nonfatal, \
                                                        xa_class_config, XA_CODEC_DAP, 1),
    XA_DAP_CONFIG_NONFATAL_ERR_READONLY_CONFIG = XA_ERROR_CODE(xa_severity_nonfatal, \
                                                        xa_class_config, XA_CODEC_DAP, 2),
};
/* Fatal Errors */
enum xa_error_fatal_config_dap {
    XA_DAP_CONFIG_FATAL_ERR_INVALID_CONFIG    = XA_ERROR_CODE(xa_severity_fatal,    \
                                                        xa_class_config, XA_CODEC_DAP, 0),
};

/****************************************************************************************************
  Class 2: Execution Class Errors
 ***************************************************************************************************/
/* Nonfatal Errors */
enum xa_error_nonfatal_execute_dap {
    XA_DAP_EXECUTE_NONFATAL_ERR_INSUFFICIENT_DATA    = XA_ERROR_CODE(xa_severity_nonfatal, \
                                                            xa_class_execute, XA_CODEC_DAP, 0),
    XA_DAP_EXECUTE_NONFATAL_ERR_OUTPUT_CONFIG_CHANGE = XA_ERROR_CODE(xa_severity_nonfatal, \
                                                            xa_class_execute, XA_CODEC_DAP, 1),
};

/* Fatal Errors */
enum xa_error_fatal_execute_dap {
    XA_DAP_EXECUTE_FATAL_ERR_INIT_FAILED             = XA_ERROR_CODE(xa_severity_fatal,  \
                                                            xa_class_execute, XA_CODEC_DAP, 0),
    XA_DAP_EXECUTE_FATAL_ERR_EXECUTE                 = XA_ERROR_CODE(xa_severity_fatal,  \
                                                            xa_class_execute, XA_CODEC_DAP, 1),
    XA_DAP_EXECUTE_FATAL_ERR_INVALID_CODEC_STATE     = XA_ERROR_CODE(xa_severity_fatal,  \
                                                            xa_class_execute, XA_CODEC_DAP, 2),
};


/****************************************************************************************************
  DAP Specific types and declarations
 ***************************************************************************************************/
#define XA_DAP_MAX_CHANNELS (8)

/****************************************************************************************************
    Channel identifiers enumerator: 
        Used to specify which channels are present and their order
 ***************************************************************************************************/
typedef enum _xa_dap_channel_id_t {
    
    XA_DAP_CHAN_EMPTY    =  0, /* Specifies that no channel is present                              */
    XA_DAP_CHAN_DONTCARE =  1, /* Use this specifier when the channel identifier is not required    */
    XA_DAP_CHAN_L        =  2, /* Left. 30 degrees left of center                                   */
    XA_DAP_CHAN_R        =  3, /* Right. 30 degrees left of center                                  */
    XA_DAP_CHAN_C        =  4, /* Center. Also used for mono. Directly in front of the listener     */
    XA_DAP_CHAN_LFE      =  5, /* Low Frequency Effects. 120Hz omnidirectional                      */
    XA_DAP_CHAN_Ms       =  6, /* Mono Surround                                                     */
    XA_DAP_CHAN_Ls       =  7, /* Left Surround. 110 degrees left of center                         */
    XA_DAP_CHAN_Rs       =  8, /* Right Surround. 110 degrees right of center                       */
    XA_DAP_CHAN_Lb       =  9, /* Left Back. Behind listener on left                                */
    XA_DAP_CHAN_Rb       = 10, /* Right Back. Behind listener on right                              */
    XA_DAP_CHAN_Cs       = 11, /* Center Surround (rear). 180 degrees off center (behind listener)  */
    XA_DAP_CHAN_Ts       = 12, /* Top Surround. 90 degrees elevated above the listener              */
    XA_DAP_CHAN_Cvh      = 13, /* Center Vertical Height. 45 degrees elevated in the center         */
    XA_DAP_CHAN_LR_SUM   = 14, /* Sum from 2 channel input                                          */
    XA_DAP_CHAN_LR_DIFF  = 15, /* Diff from 2 channel input                                         */

} xa_dap_channel_id_t;

/****************************************************************************************************
    Audio config structure
        Structure to set/get the audio configuration of DAP 
 ***************************************************************************************************/
typedef struct _xa_dap_audio_config_t {

    WORD32              sample_rate;                    /* Sampling rate for input and output       */
    UWORD32             block_size;                     /* block size to process; must be 256 always*/
    UWORD32             nchannels;                      /* number of input/output channels, upto 8  */
    UWORD32             latency;                        /* over all latency of DAP; readonly; 
                                                           applicableonly for output                */
    xa_dap_channel_id_t chan_id[XA_DAP_MAX_CHANNELS];   /*specific channel id for each channel      */

} xa_dap_audio_config_t;

/****************************************************************************************************
    DAP feature controller enumerator 
        Used to enable, disable DAP features.
 ***************************************************************************************************/
typedef enum _xa_dap_feature_control_t {
    XA_DAP_FEATURE_OFF = 0,         /* Disable */ 
    XA_DAP_FEATURE_ON = 1,          /* Enable */
    XA_DAP_FEATURE_AUTO = 2         /* Auto decide based on other configuration setting */
} xa_dap_feature_control_t;

/****************************************************************************************************
    DAP Peak limiting and Protection Mode enumerator 
        Used to control state of peak limiter and audio regulator.
 ***************************************************************************************************/
typedef enum _xa_dap_plmd_mode_t {
    XA_DAP_PLMD_DISABLE_ALL = 0,            /* Peak limiter and Audio regulator both inactive */ 
    XA_DAP_PLMD_PEAK_ONLY = 1,              /* Peak limiter active, Audio regulator inactive */
    XA_DAP_PLMD_REGULATED_PEAK = 2,         /* Peak limiter active, Audio regulator active with no
                                               device specific distortion reduction*/
    XA_DAP_PLMD_REGULATED_DISTORTION = 3,   /* Peak limiter active, Audio regulator active with 
                                               device specific distortion minimization */
    XA_DAP_PLMD_AUTO = 4,                   /* Auto mode. If endpoint is internal speaker the 
                                               mode is XA_DAP_PLMD_REGULATED_DISTORTION, */
                                            /* otherwise it is XA_DAP_PLMD_REGULATED_PEAK  */
} xa_dap_plmd_mode_t;

/****************************************************************************************************
    DAP Peak limiter test mode enumerator 
        Used to enable, disable peak limiter test mode.
 ***************************************************************************************************/
typedef enum _xa_dap_plim_test_control_t {
    XA_DAP_PLIM_TEST_DISABLE = 0,         /* Disable */ 
    XA_DAP_PLIM_TEST_ENABLE = 1,          /* Enable */
} xa_dap_plim_test_control_t;


/****************************************************************************************************
    DAP Endpoint mode enumerator 
        Used to specify the endpoint of the signal chain.
 ***************************************************************************************************/
typedef enum _xa_dap_endp_t {
    XA_DAP_ENDP_INT_SPEAKERS = 0,       /* Internal speakers */ 
    XA_DAP_ENDP_EXT_SPEAKERS = 1,       /* External speakers*/ 
    XA_DAP_ENDP_HEADPHONES = 2,         /* Headphones */ 
    XA_DAP_ENDP_HDMI = 3,               /* HDMI */ 
    XA_DAP_ENDP_SPDIF = 4,              /* SPDIF */ 
    XA_DAP_ENDP_DLNA = 5,               /* DLNA */ 
    XA_DAP_ENDP_ANALOG = 6              /* ANALOG */ 
} xa_dap_endp_t;


/****************************************************************************************************
    DAP output channel format enumerator 
        Specifies the output channel configuration.  
 ***************************************************************************************************/
typedef enum _xa_dap_ocf_t {
    XA_DAP_OCF_STEREO = 0,         /* Stereo output */ 
    XA_DAP_OCF_5DOT1 = 1,          /* 5.1 output */
    XA_DAP_OCF_7DOT1 = 2           /* 7.1 output */
} xa_dap_ocf_t;

#if defined(__cplusplus)
extern "C" {
#endif    /* __cplusplus */

xa_codec_func_t xa_dap;

#if defined(__cplusplus)
}
#endif    /* __cplusplus */

#endif /* __XA_DAP_API_H__ */


