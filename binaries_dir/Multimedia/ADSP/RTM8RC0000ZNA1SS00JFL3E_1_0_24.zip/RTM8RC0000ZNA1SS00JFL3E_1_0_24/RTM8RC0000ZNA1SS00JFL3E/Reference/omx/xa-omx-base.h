/** *****************************************************************************
  \file       xa-omx-base.h
  \brief      Header file of ADSP Interface Common
  \addtogroup ADSP Interface
 ********************************************************************************
  \date       Mar. 02, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information
   of Renesas Electronics Corporation. They must be used and modified solely for
   the purpose for which it was furnished by Renesas Electronics Corporation.
   All part of them must not be reproduced nor disclosed to others in any form,
   without the prior written permission of Renesas Electronics Corporation.
 ********************************************************************************/

#ifndef __XA_OMX_BASE_H
#define __XA_OMX_BASE_H

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include <OMX_Component.h>

/*******************************************************************************
 * Extension index
 ******************************************************************************/

enum {
    XAOMX_IndexVendorBaseDsp = (OMX_IndexVendorStartUnused + 0x00030000)  /* ADSP domain */
};

/* Add extend OMX_TeardownTunnel API from OpenMAX IL 1.2.0 */
#if (OMX_VERSION_MAJOR == 1) && (OMX_VERSION_MINOR == 1) && (OMX_VERSION_REVISION == 2)
OMX_API OMX_ERRORTYPE OMX_APIENTRY OMX_TeardownTunnel(
    OMX_IN OMX_HANDLETYPE hOutput,
    OMX_IN OMX_U32 nPortOutput,
    OMX_IN OMX_HANDLETYPE hInput,
    OMX_IN OMX_U32 nPortInput
);
#endif

#endif
