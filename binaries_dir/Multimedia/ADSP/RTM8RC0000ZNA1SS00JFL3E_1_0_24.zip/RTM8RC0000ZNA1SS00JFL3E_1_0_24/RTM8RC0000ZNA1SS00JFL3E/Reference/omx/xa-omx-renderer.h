/** *****************************************************************************
  \file       xa-omx-renderer.h
  \brief      Header file of ADSP Renderer Interface
  \addtogroup ADSP Interface
 ********************************************************************************
  \date       Mar. 02, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information
   of Renesas Electronics Corporation. They must be used and modified solely for
   the purpose for which it was furnished by Renesas Electronics Corporation.
   All part of them must not be reproduced nor disclosed to others in any form,
   without the prior written permission of Renesas Electronics Corporation.
 ********************************************************************************/

#ifndef __XA_OMX_RENDERER_H__
#define __XA_OMX_RENDERER_H__

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xa-omx-base.h"

/*******************************************************************************
 * Definition of renderer and capture index parameters 
 ******************************************************************************/

enum {
    XAOMX_IndexVendorBaseDspRenderer  = (XAOMX_IndexVendorBaseDsp + 0x2000)  /* Renderer domain */
};

enum {
    XAOMX_IndexParamAudioRenderer = (XAOMX_IndexVendorBaseDspRenderer + 0x0200),  /* OMX.RENESAS.INDEX.PARAM.AUDIO.DSP.RENDERER */
    XAOMX_IndexParamAudioCapture = (XAOMX_IndexVendorBaseDspRenderer + 0x0300)    /* OMX.RENESAS.INDEX.PARAM.AUDIO.DSP.CAPTURE */
};
 
 /*******************************************************************************
 * Definition of renderer parameters structure
 ******************************************************************************/

/** \struct XAOMX_AUDIO_PARAM_RENDERER
    \brief  Parametric Renderer Settings Structure
 */
typedef struct XAOMX_AUDIO_PARAM_RENDERER
{
    OMX_U32                            nSize;                 /**< Size of this structure, in Bytes */
    OMX_VERSIONTYPE                    nVersion;              /**< OMX specification version information */
    OMX_U32                            nPCM_frame_size;       /**< PCM framesize  */
    OMX_U32                            nPCM_output1;          /**< Output device 1 of Renderer */
    OMX_U32                            nPCM_DMAchannel1;      /**< Data transfer type of device 1 */
    OMX_U32                            nPCM_output2;          /**< Output device 2 of Renderer */
    OMX_U32                            nPCM_DMAchannel2;      /**< Data transfer type of device 2 */
    OMX_U32                            nPCM_in_sample_rate;   /**< Renderer in sample rate */
    OMX_U32                            nPCM_out_sample_rate;  /**< Renderer out sample rate */
    OMX_U32                            nPCM_volume_rate;      /**< Renderer volume rate */
    OMX_U32                            nPCM_in_channel;       /**< Number of Renderer in channel*/
    OMX_U32                            nPCM_out_channel;      /**< Number of Renderer out channel*/
    OMX_U32                            nPCM_mix_control;      /**< Renderer mixer function control flag*/
} XAOMX_AUDIO_PARAM_RENDERER;

/*******************************************************************************
 * Definition of capture parameters structure
 ******************************************************************************/

/** \struct XAOMX_AUDIO_PARAM_CAPTURE
    \brief  Parametric Capture Settings Structure
 */
typedef struct XAOMX_AUDIO_PARAM_CAPTURE
{
    OMX_U32                            nSize;                 /**< Size of this structure, in Bytes */  
    OMX_VERSIONTYPE                    nVersion;              /**< OMX specification version information */
    OMX_U32                            nPCM_frame_size;       /**< OMX PCM framesize  */
    OMX_U32                            nPCM_input1;           /**< Input device 1 of Capture */
    OMX_U32                            nPCM_DMAchannel1;      /**< Data transfer type of device 1  */
    OMX_U32                            nPCM_input2;           /**< Input device 2 of Capture */
    OMX_U32                            nPCM_DMAchannel2;      /**< Data transfer type of device 2*/
    OMX_U32                            nPCM_in_sample_rate;   /**< Capture in sample rate*/
    OMX_U32                            nPCM_out_sample_rate;  /**< Capture out sample rate */
    OMX_U32                            nPCM_volume_rate;      /**< Capture volume rate*/
} XAOMX_AUDIO_PARAM_CAPTURE;


/** \enum   ADMAC_SRCDST
    \brief  The value for set_pdma_extend() function arguments.
 */
typedef enum {
    SSI00 = 0,
    SSI01,
    SSI02,
    SSI03,
    SSI04,
    SSI05,
    SSI06,
    SSI07,
    SSI10 = 10,
    SSI11,
    SSI12,
    SSI13,
    SSI14,
    SSI15,
    SSI16,
    SSI17,
    SSI20 = 20,
    SSI21,
    SSI22,
    SSI23,
    SSI24,
    SSI25,
    SSI26,
    SSI27,
    SSI30 = 30,
    SSI31,
    SSI32,
    SSI33,
    SSI34,
    SSI35,
    SSI36,
    SSI37,
    SSI40 = 40,
    SSI41,
    SSI42,
    SSI43,
    SSI44,
    SSI45,
    SSI46,
    SSI47,
    SSI50 = 50,
    SSI60 = 60,
    SSI70 = 70,
    SSI80 = 80,
    SSI90 = 90,
    SSI91,
    SSI92,
    SSI93,
    SSI94,
    SSI95,
    SSI96,
    SSI97 = 97,
    DTCPPP0,
    DTCPPP1,
    DTCPCP0,
    DTCPCP1,
    ADSPO0,
    ADSPI0,
    ADSPO1,
    ADSPI1,
    ADSPO2,
    ADSPI2,
    ADSPO3,
    ADSPI3,
    SCU_SRCI0 = 110,
    SCU_SRCI1,
    SCU_SRCI2,
    SCU_SRCI3,
    SCU_SRCI4,
    SCU_SRCI5,
    SCU_SRCI6,
    SCU_SRCI7,
    SCU_SRCI8,
    SCU_SRCI9 = 119,
    SCU_SRCO0 = 120,
    SCU_SRCO1,
    SCU_SRCO2,
    SCU_SRCO3,
    SCU_SRCO4,
    SCU_SRCO5,
    SCU_SRCO6,
    SCU_SRCO7,
    SCU_SRCO8,
    SCU_SRCO9 = 129,
    SCU_CMD0 = 130,
    SCU_CMD1 = 131,
    MLM0,
    MLM1,
    MLM2,
    MLM3,
    MLM4,
    MLM5,
    MLM6,
    MLM7,
    NONCONFIG,
    SRC_DST_MAX        = 141
} SRCDST;

/** \enum   ADMAC_CH
    \brief  The value for set_pdma_extend() function argument.
 */
typedef enum {
    ADMACPP_CH00 = 0,
    ADMACPP_CH01,
    ADMACPP_CH02,
    ADMACPP_CH03,
    ADMACPP_CH04,
    ADMACPP_CH05,
    ADMACPP_CH06,
    ADMACPP_CH07,
    ADMACPP_CH08,
    ADMACPP_CH09,
    ADMACPP_CH10,
    ADMACPP_CH11,
    ADMACPP_CH12,
    ADMACPP_CH13,
    ADMACPP_CH14,
    ADMACPP_CH15,
    ADMACPP_CH16,
    ADMACPP_CH17,
    ADMACPP_CH18,
    ADMACPP_CH19,
    ADMACPP_CH20,
    ADMACPP_CH21,
    ADMACPP_CH22,
    ADMACPP_CH23,
    ADMACPP_CH24,
    ADMACPP_CH25,
    ADMACPP_CH26,
    ADMACPP_CH27,
    ADMACPP_CH28,
    ADMAC_CH00 = 29,
    ADMAC_CH01,
    ADMAC_CH02,
    ADMAC_CH03,
    ADMAC_CH04,
    ADMAC_CH05,
    ADMAC_CH06,
    ADMAC_CH07,
    ADMAC_CH08,
    ADMAC_CH09,
    ADMAC_CH10,
    ADMAC_CH11,
    ADMAC_CH12,
    ADMAC_CH13,
    ADMAC_CH14,
    ADMAC_CH15,
    ADMAC_CH16,
    ADMAC_CH17,
    ADMAC_CH18,
    ADMAC_CH19,
    ADMAC_CH20,
    ADMAC_CH21,
    ADMAC_CH22,
    ADMAC_CH23,
    ADMAC_CH24,
    ADMAC_CH25,
    ADMAC_CH26,
    ADMAC_CH27,
    ADMAC_CH28,
    ADMAC_CH29,
    ADMAC_CH30,
    ADMAC_CH31,
    ADMAC_CHMAX
} ADMAC_CH;

#endif /* __XA_OMX_RENDERER_H__ */
