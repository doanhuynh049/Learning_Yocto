/** *****************************************************************************
  \file       omx-renderer.c
  \brief      ADSP Renderer Interface
  \addtogroup ADSP Interface
 ********************************************************************************
  \date       Mar. 02, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information
   of Renesas Electronics Corporation. They must be used and modified solely for
   the purpose for which it was furnished by Renesas Electronics Corporation.
   All part of them must not be reproduced nor disclosed to others in any form,
   without the prior written permission of Renesas Electronics Corporation.
 ********************************************************************************/

/*******************************************************************************
 * omx-renderer.c
 *
 * OMX IL component for ADSP renderer
 ******************************************************************************/

#define MODULE_TAG                      RENDERER_INTERFACE

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xf-ap.h"
#include "omx-codec-base.h"
#include "audio/xa-renderer-api.h"
#include "xa-omx-renderer.h"

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(INIT, 1);

/*******************************************************************************
 * Local typedefs
 ******************************************************************************/

/** \struct XAOMXRenderer
    \brief  Renderer Structure
 */
typedef struct _XAOMXRenderer
{
    /** ...generic codec structure */
    XAOMXCodecBase                  base;
   
    /** ...PCM-specific parameters (input port) */
    OMX_AUDIO_PARAM_PCMMODETYPE     sPCM;

    /** ...Renderer parametrs */
    XAOMX_AUDIO_PARAM_RENDERER      sRENDERER;

} XAOMXRenderer;

/*******************************************************************************
 * Local constants definitions
 ******************************************************************************/

/** \def NUM_INPUT_BUFFERS
    ...total amount of input buffers
 */
#define NUM_INPUT_BUFFERS               4

/** \def INPUT_BUFFER_LENGTH
    ...default input buffer length
 */
#define INPUT_BUFFER_LENGTH             4096

/** \def BUFFER_ALIGNMENT
    ...required data alignment
 */
#define BUFFER_ALIGNMENT                32

/*******************************************************************************
 * Function declarations
 ******************************************************************************/
static s32 RENDERER_Setup(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg);
static s32 RENDERER_RuntimeInit(XAOMXCodecBase *pBase, xf_start_msg_t *msg);
static s32 RENDERER_GetParam(XAOMXCodecBase *pBase, xf_get_param_msg_t *msg, u32 length);
static void RENDERER_TimeStamp(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr);
static OMX_ERRORTYPE RENDERER_GetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE RENDERER_SetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE RENDERER_ComponentDeInit(OMX_HANDLETYPE hComponent);
static OMX_ERRORTYPE RENDERER_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks);
static s32 RENDERER_SetConfig_Send(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg, OMX_PTR pParam);
static OMX_ERRORTYPE RENDERER_SetConfigIndex(OMX_INDEXTYPE nIndex);

/*******************************************************************************
 * Low-level codec commands (called from component thread context)
 ******************************************************************************/

/** **************************************************************************
    \brief        RENDERER_SetConfig_Send
     Prepare message contain wanted to set parameters for XF_SET_PARAM command to send to plug-in

    \param[in]      *pBase      Pointer to pComponentPrivate of Renderer component 
    \param[in]      *msg        Message send to Renderer plug-in
    \retval         length      Number of parameters want to set for Renderer plug-in
 *****************************************************************************/
static s32 RENDERER_SetConfig_Send(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg, OMX_PTR pParam)
{
    XAOMXRenderer    *pData = (XAOMXRenderer *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */
    XAOMX_AUDIO_PARAM_RENDERER *user_param = (XAOMX_AUDIO_PARAM_RENDERER *) pParam;

    /*Check if we need to set volume to plug-in*/
    if (user_param->nPCM_volume_rate != pData->sRENDERER.nPCM_volume_rate)
    {
        /* ...save parameter to OMX_coponent */
        pData->sRENDERER.nPCM_volume_rate = user_param->nPCM_volume_rate;

        /* ...prepare parameters to set */
        msg->item[0].id = XA_RDR_CONFIG_PARAM_VOLUME_RATE;
        msg->item[0].value = pData->sRENDERER.nPCM_volume_rate;

        TRACE(INIT, _b("RENDERER set_config"));
        TRACE(INIT, _b("PCM volume rate:      0x%08x"), pData->sRENDERER.nPCM_volume_rate);

        /* ...return number of parameters we want to set */
        return XF_SET_PARAM_CMD_LEN(1);
    }

    return 0;
}

/** **************************************************************************
    \brief        Renderer SetConfigIndex
    Check the index of OMX_SetConfig is correct

    \param[in]      nIndex                       Index of parameter structure
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE RENDERER_SetConfigIndex(OMX_INDEXTYPE nIndex)
{
    /* ...check index type is supported */
    XF_CHK_ERR(nIndex == (OMX_INDEXTYPE) XAOMX_IndexParamAudioRenderer, OMX_ErrorUnsupportedIndex);

    return XA_NO_ERROR;
}

/** **************************************************************************
    \brief        Renderer prepare codec setup parameters

    \param[in]      *pBase      Pointer to pComponentPrivate of Renderer component
    \param[in]      *msg        Message send to Renderer plugin
    \retval         length      Number of parameters want to set for Renderer plugin
 *****************************************************************************/
static s32 RENDERER_Setup(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg)
{
    XAOMXRenderer    *pData = (XAOMXRenderer *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */
    int i = 0;

    TRACE(INIT, _b("RENDERER stream set parameters"));
    TRACE(INIT, _b("PCM width:            %lu"), pData->sPCM.nBitPerSample);
    TRACE(INIT, _b("Number of channels:   %lu"), pData->sRENDERER.nPCM_in_channel);
    TRACE(INIT, _b("Sampling rate:        %lu"), pData->sRENDERER.nPCM_in_sample_rate);
    TRACE(INIT, _b("PCM frame size:       %lu"), pData->sRENDERER.nPCM_frame_size);
    TRACE(INIT, _b("PCM output dest 1:    %lu"), pData->sRENDERER.nPCM_output1);
    TRACE(INIT, _b("PCM DMA channel 1:    %lu"), pData->sRENDERER.nPCM_DMAchannel1);
    TRACE(INIT, _b("PCM output dest 2:    %lu"), pData->sRENDERER.nPCM_output2);
    TRACE(INIT, _b("PCM DMA channel 2:    %lu"), pData->sRENDERER.nPCM_DMAchannel2);
    TRACE(INIT, _b("PCM out sample rate:  %lu"), pData->sRENDERER.nPCM_out_sample_rate);
    TRACE(INIT, _b("PCM volume rate:      0x%08x"), pData->sRENDERER.nPCM_volume_rate);
    TRACE(INIT, _b("PCM out channel:  %lu"), pData->sRENDERER.nPCM_out_channel);
    TRACE(INIT, _b("PCM mix control:  %lu"), pData->sRENDERER.nPCM_mix_control);

    /* ...prepare parameters to set */
    msg->item[i].id = XA_RDR_CONFIG_PARAM_PCM_WIDTH;
    msg->item[i++].value = pData->sPCM.nBitPerSample;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_CHANNELS;
    msg->item[i++].value = pData->sRENDERER.nPCM_in_channel;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_SAMPLE_RATE;
    msg->item[i++].value = pData->sRENDERER.nPCM_in_sample_rate;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_FRAME_SIZE;
    msg->item[i++].value = pData->sRENDERER.nPCM_frame_size;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_OUTPUT1;
    msg->item[i++].value = pData->sRENDERER.nPCM_output1;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_DMACHANNEL1;
    msg->item[i++].value = pData->sRENDERER.nPCM_DMAchannel1;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_OUTPUT2;
    msg->item[i++].value = pData->sRENDERER.nPCM_output2;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_DMACHANNEL2;
    msg->item[i++].value = pData->sRENDERER.nPCM_DMAchannel2;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_OUT_SAMPLE_RATE;
    msg->item[i++].value = pData->sRENDERER.nPCM_out_sample_rate;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_VOLUME_RATE;
    msg->item[i++].value = pData->sRENDERER.nPCM_volume_rate;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_OUT_CHANNELS;
    msg->item[i++].value = pData->sRENDERER.nPCM_out_channel;

    msg->item[i].id = XA_RDR_CONFIG_PARAM_MIX_CONTROL;
    msg->item[i++].value = pData->sRENDERER.nPCM_mix_control;

    /* ...return number of parameters we want to set */
    return XF_SET_PARAM_CMD_LEN(i);
}

/** **************************************************************************
    \brief        Renderer runtime initialization hook

    \param[in]      *pBase      Pointer to pComponentPrivate of Renderer component
    \param[in]      *msg        Message send to Renderer plugin
    \retval         length      Number of parameters want to get from Renderer plugin
 *****************************************************************************/
static s32 RENDERER_RuntimeInit(XAOMXCodecBase *pBase, xf_start_msg_t *msg)     /* PRQA S 3206 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    TRACE(INIT, _b("RENDERER Runtime Initial "));
    
    /* ...don't need any post-configuration update here - so bail out */
    return XF_GET_PARAM_CMD_LEN(0);
}

/** **************************************************************************
    \brief        Renderer process input stream parameters

    \param[in]      *pBase      Pointer to pComponentPrivate of Renderer component
    \param[in]      *msg        Message receive from Renderer plugin
    \param[in]      length      Length of message 
    \retval         0           Success
 *****************************************************************************/
static s32 RENDERER_GetParam(XAOMXCodecBase *pBase, xf_get_param_msg_t *msg, u32 length)    /* PRQA S 3206 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    /* ...check the message length is correct */
    XF_CHK_ERR(length == XF_GET_PARAM_RSP_LEN(0), -EBADF);

    return 0;
}

/** **************************************************************************
    \brief        Renderer timestamp advance function

    \param[in]      *pBase      Pointer to pComponentPrivate of Renderer component
    \param[in]      *pBufHdr    Input buffer  
 *****************************************************************************/
static void RENDERER_TimeStamp(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    XAOMXRenderer    *pData = (XAOMXRenderer *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */
    u32                 length = pBufHdr->nFilledLen;
    u32                 n = (length * 8) / (pData->sRENDERER.nPCM_in_channel * pData->sPCM.nBitPerSample);

    /* ...add current timestamp to the input buffer */
    pBufHdr->nTimeStamp = pBase->nTimeStamp;

    /* ...advance timestamp for the next buffer (very basic and inaccurate way) */
    pBase->nTimeStamp += (n * 1000000) / pData->sRENDERER.nPCM_in_sample_rate;
}

/*******************************************************************************
 * Codec-specific OMX IL interface
 ******************************************************************************/

/** **************************************************************************
    \brief        Renderer get parameter

    \param[in]      *pBase                       Pointer to pComponentPrivate of Renderer component
    \param[in]      nIndex                       Index of parameter structure
    \param[in]      pParam                       Pointer to parameter structure want to get
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE RENDERER_GetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXRenderer    *pData = (XAOMXRenderer *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */

    switch(nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...gets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sPCM, sizeof(*param));        /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        break;
    }
    case XAOMX_IndexParamAudioRenderer:         /* PRQA S 1460 *//* Confirm extension enum value is correct. Oct 14, 2016 */
    {
        /* ...gets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        XAOMX_AUDIO_PARAM_RENDERER    *param = (XAOMX_AUDIO_PARAM_RENDERER *) pParam;

        memcpy(param, &pData->sRENDERER, sizeof(*param));   /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        break;
    }
    case OMX_IndexParamCompBufferSupplier:
    {
        /* ...gets OMX_PARAM_BUFFERSUPPLIERTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_BUFFERSUPPLIERTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort == 0, OMX_ErrorBadPortIndex);

        memcpy(pParam, &pData->base.sSupplier[nPort], sizeof(OMX_PARAM_BUFFERSUPPLIERTYPE));    /* PRQA S 3200 *//* Confirm return vlaue is no use. Oct 14, 2016 */

        break;
    }
    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        Renderer Set parameter

    \param[in]      *pBase                       Pointer to pComponentPrivate of Renderer component
    \param[in]      nIndex                       Index of parameter structure
    \param[in]      pParam                       Pointer to parameter structure want to set
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE RENDERER_SetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXRenderer    *pData = (XAOMXRenderer *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */

    switch(nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...sets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(&pData->sPCM, param, sizeof(*param));        /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        TRACE(INIT, _b("PCM parameters set"));
        TRACE(INIT, _b("Sample width:       %lu"), pData->sPCM.nBitPerSample);

        break;
    }
    case XAOMX_IndexParamAudioRenderer:                     /* PRQA S 1460 *//* Confirm extension enum value is correct. Oct 14, 2016 */
    {
        /* ...sets XAOMX_AUDIO_PARAM_RENDERER structure */
        XAOMX_AUDIO_PARAM_RENDERER    *param = (XAOMX_AUDIO_PARAM_RENDERER *) pParam;

        memcpy(&pData->sRENDERER, param, sizeof(*param));   /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        TRACE(INIT, _b("RENDERER parameters set"));
        TRACE(INIT, _b("Frame size:         %lu"), pData->sRENDERER.nPCM_frame_size);
        TRACE(INIT, _b("Output1:            %lu"), pData->sRENDERER.nPCM_output1);
        TRACE(INIT, _b("ADMP channel1:      %lu"), pData->sRENDERER.nPCM_DMAchannel1);
        TRACE(INIT, _b("Output2:            %lu"), pData->sRENDERER.nPCM_output2);
        TRACE(INIT, _b("ADMP channel2:      %lu"), pData->sRENDERER.nPCM_DMAchannel2);
        TRACE(INIT, _b("In sampling rate:      %lu"), pData->sRENDERER.nPCM_in_sample_rate);
        TRACE(INIT, _b("Out sample rate:    %lu"), pData->sRENDERER.nPCM_out_sample_rate);
        TRACE(INIT, _b("Volume rate  :      0x%08x"), pData->sRENDERER.nPCM_volume_rate);
        TRACE(INIT, _b("Number of in channels: %lu"), pData->sRENDERER.nPCM_in_channel);
        TRACE(INIT, _b("Number of out channels: %lu"), pData->sRENDERER.nPCM_out_channel);
        TRACE(INIT, _b("Mixer control: %lu"), pData->sRENDERER.nPCM_mix_control);
        break;
    }
    case OMX_IndexParamCompBufferSupplier:
    {
        /* ...gets OMX_PARAM_BUFFERSUPPLIERTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_BUFFERSUPPLIERTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort == 0, OMX_ErrorBadPortIndex);

        memcpy(&pData->base.sSupplier[nPort], pParam, sizeof(OMX_PARAM_BUFFERSUPPLIERTYPE));    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        TRACE(INIT, _b("Buffer supplier [%d]: %d"), nPort, pData->base.sSupplier[nPort].eBufferSupplier);

        break;
    }
    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        RENDERER_ComponentDeInit 

    \param[in]      hComponent                   Pointer to Renderer component handle
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
static OMX_ERRORTYPE RENDERER_ComponentDeInit(OMX_HANDLETYPE hComponent)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXRenderer    *pData = (XAOMXRenderer *) pComp->pComponentPrivate;

    /* ...destroy base component */
    XAOMX_CHK_API(XAOMX_ComponentDeInit(hComponent));

    /* ...destroy private data */
    free(pData);        /* PRQA S 5118 *//* Confirm free memory usage is correct. Oct 14, 2016 */

    /* ...destroy component data itself (component ceases to exist) */
    free(pComp);        /* PRQA S 5118 *//* Confirm free memory usage is correct. Oct 14, 2016 */

    TRACE(INIT, _b("RENDERER component destroyed"));

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        RENDERER_ComponentInit 

    \param[in]      *proxy                       OpenMAX interface proxy
    \param[in]      hComponent                   Pointer to Renderer component handle
    \param[in]      pAppData                     Pointer to pAppData of Renderer component 
    \param[in]      *pCallbacks                  Pointer to Callbacks of Renderer component 
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
static OMX_ERRORTYPE RENDERER_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE   *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXRenderer       *pData = (XAOMXRenderer *)pComp->pComponentPrivate;

    /* ...initialize base codec interface */
    XAOMX_CHK_API(XAOMX_ComponentInit(proxy, hComponent, pAppData, pCallbacks, "audio_renderer.pcm", "renderer"));

    /* ...set codec-specific callbacks */
    pData->base.pComponentName = "OMX.RENESAS.AUDIO.DSP.RENDERER";
    pData->base.SetParameter = &RENDERER_SetParameter;      /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.GetParameter = &RENDERER_GetParameter;      /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.SetConfig_Send = &RENDERER_SetConfig_Send;  /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.SetConfigIndex = &RENDERER_SetConfigIndex;       /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecSetup = &RENDERER_Setup;               /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecRuntimeInit = &RENDERER_RuntimeInit;   /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecGetParam = &RENDERER_GetParam;         /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecTimeStamp = &RENDERER_TimeStamp;       /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */

    /* ...override component interface */
    pComp->ComponentDeInit = &RENDERER_ComponentDeInit;

    /* ...initialize the audio parameters for input port */
    pData->base.sPortDef[0].nBufferCountActual = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferCountMin = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferSize = INPUT_BUFFER_LENGTH;
    pData->base.sPortDef[0].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[0].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[0].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[0].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[0].format.audio.bFlagErrorConcealment = OMX_FALSE;

    /* ...need a fake output buffer port to follow other OMX - tbd need to consider remove it */
    pData->base.sPortDef[1].nBufferCountActual = 1;
    pData->base.sPortDef[1].nBufferCountMin = 1;
    pData->base.sPortDef[1].nBufferSize = 1;
    pData->base.sPortDef[1].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[1].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[1].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[1].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[1].format.audio.bFlagErrorConcealment = OMX_FALSE;

    /* ...initialize the compression format for input port */
    pData->base.sPortFormat[0].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[0].eEncoding = OMX_AUDIO_CodingPCM;

    pData->base.sPortFormat[1].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[1].eEncoding = OMX_AUDIO_CodingPCM;

    /* ...PCM format defaults */
    XAOMX_INIT_STRUCT(&pData->sPCM, OMX_AUDIO_PARAM_PCMMODETYPE);
    XAOMX_INIT_STRUCT(&pData->sRENDERER, XAOMX_AUDIO_PARAM_RENDERER);
    pData->sPCM.nPortIndex = 0;
    pData->sPCM.nChannels = 2;
    pData->sPCM.nSamplingRate = 44100;
    pData->sPCM.nBitPerSample = 16;
    pData->sPCM.eNumData = OMX_NumericalDataSigned;
    pData->sPCM.eEndian = OMX_EndianLittle;
    pData->sPCM.bInterleaved = OMX_TRUE;
    pData->sPCM.ePCMMode = OMX_AUDIO_PCMModeLinear;
    pData->sPCM.eChannelMapping[0] = OMX_AUDIO_ChannelLF;
    pData->sPCM.eChannelMapping[1] = OMX_AUDIO_ChannelRF;

    /* Renderer parameters structure default format */
    pData->sRENDERER.nPCM_frame_size = 1024;
    pData->sRENDERER.nPCM_output1 = SSI00;
    pData->sRENDERER.nPCM_DMAchannel1 = ADMACPP_CH00;
    pData->sRENDERER.nPCM_output2 = NONCONFIG;
    pData->sRENDERER.nPCM_DMAchannel2 = ADMACPP_CH01;
    pData->sRENDERER.nPCM_in_sample_rate = 44100;
    pData->sRENDERER.nPCM_out_sample_rate = 44100;
    pData->sRENDERER.nPCM_volume_rate = 0xFFFFFFFF;
    pData->sRENDERER.nPCM_in_channel = 2;
    pData->sRENDERER.nPCM_out_channel = 2;
    pData->sRENDERER.nPCM_mix_control = 0;
    TRACE(INIT, _b("RENDERER instantiated"));

    return OMX_ErrorNone;
}

/*******************************************************************************
 * Entry points
 ******************************************************************************/

/** **************************************************************************
    \brief     RENDERER_ComponentCreate 

    \param[in]      *proxy                       OpenMAX interface proxy
    \param[in]      *hComponent                  Pointer to Renderer component handle
    \param[in]      pAppData                     Pointer to pAppData of Renderer component 
    \param[in]      *pCallbacks                  Pointer to Callbacks of Renderer component 
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
OMX_ERRORTYPE RENDERER_ComponentCreate(xf_proxy_t *proxy, OMX_HANDLETYPE *hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)   /* PRQA S 1503, 3408 *//* Confirm function definition and usage is correct. Oct 14, 2016 */
{
    OMX_COMPONENTTYPE   *pComp;
    XAOMXRenderer       *pData;
    OMX_ERRORTYPE       eError = OMX_ErrorInsufficientResources;

    /* ...create the base component */
    pComp = calloc(1, sizeof(*pComp));      /* PRQA S 5118 *//* Confirm memory allocation is correct. Oct 14, 2016 */
    if (pComp == NULL) {
        goto error;     /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    /* ...set component version */
    XAOMX_INIT_STRUCT(pComp, OMX_COMPONENTTYPE);

    /* ...allocate private memory */
    pData = calloc(1, sizeof(*pData));      /* PRQA S 5118 *//* Confirm memory allocation is correct. Oct 14, 2016 */
    if (pData == NULL) {
        goto error1;    /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    /* ...set private data handle */
    pComp->pComponentPrivate = (OMX_PTR) pData;

    /* ...initialize component */
    eError = RENDERER_ComponentInit(proxy, (OMX_HANDLETYPE)pComp, pAppData, pCallbacks);
    if (eError != OMX_ErrorNone) {
        goto error1;    /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    TRACE(INIT, _b("RENDERER initialized"));

    /* ...return component handle */
    *hComponent = (OMX_HANDLETYPE)pComp;

    return OMX_ErrorNone;

error1:
    /* ...destroy component handle data */
    free(pComp);        /* PRQA S 5118 *//* Confirm free memomry is used correctly. Oct 14, 2016 */

error:
    TRACE(INIT, _b("RENDERER component creation failed: %X"), eError);

    return eError;
}
