/*******************************************************************************
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 ******************************************************************************/

/*******************************************************************************
 * xa-audio-decoder-api.h
 *
 * Generic audio decoder API
 ******************************************************************************/

#ifndef __XA_ADEC_API_H__
#define __XA_ADEC_API_H__

/* ...includes */
#include "xa_type_def.h"
#include "xa_error_standards.h"
#include "xa_apicmd_standards.h"
#include "xa_memory_standards.h"

/* ...generic audio-decoder configuration parameters */
enum xa_config_param_codec {
    XA_CODEC_CONFIG_PARAM_CHANNELS       = 0x10000 + 0,
    XA_CODEC_CONFIG_PARAM_SAMPLE_RATE    = 0x10000 + 1,
    XA_CODEC_CONFIG_PARAM_PCM_WIDTH      = 0x10000 + 2,
    XA_CODEC_CONFIG_PARAM_PRODUCED       = 0x10000 + 3
};

/* ...ports indices */
enum xa_codec_ports {
    XA_CODEC_INPUT_PORT  = 0,
    XA_CODEC_OUTPUT_PORT = 1
};

/* ...non-fatal execution errors */
enum
{
    XA_CODEC_EXEC_NO_DATA = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_GENERIC, 0)
};

/* ...fatal execution errors */
enum
{
    XA_CODEC_EXEC_SEQUENCE = XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_GENERIC, 0),
    XA_CODEC_EXEC_MISBEHAVING = XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_GENERIC, 1),
};

#endif
