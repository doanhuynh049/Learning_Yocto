/** *****************************************************************************
  \file       omx-tdm-renderer.c
  \brief      ADSP TDM Renderer Interface
  \addtogroup ADSP Interface
 ********************************************************************************
  \date       Mar. 02, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information
   of Renesas Electronics Corporation. They must be used and modified solely for
   the purpose for which it was furnished by Renesas Electronics Corporation.
   All part of them must not be reproduced nor disclosed to others in any form,
   without the prior written permission of Renesas Electronics Corporation.
 ********************************************************************************/

/*******************************************************************************
 * omx-tdm-renderer.c
 *
 * OMX IL component for ADSP TDM renderer
 ******************************************************************************/

#define MODULE_TAG                      TDM_RENDERER_INTERFACE

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xf-ap.h"
#include "omx-tdm-codec-base.h"
#include "audio/xa-tdm-renderer-api.h"
#include "xa-omx-tdm-renderer.h"

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(INIT, 1);

/*******************************************************************************
 * Local typedefs
 ******************************************************************************/

/** \struct XAOMX_TDM_RDR
    \brief  TDM Renderer Structure
 */
typedef struct _XAOMX_TDM_RDR
{
    /** ...generic codec structure */
    XAOMXTDMCodecBase                   base;
   
    /** ...PCM-specific parameters (input port) */
    OMX_AUDIO_PARAM_PCMMODETYPE         sPCM;

    /** ...TDM Renderer parametrs */
    XAOMX_AUDIO_PARAM_TDM_RENDERER      sTDM_RENDERER;

} XAOMX_TDM_RDR;

/*******************************************************************************
 * Local constants definitions
 ******************************************************************************/

/** \def NUM_INPUT_BUFFERS
    ...total amount of input buffers
 */
#define NUM_INPUT_BUFFERS               (4)

/** \def INPUT_BUFFER_LENGTH
    ...default input buffer length
 */
#define INPUT_BUFFER_LENGTH             (4096)

/** \def BUFFER_ALIGNMENT
    ...required data alignment
 */
#define BUFFER_ALIGNMENT                (32)

/*******************************************************************************
 * Function declarations
 ******************************************************************************/
static s32 TDM_RENDERER_Setup(XAOMXTDMCodecBase *pBase, xf_set_param_msg_t *msg);
static s32 TDM_RENDERER_RuntimeInit(XAOMXTDMCodecBase *pBase, xf_start_msg_t *msg);
static s32 TDM_RENDERER_GetParam(XAOMXTDMCodecBase *pBase, xf_get_param_msg_t *msg, u32 length);
static void TDM_RENDERER_TimeStamp(XAOMXTDMCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr);
static OMX_ERRORTYPE TDM_RENDERER_GetParameter(XAOMXTDMCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE TDM_RENDERER_SetParameter(XAOMXTDMCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE TDM_RENDERER_ComponentDeInit(OMX_HANDLETYPE hComponent);
static OMX_ERRORTYPE TDM_RENDERER_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks);

/*******************************************************************************
 * Low-level codec commands (called from component thread context)
 ******************************************************************************/

/** **************************************************************************
    \brief        TDM Renderer prepare codec setup parameters

    \param[in]      *pBase      Pointer to pComponentPrivate of TDM Renderer component
    \param[in]      *msg        Message send to TDM Renderer plugin
    \retval         length      Number of parameters want to set for TDM Renderer plugin
 *****************************************************************************/
static s32 TDM_RENDERER_Setup(XAOMXTDMCodecBase *pBase, xf_set_param_msg_t *msg)
{
    XAOMX_TDM_RDR    *pData = (XAOMX_TDM_RDR *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */
    s32              i = 0;

    TRACE(INIT, _b("TDM RENDERER stream set parameters"));
    TRACE(INIT, _b("PCM width:          %lu"), pData->sPCM.nBitPerSample);
    TRACE(INIT, _b("Channel mode:       %lu"), pData->sTDM_RENDERER.nPCM_channel_mode);
    TRACE(INIT, _b("In sampling rate:   %lu"), pData->sTDM_RENDERER.nPCM_in_sample_rate);
    TRACE(INIT, _b("Out sampling rate:  %lu"), pData->sTDM_RENDERER.nPCM_out_sample_rate);
    TRACE(INIT, _b("PCM frame size:     %lu"), pData->sTDM_RENDERER.nPCM_frame_size);
    TRACE(INIT, _b("Output1:            %lu"), pData->sTDM_RENDERER.nPCM_output1);
    TRACE(INIT, _b("DMA channel1:       %lu"), pData->sTDM_RENDERER.nPCM_dma_channel1);
    TRACE(INIT, _b("Output2:            %lu"), pData->sTDM_RENDERER.nPCM_output2);
    TRACE(INIT, _b("DMA channel2:       %lu"), pData->sTDM_RENDERER.nPCM_dma_channel2);
    TRACE(INIT, _b("Volume rate:        %lu"), pData->sTDM_RENDERER.nPCM_volume_rate);

    /* ...prepare parameters to set */
    msg->item[i].id = XA_TDM_RDR_CONFIG_PARAM_PCM_WIDTH;
    msg->item[i++].value = pData->sPCM.nBitPerSample;

    msg->item[i].id = XA_TDM_RDR_CONFIG_PARAM_CHANNEL_MODE;
    msg->item[i++].value = pData->sTDM_RENDERER.nPCM_channel_mode;

    msg->item[i].id = XA_TDM_RDR_CONFIG_PARAM_IN_SAMPLE_RATE;
    msg->item[i++].value = pData->sTDM_RENDERER.nPCM_in_sample_rate;

    msg->item[i].id = XA_TDM_RDR_CONFIG_PARAM_OUT_SAMPLE_RATE;
    msg->item[i++].value = pData->sTDM_RENDERER.nPCM_out_sample_rate;

    msg->item[i].id = XA_TDM_RDR_CONFIG_PARAM_FRAME_SIZE;
    msg->item[i++].value = pData->sTDM_RENDERER.nPCM_frame_size;

    msg->item[i].id = XA_TDM_RDR_CONFIG_PARAM_OUTPUT1;
    msg->item[i++].value = pData->sTDM_RENDERER.nPCM_output1;

    msg->item[i].id = XA_TDM_RDR_CONFIG_PARAM_DMACHANNEL1;
    msg->item[i++].value = pData->sTDM_RENDERER.nPCM_dma_channel1;

    msg->item[i].id = XA_TDM_RDR_CONFIG_PARAM_OUTPUT2;
    msg->item[i++].value = pData->sTDM_RENDERER.nPCM_output2;

    msg->item[i].id = XA_TDM_RDR_CONFIG_PARAM_DMACHANNEL2;
    msg->item[i++].value = pData->sTDM_RENDERER.nPCM_dma_channel2;

    msg->item[i].id = XA_TDM_RDR_CONFIG_PARAM_VOLUME_RATE;
    msg->item[i++].value = pData->sTDM_RENDERER.nPCM_volume_rate;

    /* ...return number of parameters we want to set */
    return XF_SET_PARAM_CMD_LEN(i);
}

/** **************************************************************************
    \brief        TDM Renderer runtime initialization hook

    \param[in]      *pBase      Pointer to pComponentPrivate of TDM Renderer component
    \param[in]      *msg        Message send to TDM Renderer plugin
    \retval         length      Number of parameters want to get from TDM Renderer plugin
 *****************************************************************************/
static s32 TDM_RENDERER_RuntimeInit(XAOMXTDMCodecBase *pBase, xf_start_msg_t *msg)     /* PRQA S 3206 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    /* ...don't need any post-configuration update here - so bail out */
    return XF_GET_PARAM_CMD_LEN(0);
}

/** **************************************************************************
    \brief        TDM Renderer process input stream parameters

    \param[in]      *pBase      Pointer to pComponentPrivate of TDM Renderer component
    \param[in]      *msg        Message receive from TDM Renderer plugin
    \param[in]      length      Length of message 
    \retval         0           Success
 *****************************************************************************/
static s32 TDM_RENDERER_GetParam(XAOMXTDMCodecBase *pBase, xf_get_param_msg_t *msg, u32 length)    /* PRQA S 3206 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    /* ...check the message length is correct */
    XF_CHK_ERR(length == XF_GET_PARAM_RSP_LEN(0), -EBADF);

    return 0;
}

/** **************************************************************************
    \brief        TDM Renderer timestamp advance function

    \param[in]      *pBase      Pointer to pComponentPrivate of TDM Renderer component
    \param[in]      *pBufHdr    Input buffer  
 *****************************************************************************/
static void TDM_RENDERER_TimeStamp(XAOMXTDMCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    XAOMX_TDM_RDR   *pData = (XAOMX_TDM_RDR *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */
    u32             length = pBufHdr->nFilledLen;
    u32             n = (length * 8) / (pData->sPCM.nChannels * pData->sPCM.nBitPerSample);

    /* ...add current timestamp to the input buffer */
    pBufHdr->nTimeStamp = pBase->nTimeStamp;

    /* ...advance timestamp for the next buffer (very basic and inaccurate way) */
    pBase->nTimeStamp += (n * 1000000) / pData->sPCM.nSamplingRate;
}

/*******************************************************************************
 * Codec-specific OMX IL interface
 ******************************************************************************/

/** **************************************************************************
    \brief        TDM Renderer get parameter

    \param[in]      *pBase                       Pointer to pComponentPrivate of TDM Renderer component
    \param[in]      nIndex                       Index of parameter structure
    \param[in]      pParam                       Pointer to parameter structure want to get
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE TDM_RENDERER_GetParameter(XAOMXTDMCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMX_TDM_RDR    *pData = (XAOMX_TDM_RDR *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */

    switch(nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...gets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sPCM, sizeof(*param));        /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        break;
    }
    case XAOMX_IndexParamAudioTDMRenderer:         /* PRQA S 1460 *//* Confirm extension enum value is correct. Oct 14, 2016 */
    {
        /* ...gets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        XAOMX_AUDIO_PARAM_TDM_RENDERER    *param = (XAOMX_AUDIO_PARAM_TDM_RENDERER *) pParam;

        memcpy(param, &pData->sTDM_RENDERER, sizeof(*param));   /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        break;
    }
    case OMX_IndexParamCompBufferSupplier:
    {
        /* ...gets OMX_PARAM_BUFFERSUPPLIERTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_BUFFERSUPPLIERTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort == 0, OMX_ErrorBadPortIndex);

        memcpy(pParam, &pData->base.sSupplier[nPort], sizeof(OMX_PARAM_BUFFERSUPPLIERTYPE));    /* PRQA S 3200 *//* Confirm return vlaue is no use. Oct 14, 2016 */

        break;
    }
    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        TDM Renderer Set parameter

    \param[in]      *pBase                       Pointer to pComponentPrivate of TDM Renderer component
    \param[in]      nIndex                       Index of parameter structure
    \param[in]      pParam                       Pointer to parameter structure want to set
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE TDM_RENDERER_SetParameter(XAOMXTDMCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMX_TDM_RDR    *pData = (XAOMX_TDM_RDR *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */

    switch(nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...sets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(&pData->sPCM, param, sizeof(*param));        /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        TRACE(INIT, _b("PCM parameters set"));
        TRACE(INIT, _b("Number of channels: %lu"), pData->sPCM.nChannels);
        TRACE(INIT, _b("Sampling rate:      %lu"), pData->sPCM.nSamplingRate);
        TRACE(INIT, _b("Sample width:       %lu"), pData->sPCM.nBitPerSample);

        break;
    }
    case XAOMX_IndexParamAudioTDMRenderer:                     /* PRQA S 1460 *//* Confirm extension enum value is correct. Oct 14, 2016 */
    {
        /* ...sets XAOMX_AUDIO_PARAM_TDM_RENDERER structure */
        XAOMX_AUDIO_PARAM_TDM_RENDERER    *param = (XAOMX_AUDIO_PARAM_TDM_RENDERER *) pParam;

        memcpy(&pData->sTDM_RENDERER, param, sizeof(*param));   /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        break;
    }
    case OMX_IndexParamCompBufferSupplier:
    {
        /* ...gets OMX_PARAM_BUFFERSUPPLIERTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_BUFFERSUPPLIERTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort == 0, OMX_ErrorBadPortIndex);

        memcpy(&pData->base.sSupplier[nPort], pParam, sizeof(OMX_PARAM_BUFFERSUPPLIERTYPE));    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        TRACE(INIT, _b("Buffer supplier [%d]: %d"), nPort, pData->base.sSupplier[nPort].eBufferSupplier);

        break;
    }
    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        TDM RENDERER_ComponentDeInit

    \param[in]      hComponent                   Pointer to TDM Renderer component handle
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
static OMX_ERRORTYPE TDM_RENDERER_ComponentDeInit(OMX_HANDLETYPE hComponent)
{
    OMX_COMPONENTTYPE   *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMX_TDM_RDR       *pData = (XAOMX_TDM_RDR *) pComp->pComponentPrivate;

    /* ...destroy base component */
    XAOMX_CHK_API(XAOMXTDM_ComponentDeInit(hComponent));

    /* ...destroy private data */
    free(pData);        /* PRQA S 5118 *//* Confirm free memory usage is correct. Oct 14, 2016 */

    /* ...destroy component data itself (component ceases to exist) */
    free(pComp);        /* PRQA S 5118 *//* Confirm free memory usage is correct. Oct 14, 2016 */

    TRACE(INIT, _b("TDM RENDERER component destroyed"));

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        TDM RENDERER_ComponentInit

    \param[in]      *proxy                       OpenMAX interface proxy
    \param[in]      hComponent                   Pointer to TDM Renderer component handle
    \param[in]      pAppData                     Pointer to pAppData of TDM Renderer component
    \param[in]      *pCallbacks                  Pointer to Callbacks of TDM Renderer component
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
static OMX_ERRORTYPE TDM_RENDERER_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE   *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMX_TDM_RDR       *pData = (XAOMX_TDM_RDR *)pComp->pComponentPrivate;
    s32                 i;

    /* ...initialize base codec interface */
    XAOMX_CHK_API(XAOMXTDM_ComponentInit(proxy, hComponent, pAppData, pCallbacks, "audio_tdm_renderer.pcm", "tdm-renderer"));

    /* ...set codec-specific callbacks */
    pData->base.pComponentName = "OMX.RENESAS.AUDIO.DSP.TDMRENDERER";
    pData->base.SetParameter = &TDM_RENDERER_SetParameter;      /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.GetParameter = &TDM_RENDERER_GetParameter;      /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecSetup = &TDM_RENDERER_Setup;               /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecRuntimeInit = &TDM_RENDERER_RuntimeInit;   /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecGetParam = &TDM_RENDERER_GetParam;         /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecTimeStamp = &TDM_RENDERER_TimeStamp;       /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */

    /* ...override component interface */
    pComp->ComponentDeInit = &TDM_RENDERER_ComponentDeInit;

    for (i = 0; i < XAOMX_PORT_MAX; i++)
    {
        /* ...initialize the audio parameters for input port */
        pData->base.sPortDef[i].nBufferCountActual = NUM_INPUT_BUFFERS;
        pData->base.sPortDef[i].nBufferCountMin = NUM_INPUT_BUFFERS;
        pData->base.sPortDef[i].nBufferSize = INPUT_BUFFER_LENGTH;
        pData->base.sPortDef[i].nBufferAlignment = BUFFER_ALIGNMENT;
        pData->base.sPortDef[i].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
        pData->base.sPortDef[i].format.audio.cMIMEType = (OMX_STRING) "raw";
        pData->base.sPortDef[i].format.audio.pNativeRender = NULL;
        pData->base.sPortDef[i].format.audio.bFlagErrorConcealment = OMX_FALSE;

        pData->base.sPortDef[i].nPortIndex = i;
        pData->base.sPortDef[i].eDir = OMX_DirInput;

        /* ...initialize the compression format for input port */
        pData->base.sPortFormat[i].nIndex = OMX_IndexParamAudioPcm;
        pData->base.sPortFormat[i].eEncoding = OMX_AUDIO_CodingPCM;
    }

    /* ...need a fake output buffer port to follow other OMX - tbd need to consider remove it */
    pData->base.sPortDef[XAOMX_PORT_MAX].nBufferCountActual = 1;
    pData->base.sPortDef[XAOMX_PORT_MAX].nBufferCountMin = 1;
    pData->base.sPortDef[XAOMX_PORT_MAX].nBufferSize = 1;
    pData->base.sPortDef[XAOMX_PORT_MAX].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[XAOMX_PORT_MAX].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[XAOMX_PORT_MAX].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[XAOMX_PORT_MAX].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[XAOMX_PORT_MAX].format.audio.bFlagErrorConcealment = OMX_FALSE;

    pData->base.sPortDef[XAOMX_PORT_MAX].nPortIndex = XAOMX_PORT_MAX;
    pData->base.sPortDef[XAOMX_PORT_MAX].eDir = OMX_DirOutput;

    /* ...initialize the compression format for output port */
    pData->base.sPortFormat[XAOMX_PORT_MAX].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[XAOMX_PORT_MAX].eEncoding = OMX_AUDIO_CodingPCM;

    XAOMX_INIT_STRUCT(&pData->sTDM_RENDERER, XAOMX_AUDIO_PARAM_TDM_RENDERER);

    /* ...PCM format defaults */
    XAOMX_INIT_STRUCT(&pData->sPCM, OMX_AUDIO_PARAM_PCMMODETYPE);
    pData->sPCM.nPortIndex = 0;
    pData->sPCM.nChannels = 2;
    pData->sPCM.nSamplingRate = 44100;
    pData->sPCM.nBitPerSample = 16;
    pData->sPCM.eNumData = OMX_NumericalDataSigned;
    pData->sPCM.eEndian = OMX_EndianLittle;
    pData->sPCM.bInterleaved = OMX_TRUE;
    pData->sPCM.ePCMMode = OMX_AUDIO_PCMModeLinear;
    pData->sPCM.eChannelMapping[0] = OMX_AUDIO_ChannelLF;
    pData->sPCM.eChannelMapping[1] = OMX_AUDIO_ChannelRF;

    /* ...TDM Renderer format defaults */
    pData->sTDM_RENDERER.nPCM_frame_size = 1024;
    pData->sTDM_RENDERER.nPCM_channel_mode = 0;
    pData->sTDM_RENDERER.nPCM_in_sample_rate = 44100;
    pData->sTDM_RENDERER.nPCM_out_sample_rate = 0;
    pData->sTDM_RENDERER.nPCM_output1 = SSI00;
    pData->sTDM_RENDERER.nPCM_dma_channel1 = ADMACPP_CH00;
    pData->sTDM_RENDERER.nPCM_output2 = NONCONFIG;
    pData->sTDM_RENDERER.nPCM_dma_channel2 = ADMACPP_CH01;
    pData->sTDM_RENDERER.nPCM_volume_rate = 0xFFFFFFFF;

    TRACE(INIT, _b("RENDERER instantiated"));

    return OMX_ErrorNone;
}

/*******************************************************************************
 * Entry points
 ******************************************************************************/

/** **************************************************************************
    \brief     TDM RENDERER_ComponentCreate

    \param[in]      *proxy                       OpenMAX interface proxy
    \param[in]      *hComponent                  Pointer to TDM Renderer component handle
    \param[in]      pAppData                     Pointer to pAppData of TDM Renderer component
    \param[in]      *pCallbacks                  Pointer to Callbacks of TDM Renderer component
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
OMX_ERRORTYPE TDM_RENDERER_ComponentCreate(xf_proxy_t *proxy, OMX_HANDLETYPE *hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)   /* PRQA S 1503, 3408 *//* Confirm function definition and usage is correct. Oct 14, 2016 */
{
    OMX_COMPONENTTYPE   *pComp;
    XAOMX_TDM_RDR       *pData;
    OMX_ERRORTYPE       eError = OMX_ErrorInsufficientResources;

    /* ...create the base component */
    pComp = calloc(1, sizeof(*pComp));      /* PRQA S 5118 *//* Confirm memory allocation is correct. Oct 14, 2016 */
    if (pComp == NULL) {
        goto error;     /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    /* ...set component version */
    XAOMX_INIT_STRUCT(pComp, OMX_COMPONENTTYPE);

    /* ...allocate private memory */
    pData = calloc(1, sizeof(*pData));      /* PRQA S 5118 *//* Confirm memory allocation is correct. Oct 14, 2016 */
    if (pData == NULL) {
        goto error1;    /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    /* ...set private data handle */
    pComp->pComponentPrivate = (OMX_PTR) pData;

    /* ...initialize component */
    eError = TDM_RENDERER_ComponentInit(proxy, (OMX_HANDLETYPE)pComp, pAppData, pCallbacks);
    if (eError != OMX_ErrorNone) {
        goto error1;    /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    TRACE(INIT, _b("TDM RENDERER initialized"));

    /* ...return component handle */
    *hComponent = (OMX_HANDLETYPE)pComp;

    return OMX_ErrorNone;

error1:
    /* ...destroy component handle data */
    free(pComp);        /* PRQA S 5118 *//* Confirm free memomry is used correctly. Oct 14, 2016 */

error:
    TRACE(INIT, _b("TDM RENDERER component creation failed: %X"), eError);

    return eError;
}
