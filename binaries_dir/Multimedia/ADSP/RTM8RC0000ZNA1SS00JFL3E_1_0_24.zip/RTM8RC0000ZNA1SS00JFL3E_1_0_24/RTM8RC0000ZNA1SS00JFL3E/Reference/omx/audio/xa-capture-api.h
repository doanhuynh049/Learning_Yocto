/** *****************************************************************************
  \file       xa-capture-api.h
  \brief      Header file of Capture component
  \addtogroup ADSP Framework
 ********************************************************************************
  \date       Mar. 02, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information
   of Renesas Electronics Corporation. They must be used and modified solely for
   the purpose for which it was furnished by Renesas Electronics Corporation.
   All part of them must not be reproduced nor disclosed to others in any form,
   without the prior written permission of Renesas Electronics Corporation.
 ********************************************************************************/

/*******************************************************************************
 * xa-capture-api.h
 *
 * Capture component API
 ******************************************************************************/

#ifndef __XA_CAPTURE_API_H__
#define __XA_CAPTURE_API_H__

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xa_type_def.h"
#include "xa_error_standards.h"
#include "xa_apicmd_standards.h"
#include "xa_memory_standards.h"

/*******************************************************************************
 * Constants definitions
 ******************************************************************************/

/* ...Capture-specific configuration parameters */
enum xa_config_param_capture {
    XA_CAP_CONFIG_PARAM_CB               = 0,
    XA_CAP_CONFIG_PARAM_STATE            = 1,
    XA_CAP_CONFIG_PARAM_PCM_WIDTH        = 2,
    XA_CAP_CONFIG_PARAM_CHANNELS         = 3,
    XA_CAP_CONFIG_PARAM_SAMPLE_RATE      = 4,
    XA_CAP_CONFIG_PARAM_FRAME_SIZE       = 5,
    XA_CAP_CONFIG_PARAM_INPUT1           = 6,
    XA_CAP_CONFIG_PARAM_DMACHANNEL1      = 7,
    XA_CAP_CONFIG_PARAM_INPUT2           = 8,
    XA_CAP_CONFIG_PARAM_DMACHANNEL2      = 9,
    XA_CAP_CONFIG_PARAM_OUT_SAMPLE_RATE  = 10,
    XA_CAP_CONFIG_PARAM_VOLUME_RATE      = 11,
    XA_CAP_CONFIG_PARAM_NUM              = 12
};

/* ...CAPTURE states  */
enum xa_capture_state {
    XA_CAP_STATE_IDLE  = 0,
    XA_CAP_STATE_RUN   = 1,
    XA_CAP_STATE_PAUSE = 2
};

/* ...component identifier (informative) */
#define XA_CODEC_CAPTURE               3

/*******************************************************************************
 * Class 0: API Errors
 ******************************************************************************/

#define XA_CAPTURE_API_NONFATAL(e)     \
    XA_ERROR_CODE(xa_severity_nonfatal, xa_class_api, XA_CODEC_CAPTURE, (e))

#define XA_CAPTURE_API_FATAL(e)        \
    XA_ERROR_CODE(xa_severity_fatal, xa_class_api, XA_CODEC_CAPTURE, (e))

enum xa_error_nonfatal_api_capture {
    XA_CAP_API_NONFATAL_MAX = XA_CAPTURE_API_NONFATAL(0)
};

enum xa_error_fatal_api_capture {
    XA_CAP_API_FATAL_MAX = XA_CAPTURE_API_FATAL(0)
};

/*******************************************************************************
 * Class 1: Configuration Errors
 ******************************************************************************/

#define XA_CAP_CONFIG_NONFATAL(e)  \
    XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_CAPTURE, (e))

#define XA_CAP_CONFIG_FATAL(e)     \
    XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_CAPTURE, (e))

enum xa_error_nonfatal_config_capture {
	XA_CAP_CONFIG_NONFATAL_ERR_PCM_WIDTH		= XA_CAP_CONFIG_NONFATAL(0),
	XA_CAP_CONFIG_NONFATAL_ERR_CHANNELS			= XA_CAP_CONFIG_NONFATAL(1),
	XA_CAP_CONFIG_NONFATAL_ERR_SAMPLE_RATE		= XA_CAP_CONFIG_NONFATAL(2),
	XA_CAP_CONFIG_NONFATAL_ERR_FRAME_SIZE		= XA_CAP_CONFIG_NONFATAL(3),
	XA_CAP_CONFIG_NONFATAL_ERR_SOURCE			= XA_CAP_CONFIG_NONFATAL(4),
	XA_CAP_CONFIG_NONFATAL_ERR_DMACHANNEL		= XA_CAP_CONFIG_NONFATAL(5),
	XA_CAP_CONFIG_NONFATAL_MAX					= XA_CAP_CONFIG_NONFATAL(6)
};

enum xa_error_fatal_config_capture {
    XA_CAP_CONFIG_FATAL_STATE					= XA_CAP_CONFIG_FATAL(0),
    XA_CAP_CONFIG_FATAL_HW						= XA_CAP_CONFIG_FATAL(1),
    XA_CAP_CONFIG_FATAL_ERR_MONO_24BIT			= XA_CAP_CONFIG_FATAL(2),
    XA_CAP_CONFIG_FATAL_MAX						= XA_CAP_CONFIG_FATAL(3)
};

/*******************************************************************************
 * Class 2: Execution Class Errors
 ******************************************************************************/

#define XA_CAP_EXEC_NONFATAL(e)    \
    XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_CAPTURE, (e))

#define XA_CAP_EXEC_FATAL(e)       \
    XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_CAPTURE, (e))

enum xa_error_nonfatal_execute_capture {
	XA_CAP_EXEC_NONFATAL_OUTPUT					= XA_CAP_EXEC_NONFATAL(0),
    XA_CAP_EXEC_NONFATAL_MAX    				= XA_CAP_EXEC_NONFATAL(1)
};

enum xa_error_fatal_execute_capture {
    XA_CAP_EXEC_FATAL_STATE						= XA_CAP_EXEC_FATAL(0),
    XA_CAP_EXEC_FATAL_HW						= XA_CAP_EXEC_FATAL(1),
    XA_CAP_EXEC_FATAL_MAX						= XA_CAP_EXEC_FATAL(2)
};

/*******************************************************************************
 * API entry point
 ******************************************************************************/
XA_ERRORCODE xa_rel_capture(xa_codec_handle_t p_xa_module_obj, WORD32 i_cmd, WORD32 i_idx, pVOID pv_value);

/*******************************************************************************
 * API function definition (tbd)
 ******************************************************************************/

#if defined(USE_DLL) && defined(_WIN32)
#define DLL_SHARED __declspec(dllimport)
#elif defined (_WINDLL)
#define DLL_SHARED __declspec(dllexport)
#else
#define DLL_SHARED
#endif

#if defined(__cplusplus)
extern "C" {
#endif  /* __cplusplus */
DLL_SHARED xa_codec_func_t xa_rel_cap;
#if defined(__cplusplus)
}
#endif  /* __cplusplus */

#endif /* __XA_CAPTURE_API_H__ */
