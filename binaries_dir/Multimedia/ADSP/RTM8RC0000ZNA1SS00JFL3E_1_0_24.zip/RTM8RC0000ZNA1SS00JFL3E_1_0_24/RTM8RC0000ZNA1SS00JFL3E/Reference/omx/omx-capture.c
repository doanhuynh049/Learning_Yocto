/** *****************************************************************************
  \file       omx-capture.c
  \brief      ADSP Capture Interface
  \addtogroup ADSP Interface
 ********************************************************************************
  \date       Mar. 02, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information
   of Renesas Electronics Corporation. They must be used and modified solely for
   the purpose for which it was furnished by Renesas Electronics Corporation.
   All part of them must not be reproduced nor disclosed to others in any form,
   without the prior written permission of Renesas Electronics Corporation.
 ********************************************************************************/

/*******************************************************************************
 * omx-capture.c
 *
 * OMX IL component for ADSP capture
 ******************************************************************************/

#define MODULE_TAG                      CAPTURE_INTERFACE

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xf-ap.h"
#include "omx-codec-base.h"
#include "audio/xa-capture-api.h"
#include "xa-omx-renderer.h"

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(INIT, 1);

/*******************************************************************************
 * Local typedefs
 ******************************************************************************/

/** \struct XAOMXCapture
    \brief  Capture Structure
 */
typedef struct _XAOMXCapture
{
    /** ...generic codec structure */
    XAOMXCodecBase                  base;
   
    /** ...PCM-specific parameters (output port) */
    OMX_AUDIO_PARAM_PCMMODETYPE     sPCM;

    /** ...Capture parameters */
    XAOMX_AUDIO_PARAM_CAPTURE       sCAPTURE;

} XAOMXCapture;

/*******************************************************************************
 * Local constants definitions
 ******************************************************************************/

/** \def NUM_OUTPUT_BUFFERS
    ...total amount of output buffers
 */
#define NUM_OUTPUT_BUFFERS              4

/** \def OUTPUT_BUFFER_LENGTH
    ...default output buffer length
 */
#define OUTPUT_BUFFER_LENGTH            4096

/** \def BUFFER_ALIGNMENT
    ...required data alignment
 */
#define BUFFER_ALIGNMENT                32

/*******************************************************************************
 * Function declarations
 ******************************************************************************/
static s32 CAPTURE_Setup(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg);
static s32 CAPTURE_RuntimeInit(XAOMXCodecBase *pBase, xf_start_msg_t *msg);
static s32 CAPTURE_GetParam(XAOMXCodecBase *pBase, xf_get_param_msg_t *msg, u32 length);
static void CAPTURE_TimeStamp(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr);
static OMX_ERRORTYPE CAPTURE_GetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE CAPTURE_SetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE CAPTURE_ComponentDeInit(OMX_HANDLETYPE hComponent);
static OMX_ERRORTYPE CAPTURE_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks);
static s32 CAPTURE_SetConfig_Send(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg, OMX_PTR pParam);
static OMX_ERRORTYPE CAPTURE_SetConfigIndex(OMX_INDEXTYPE nIndex);

/** **************************************************************************
    \brief        CAPTURE_SetConfig_Send
     Prepare message contain wanted to set parameters for XF_SET_PARAM command to send to plug-in

    \param[in]      *pBase      Pointer to pComponentPrivate of Capture component
    \param[in]      *msg        Message send to Capture plugin
    \retval         length      Number of parameters want to set for Capture plugin
 *****************************************************************************/
static s32 CAPTURE_SetConfig_Send(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg, OMX_PTR pParam)
{
    XAOMXCapture    *pData = (XAOMXCapture *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */
    XAOMX_AUDIO_PARAM_CAPTURE *user_param = (XAOMX_AUDIO_PARAM_CAPTURE *) pParam;

    /*Check if we need to set volume to plug-in*/
    if (user_param->nPCM_volume_rate != pData->sCAPTURE.nPCM_volume_rate)
    {
        /* ...save parameter to OMX_coponent */
        pData->sCAPTURE.nPCM_volume_rate = user_param->nPCM_volume_rate;

        /* ...prepare parameters to set */
        msg->item[0].id = XA_CAP_CONFIG_PARAM_VOLUME_RATE;
        msg->item[0].value = pData->sCAPTURE.nPCM_volume_rate;

        TRACE(INIT, _b("CAPTURE set_config"));
        TRACE(INIT, _b("PCM volume rate:      0x%08x"), pData->sCAPTURE.nPCM_volume_rate);

        /* ...return number of parameters we want to set */
        return XF_SET_PARAM_CMD_LEN(1);
    }

    return 0;
}

/** **************************************************************************
    \brief        Capture SetConfigIndex
    Check the index of OMX_SetConfig is correct

    \param[in]      nIndex                       Index of parameter structure
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE CAPTURE_SetConfigIndex(OMX_INDEXTYPE nIndex)
{
    /* ...check index type is supported */
    XF_CHK_ERR(nIndex == (OMX_INDEXTYPE) XAOMX_IndexParamAudioCapture, OMX_ErrorUnsupportedIndex);

    return XA_NO_ERROR;
}

/*******************************************************************************
 * Low-level codec commands (called from component thread context)
 ******************************************************************************/

/** **************************************************************************
    \brief        Capture prepare codec setup parameters 

    \param[in]      *pBase      Pointer to pComponentPrivate of Capture component 
    \param[in]      *msg        Message send to Capture plugin
    \retval         length      Number of parameters want to set for capture plugin
 *****************************************************************************/
static s32 CAPTURE_Setup(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg)
{
    XAOMXCapture    *pData = (XAOMXCapture *) pBase;    /* PRQA S 0310 *//* We confirmed pointer casting is correct. Oct 14, 2016 */

    TRACE(INIT, _b("CAPTURE stream set parameters"));
    TRACE(INIT, _b("PCM width:          %lu"), pData->sPCM.nBitPerSample);
    TRACE(INIT, _b("Number of channels: %lu"), pData->sPCM.nChannels);
    TRACE(INIT, _b("Sampling rate:      %lu"), pData->sPCM.nSamplingRate);
    TRACE(INIT, _b("PCM frame size:     %lu"), pData->sCAPTURE.nPCM_frame_size);
    TRACE(INIT, _b("PCM input source 1:   %lu"), pData->sCAPTURE.nPCM_input1);
    TRACE(INIT, _b("PCM DMA channel 1:    %lu"), pData->sCAPTURE.nPCM_DMAchannel1);
    TRACE(INIT, _b("PCM input source 2:   %lu"), pData->sCAPTURE.nPCM_input2);
    TRACE(INIT, _b("PCM DMA channel 2:    %lu"), pData->sCAPTURE.nPCM_DMAchannel2);
    TRACE(INIT, _b("PCM out sample rate:  %lu"), pData->sCAPTURE.nPCM_out_sample_rate);
    TRACE(INIT, _b("PCM volume rate:      0x%08x"), pData->sCAPTURE.nPCM_volume_rate);

    /* ...prepare parameters to set */
    msg->item[0].id = XA_CAP_CONFIG_PARAM_PCM_WIDTH;
    msg->item[0].value = pData->sPCM.nBitPerSample;

    msg->item[1].id = XA_CAP_CONFIG_PARAM_CHANNELS;
    msg->item[1].value = pData->sPCM.nChannels;
    
    msg->item[2].id = XA_CAP_CONFIG_PARAM_SAMPLE_RATE;
    msg->item[2].value = pData->sCAPTURE.nPCM_in_sample_rate;

    msg->item[3].id = XA_CAP_CONFIG_PARAM_FRAME_SIZE;
    msg->item[3].value = pData->sCAPTURE.nPCM_frame_size;

    msg->item[4].id = XA_CAP_CONFIG_PARAM_INPUT1;
    msg->item[4].value = pData->sCAPTURE.nPCM_input1;

    msg->item[5].id = XA_CAP_CONFIG_PARAM_DMACHANNEL1;
    msg->item[5].value = pData->sCAPTURE.nPCM_DMAchannel1;

    msg->item[6].id = XA_CAP_CONFIG_PARAM_INPUT2;
    msg->item[6].value = pData->sCAPTURE.nPCM_input2;

    msg->item[7].id = XA_CAP_CONFIG_PARAM_DMACHANNEL2;
    msg->item[7].value = pData->sCAPTURE.nPCM_DMAchannel2;

    msg->item[8].id = XA_CAP_CONFIG_PARAM_OUT_SAMPLE_RATE;
    msg->item[8].value = pData->sCAPTURE.nPCM_out_sample_rate;

    msg->item[9].id = XA_CAP_CONFIG_PARAM_VOLUME_RATE;
    msg->item[9].value = pData->sCAPTURE.nPCM_volume_rate;

    /* ...return number of parameters we want to set */
    return XF_SET_PARAM_CMD_LEN(10);
}

/** **************************************************************************
    \brief        Capture runtime initialization hook

    \param[in]      *pBase      Pointer to pComponentPrivate of Capture component
    \param[in]      *msg        Message send to Capture plugin
    \retval         length      Number of parameters want to get from capture plugin
 *****************************************************************************/
static s32 CAPTURE_RuntimeInit(XAOMXCodecBase *pBase, xf_start_msg_t *msg)  /* PRQA S 3206 *//* Confirm function definition is correct. Oct 14, 2016 */
{
    xf_get_param_msg_t *get = (xf_get_param_msg_t *)msg;    /* PRQA S 0310 *//* Confirmed pointer casting is correct. Oct 14, 2016 */

    TRACE(INIT, _b("CAPTURE Runtime initial"));

    /* ...update parameters requiring port reconfiguration */
    get->c.id[0] = XA_CAP_CONFIG_PARAM_DMACHANNEL1;
    get->c.id[1] = XA_CAP_CONFIG_PARAM_DMACHANNEL2;

    /* ...return number of parameters we are querying */
    return XF_GET_PARAM_CMD_LEN(2);
}

/** **************************************************************************
    \brief        Capture process output stream parameters

    \param[in]      *pBase      Pointer to pComponentPrivate of Capture component
    \param[in]      *msg        Message receive from Capture plugin
    \param[in]      length      Length of message 
    \retval         0           Success
 *****************************************************************************/
static s32 CAPTURE_GetParam(XAOMXCodecBase *pBase, xf_get_param_msg_t *msg, u32 length) /* PRQA S 3673, 3206 *//* Confirm function definition and usage is correct. Oct 14, 2016 */
{
    XAOMXCapture    *pData = (XAOMXCapture *) pBase;    /* PRQA S 0310 *//* Confirmed pointer casting is correct. Oct 14, 2016 */

    /* ...check the message length is correct */
    XF_CHK_ERR(length == XF_GET_PARAM_RSP_LEN(2), -EBADF);

    /* ...set ADMA-pp channel usage */
    pData->sCAPTURE.nPCM_DMAchannel1 = msg->r.value[0];
    pData->sCAPTURE.nPCM_DMAchannel2 = msg->r.value[1];

    TRACE(INIT, _b("CAPTURE parameters"));
    TRACE(INIT, _b("ADMA channel 1:     %u"), pData->sCAPTURE.nPCM_DMAchannel1);
    TRACE(INIT, _b("ADMA channel 2:     %u"), pData->sCAPTURE.nPCM_DMAchannel2);

    return 0;
}

/** **************************************************************************
    \brief        Capture timestamp advance function

    \param[in]      *pBase      Pointer to pComponentPrivate of Capture component
    \param[in]      *pBufHdr    Output buffer  
 *****************************************************************************/
static void CAPTURE_TimeStamp(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    XAOMXCapture    *pData = (XAOMXCapture *) pBase;        /* PRQA S 0310 *//* Confirmed pointer casting is correct. Oct 14, 2016 */
    u32                 length = pBufHdr->nFilledLen;
    u32                 n = (length * 8) / (pData->sPCM.nChannels * pData->sPCM.nBitPerSample);

    /* ...add current timestamp to the output buffer */
    pBufHdr->nTimeStamp = pBase->nTimeStamp;

    /* ...advance timestamp for the next buffer (very basic and inaccurate way) */
    pBase->nTimeStamp += (n * 1000000) / pData->sPCM.nSamplingRate;
}

/*******************************************************************************
 * Codec-specific OMX IL interface
 ******************************************************************************/

/** **************************************************************************
    \brief        Capture get parameter

    \param[in]      *pBase                       Pointer to pComponentPrivate of Capture component
    \param[in]      nIndex                       Index of parameter structure
    \param[in]      pParam                       Pointer to parameter structure want to get
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE CAPTURE_GetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXCapture    *pData = (XAOMXCapture *) pBase;        /* PRQA S 0310 *//* Confirmed pointer casting is correct. Oct 14, 2016 */

    switch(nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...gets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sPCM, sizeof(*param));        /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        break;
    }
    case XAOMX_IndexParamAudioCapture:      /* PRQA S 1460 *//* Confirmed extension enum value is correct. Oct 14, 2016 */
    {
        /* ...gets XAOMX_AUDIO_PARAM_CAPTURE structure */
        XAOMX_AUDIO_PARAM_CAPTURE    *param = (XAOMX_AUDIO_PARAM_CAPTURE *) pParam;

        memcpy(param, &pData->sCAPTURE, sizeof(*param));    /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        break;
    }
    case OMX_IndexParamCompBufferSupplier:
    {
        /* ...gets OMX_PARAM_BUFFERSUPPLIERTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_BUFFERSUPPLIERTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort == 1, OMX_ErrorBadPortIndex);

        memcpy(pParam, &pData->base.sSupplier[nPort], sizeof(OMX_PARAM_BUFFERSUPPLIERTYPE));    /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        break;
    }
    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        Capture Set parameter

    \param[in]      *pBase                       Pointer to pComponentPrivate of Capture component
    \param[in]      nIndex                       Index of parameter structure
    \param[in]      pParam                       Pointer to parameter structure want to set
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE CAPTURE_SetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXCapture    *pData = (XAOMXCapture *) pBase;    /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */

    switch(nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...sets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(&pData->sPCM, param, sizeof(*param));    /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        TRACE(INIT, _b("PCM parameters set"));
        TRACE(INIT, _b("Number of channels: %lu"), pData->sPCM.nChannels);
        TRACE(INIT, _b("Sampling rate:      %lu"), pData->sPCM.nSamplingRate);
        TRACE(INIT, _b("Sample width:       %lu"), pData->sPCM.nBitPerSample);

        break;
    }
    case XAOMX_IndexParamAudioCapture:      /* PRQA S 1460 *//* Confirm extension enum value is correct. Oct 14, 2016 */
    {
        /* ...sets XAOMX_AUDIO_PARAM_CAPTURE structure */
        XAOMX_AUDIO_PARAM_CAPTURE    *param = (XAOMX_AUDIO_PARAM_CAPTURE *) pParam;

        memcpy(&pData->sCAPTURE, param, sizeof(*param));    /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        TRACE(INIT, _b("CAPTURE parameters set"));
        TRACE(INIT, _b("Frame size:         %lu"), pData->sCAPTURE.nPCM_frame_size);
        TRACE(INIT, _b("PCM input source 1:   %lu"), pData->sCAPTURE.nPCM_input1);
        TRACE(INIT, _b("PCM DMA channel 1:    %lu"), pData->sCAPTURE.nPCM_DMAchannel1);
        TRACE(INIT, _b("PCM input source 2:   %lu"), pData->sCAPTURE.nPCM_input2);
        TRACE(INIT, _b("PCM DMA channel 2:    %lu"), pData->sCAPTURE.nPCM_DMAchannel2);
        TRACE(INIT, _b("PCM out sample rate:  %lu"), pData->sCAPTURE.nPCM_out_sample_rate);
        TRACE(INIT, _b("PCM volume rate:      0x%08x"), pData->sCAPTURE.nPCM_volume_rate);

        break;
    }
    case OMX_IndexParamCompBufferSupplier:
    {
        /* ...gets OMX_PARAM_BUFFERSUPPLIERTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_BUFFERSUPPLIERTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort == 1, OMX_ErrorBadPortIndex);

        memcpy(&pData->base.sSupplier[nPort], pParam, sizeof(OMX_PARAM_BUFFERSUPPLIERTYPE));    /* PRQA S 3200 *//* Confirm returned value from memcpy is not needed. Oct 14, 2016 */

        TRACE(INIT, _b("Buffer supplier [%d]: %d"), nPort, pData->base.sSupplier[nPort].eBufferSupplier);

        break;
    }
    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        CAPTURE_ComponentDeInit 

    \param[in]      hComponent                   Pointer to Capture component handle
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
static OMX_ERRORTYPE CAPTURE_ComponentDeInit(OMX_HANDLETYPE hComponent)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXCapture    *pData = (XAOMXCapture *) pComp->pComponentPrivate;

    /* ...destroy base component */
    XAOMX_CHK_API(XAOMX_ComponentDeInit(hComponent));

    /* ...destroy private data */
    free(pData);        /* PRQA S 5118 *//* Confirm free usage is follow original framework. Oct 14, 2016 */

    /* ...destroy component data itself (component ceases to exist) */
    free(pComp);        /* PRQA S 5118 *//* Confirm free usage is follow original framework. Oct 14, 2016 */

    TRACE(INIT, _b("CAPTURE component destroyed"));

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        CAPTURE_ComponentInit 

    \param[in]      *proxy                       OpenMAX interface proxy
    \param[in]      hComponent                   Pointer to Capture component handle
    \param[in]      pAppData                     Pointer to pAppData of Capture component 
    \param[in]      *pCallbacks                  Pointer to Callbacks of Capture component 
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
static OMX_ERRORTYPE CAPTURE_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXCapture    *pData = (XAOMXCapture *)pComp->pComponentPrivate;

    /* ...initialize base codec interface */
    XAOMX_CHK_API(XAOMX_ComponentInit(proxy, hComponent, pAppData, pCallbacks, "audio_capture.pcm", "capture"));

    /* ...set codec-specific callbacks */
    pData->base.pComponentName = "OMX.RENESAS.AUDIO.DSP.CAPTURE";
    pData->base.SetParameter = &CAPTURE_SetParameter;       /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.GetParameter = &CAPTURE_GetParameter;       /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecSetup = &CAPTURE_Setup;                /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecRuntimeInit = &CAPTURE_RuntimeInit;    /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecGetParam = &CAPTURE_GetParam;          /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecTimeStamp = &CAPTURE_TimeStamp;        /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.SetConfig_Send = &CAPTURE_SetConfig_Send;                /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.SetConfigIndex = &CAPTURE_SetConfigIndex;                /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */

    /* ...override component interface */
    pComp->ComponentDeInit = &CAPTURE_ComponentDeInit;

    /* ...initialize the audio parameters for fake input port */
    pData->base.sPortDef[0].nBufferCountMin = 1;
    pData->base.sPortDef[0].nBufferCountActual = 1;
    pData->base.sPortDef[0].nBufferSize = 128;
    pData->base.sPortDef[0].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[0].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[0].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[0].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[0].format.audio.bFlagErrorConcealment = OMX_FALSE;

    /* ...initialize the compression format for fake input port */
    pData->base.sPortFormat[0].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[0].eEncoding = OMX_AUDIO_CodingPCM;

    /* ...initialize the audio parameters for output port */
    pData->base.sPortDef[1].nBufferCountMin = NUM_OUTPUT_BUFFERS;
    pData->base.sPortDef[1].nBufferCountActual = NUM_OUTPUT_BUFFERS;
    pData->base.sPortDef[1].nBufferSize = OUTPUT_BUFFER_LENGTH;
    pData->base.sPortDef[1].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[1].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[1].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[1].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[1].format.audio.bFlagErrorConcealment = OMX_FALSE;

    /* ...initialize the compression format for output port */
    pData->base.sPortFormat[1].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[1].eEncoding = OMX_AUDIO_CodingPCM;

    /* ...PCM format defaults */
    XAOMX_INIT_STRUCT(&pData->sPCM, OMX_AUDIO_PARAM_PCMMODETYPE);
    pData->sPCM.nPortIndex = 1;
    pData->sPCM.nChannels = 2;
    pData->sPCM.nSamplingRate = 44100;
    pData->sPCM.nBitPerSample = 16;
    pData->sPCM.eNumData = OMX_NumericalDataSigned;
    pData->sPCM.eEndian = OMX_EndianLittle;
    pData->sPCM.bInterleaved = OMX_TRUE;
    pData->sPCM.ePCMMode = OMX_AUDIO_PCMModeLinear;
    pData->sPCM.eChannelMapping[0] = OMX_AUDIO_ChannelLF;
    pData->sPCM.eChannelMapping[1] = OMX_AUDIO_ChannelRF;

    /* ...CAPTURE format defaults */
    XAOMX_INIT_STRUCT(&pData->sCAPTURE, XAOMX_AUDIO_PARAM_CAPTURE);
    pData->sCAPTURE.nPCM_frame_size = 1024;
    pData->sCAPTURE.nPCM_input1 = SSI10;
    pData->sCAPTURE.nPCM_DMAchannel1 = ADMACPP_CH10;
    pData->sCAPTURE.nPCM_input2 = NONCONFIG;
    pData->sCAPTURE.nPCM_DMAchannel2 = ADMACPP_CH02;
    pData->sCAPTURE.nPCM_in_sample_rate = 44100;
    pData->sCAPTURE.nPCM_out_sample_rate = 44100;
    pData->sCAPTURE.nPCM_volume_rate = 0xFFFFFFFF;

    TRACE(INIT, _b("CAPTURE instantiated"));

    return OMX_ErrorNone;
}

/*******************************************************************************
 * Entry points
 ******************************************************************************/

/** **************************************************************************
    \brief     CAPTURE_ComponentCreate 

    \param[in]      *proxy                       OpenMAX interface proxy
    \param[in]      *hComponent                  Pointer to Capture component handle
    \param[in]      pAppData                     Pointer to pAppData of Capture component 
    \param[in]      *pCallbacks                  Pointer to Callbacks of Capture component 
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
OMX_ERRORTYPE CAPTURE_ComponentCreate(xf_proxy_t *proxy, OMX_HANDLETYPE *hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)    /* PRQA S 1503, 3408 *//* Confirm prototype and usage is correct. Oct 14, 2016 */
{
    OMX_COMPONENTTYPE  *pComp;
    XAOMXCapture    *pData;
    OMX_ERRORTYPE       eError = OMX_ErrorInsufficientResources;

    /* ...create the base component */
    pComp = calloc(1, sizeof(*pComp));      /* PRQA S 5118 *//* Confirm memory allocation is correct. Oct 14, 2016 */
    if (pComp == NULL) {
        goto error;         /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    /* ...set component version */
    XAOMX_INIT_STRUCT(pComp, OMX_COMPONENTTYPE);

    /* ...allocate private memory */
    pData = calloc(1, sizeof(*pData));      /* PRQA S 5118 *//* Confirm memory allocation is correct. Oct 14, 2016 */
    if (pData == NULL) {
        goto error1;        /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    /* ...set private data handle */
    pComp->pComponentPrivate = (OMX_PTR) pData;

    /* ...initialize component */
    eError = CAPTURE_ComponentInit(proxy, (OMX_HANDLETYPE)pComp, pAppData, pCallbacks);
    if (eError != OMX_ErrorNone) {
        goto error1;        /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    TRACE(INIT, _b("CAPTURE initialized"));

    /* ...return component handle */
    *hComponent = (OMX_HANDLETYPE)pComp;

    return OMX_ErrorNone;

error1:
    /* ...destroy component handle data */
    free(pComp);    /* PRQA S 5118 *//* Confirm memory free is correct. Oct 14, 2016 */

error:
    TRACE(INIT, _b("CAPTURE component creation failed: %X"), eError);

    return eError;
}
