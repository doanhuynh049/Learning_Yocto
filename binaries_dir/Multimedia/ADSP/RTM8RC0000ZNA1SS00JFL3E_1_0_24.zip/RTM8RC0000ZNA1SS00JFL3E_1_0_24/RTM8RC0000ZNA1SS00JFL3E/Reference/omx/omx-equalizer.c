/** *****************************************************************************
  \file       omx-equalizer.c
  \brief      Source code of ADSP Equalizer Interface
  \addtogroup ADSP Interface
 ********************************************************************************
  \date       Mar. 02, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information

   of Renesas Electronics Corporation. They must be used and modified solely for

   the purpose for which it was furnished by Renesas Electronics Corporation.

   All part of them must not be reproduced nor disclosed to others in any form,

   without the prior written permission of Renesas Electronics Corporation.

 ********************************************************************************/

/*******************************************************************************
 * omx-equalizer.c
 *
 * OMX IL component for ADSP Equalizer
 ******************************************************************************/

#define MODULE_TAG                      XA_EQU

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xf-ap.h"
#include "omx-codec-base.h"
#include "xa-omx-equalizer.h"
#include "audio/xa_rel_eqz.h"

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(INIT, 1);

/*******************************************************************************
 * Local typedefs
 ******************************************************************************/
/** \struct XAOMXEqualizer
    \brief  Equalizer Structure
 */
typedef struct _XAOMXEqualizer {
    /** ...generic codec structure */
    XAOMXCodecBase                  base;
   
    /** ...PCM-specific parameters (input port) */
    OMX_AUDIO_PARAM_PCMMODETYPE     sPCM_in;

    /** ...PCM-specific parameters (output port) */
    OMX_AUDIO_PARAM_PCMMODETYPE     sPCM_out;

    /** ...Equalizer-specific parametrs */
    XAOMX_AUDIO_PARAM_EQUALIZER     sEQU;
} XAOMXEqualizer;
/*******************************************************************************
 * Local constants definitions
 ******************************************************************************/
/** \def NUM_INPUT_BUFFERS
    ...total amount of input buffers
 */
#define NUM_INPUT_BUFFERS               4

/** \def INPUT_BUFFER_LENGTH
    ...default input buffer length
 */
#define INPUT_BUFFER_LENGTH             4096

/** \def NUM_OUTPUT_BUFFERS
    ...total amount of output buffers
 */
#define NUM_OUTPUT_BUFFERS              4

/** \def OUTPUT_BUFFER_LENGTH
    ...default output buffer length
 */
#define OUTPUT_BUFFER_LENGTH            4096

/** \def BUFFER_ALIGNMENT
    ...required data alignment
 */
#define BUFFER_ALIGNMENT                32

/*******************************************************************************
 * Function declarations
 ******************************************************************************/
static s32 EQUALIZER_Setup(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg);
static s32 EQUALIZER_RuntimeInit(XAOMXCodecBase *pBase, xf_start_msg_t *msg);
static s32 EQUALIZER_GetParam(XAOMXCodecBase *pBase, xf_get_param_msg_t *msg, u32 length);
static void EQUALIZER_TimeStamp(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr);
static OMX_ERRORTYPE EQUALIZER_GetParameter(struct XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE EQUALIZER_SetParameter(struct XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE EQUALIZER_ComponentDeInit(OMX_HANDLETYPE hComponent);
static OMX_ERRORTYPE EQUALIZER_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks);

/*******************************************************************************
 * Low-level codec commands (called from component thread context)
 ******************************************************************************/

/** **************************************************************************
    \brief        Equalizer prepare codec setup parameters 

    \param[in]      *pBase      Pointer to pComponentPrivate of Equalizer component 
    \param[in]      *msg        Message send to Equalizer plugin
    \retval         length      Number of parameters want to set for Equalizer plugin
 *****************************************************************************/
static s32 EQUALIZER_Setup(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg)
{
    u32                 i;
    XAOMXEqualizer      *pData = (XAOMXEqualizer *) pBase;  /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */

    TRACE(INIT, _b("EQUALIZER stream set parameters: "));
    TRACE(INIT, _b("Number of channels:     %lu"), pData->sPCM_in.nChannels);
    TRACE(INIT, _b("PCM width:              %lu"), pData->sPCM_in.nBitPerSample);
    TRACE(INIT, _b("Sampling rate:          %lu"), pData->sPCM_in.nSamplingRate);
    
    /* ...prepare parameters to set */
    msg->item[0].id = XA_EQZ_CONFIG_PARAM_COEF_FS;
    msg->item[0].value = (u32)pData->sPCM_out.nSamplingRate;

    msg->item[1].id = XA_EQZ_CONFIG_PARAM_PCM_WIDTH;
    msg->item[1].value = (u32)pData->sPCM_out.nBitPerSample;

    msg->item[2].id = XA_EQZ_CONFIG_PARAM_CH;
    msg->item[2].value = (u32)pData->sPCM_out.nChannels;

    msg->item[3].id = XA_EQZ_CONFIG_PARAM_EQZ_TYPE;
    msg->item[3].value = (u32)pData->sEQU.Eqz_type;

    for (i = 0; i < 9; i++)
    {
        /* ...centre frequencies */
        msg->item[i + 4].id = XA_EQZ_CONFIG_PARAM_FILTER_0_COEF_FC + i;
        msg->item[i + 4].value = (u32)pData->sEQU.stEqCoef.FreqCenter[i];

        /* ...filter type */
        msg->item[i + 13].id = XA_EQZ_CONFIG_PARAM_FILTER_0_COEF_TYPE + i;
        msg->item[i + 13].value = (u32)pData->sEQU.stEqCoef.Type[i];

        /* ...filter bandwidth */
        msg->item[i + 22].id = XA_EQZ_CONFIG_PARAM_FILTER_0_COEF_BW + i;
        msg->item[i + 22].value = (u32)pData->sEQU.stEqCoef.BandWidth[i];

        /* ...filter gain */
        msg->item[i + 31].id = XA_EQZ_CONFIG_PARAM_FILTER_0_COEF_GA + i;
        msg->item[i + 31].value = (u32)pData->sEQU.stEqCoef.Gain[i];

        /* ...filter gain base */
        msg->item[i + 40].id = XA_EQZ_CONFIG_PARAM_FILTER_0_COEF_BA + i;
        msg->item[i + 40].value = (u32)pData->sEQU.stEqCoef.GainBase[i];

        if (i < 5)
        {
            msg->item[i + 49].id = XA_EQZ_CONFIG_PARAM_BAND_0_GCOEF_GA + i;
            msg->item[i + 49].value = (u32)pData->sEQU.stEqGCoef.Gain_g[i];
        }
    }

    /* ...return number of parameters we want to set */
    return XF_SET_PARAM_CMD_LEN(54);
}

/** **************************************************************************
    \brief        Equalizer runtime initialization hook

    \param[in]      *pBase      Pointer to pComponentPrivate of Equalizer component
    \param[in]      *msg        Message send to Equalizer plugin
    \retval         length      Number of parameters want to get from Equalizer plugin
 *****************************************************************************/
static s32 EQUALIZER_RuntimeInit(XAOMXCodecBase *pBase, xf_start_msg_t *msg)    /* PRQA S 3206 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    TRACE(INIT, _b("Equalizer stream prepared: f=%u, c=%u, w=%u, i=%u, o=%u"),
                    msg->sample_rate, msg->channels, msg->pcm_width, msg->input_length, msg->output_length);

    /* ...return number of parameters we are querying */
    return XF_GET_PARAM_CMD_LEN(0);
}

/** **************************************************************************
    \brief        Equalizer process input stream parameters

    \param[in]      *pBase      Pointer to pComponentPrivate of Equalizer component
    \param[in]      *msg        Message receive from Equalizer plugin
    \param[in]      length      Length of message 
    \retval         0           Success
 *****************************************************************************/
static s32 EQUALIZER_GetParam(XAOMXCodecBase *pBase, xf_get_param_msg_t *msg, u32 length)   /* PRQA S 3206 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    /* ...check the message length is correct */
    XF_CHK_ERR(length == XF_GET_PARAM_RSP_LEN(0), -EBADF);

    return 0;
}

/** **************************************************************************
    \brief        Equalizer timestamp advance function

    \param[in]      *pBase      Pointer to pComponentPrivate of Equalizer component
    \param[in]      *pBufHdr    Output buffer  
 *****************************************************************************/
static void EQUALIZER_TimeStamp(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    XAOMXEqualizer      *pData = (XAOMXEqualizer *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */
    u32                 length = pBufHdr->nFilledLen;
    u32                 n = (length * 8) / (pData->sPCM_out.nChannels * pData->sPCM_out.nBitPerSample);

    /* ...add current timestamp to the output buffer */
    pBufHdr->nTimeStamp = pBase->nTimeStamp;

    /* ...advance timestamp for the next buffer (very basic and inaccurate way) */
    pBase->nTimeStamp += (OMX_TICKS)((n * 1000000) / pData->sPCM_out.nSamplingRate);    /* PRQA S 4121 *//* Confirm casting is correct. Oct 14, 2016 */
}

/*******************************************************************************
 * Codec-specific OMX IL interface
 ******************************************************************************/

/** **************************************************************************
    \brief        Equalizer get parameter

    \param[in]      *pBase                       Pointer to pComponentPrivate of Equalizer component
    \param[in]      nIndex                       Index of parameter structure
    \param[in]      pParam                       Pointer to parameter structure want to get
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE EQUALIZER_GetParameter(struct XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXEqualizer      *pData = (XAOMXEqualizer *) pBase;      /* PRQA S 0310 *//* Confirm pointer casting is correct. Oct 14, 2016 */

    switch (nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...gets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex < 2, OMX_ErrorBadPortIndex);

        if (param->nPortIndex == pData->sPCM_in.nPortIndex)
        {
            memcpy(param, &pData->sPCM_in, sizeof(*param));     /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
        }
        else
        {
            memcpy(param, &pData->sPCM_out, sizeof(*param));    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
        }

        break;
    }
    case XAOMX_IndexParamAudioEqualizer:        /* PRQA S 1460 *//* Confirm extension enum is correct. Oct 14, 2016 */
    {
        XAOMX_AUDIO_PARAM_EQUALIZER   *param = (XAOMX_AUDIO_PARAM_EQUALIZER *) pParam;

        memcpy(param, &pData->sEQU, sizeof(*param));            /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        break;
    }
    case OMX_IndexParamCompBufferSupplier:
    {
        /* ...gets OMX_PARAM_BUFFERSUPPLIERTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_BUFFERSUPPLIERTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort < 2, OMX_ErrorBadPortIndex);

        memcpy(pParam, &pData->base.sSupplier[nPort], sizeof(OMX_PARAM_BUFFERSUPPLIERTYPE));    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        break;
    }
    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        Equalizer Set parameter

    \param[in]      *pBase                       Pointer to pComponentPrivate of Equalizer component
    \param[in]      nIndex                       Index of parameter structure
    \param[in]      pParam                       Pointer to parameter structure want to set
    \retval         OMX_ErrorNone                Success
    \retval         OMX_ErrorUnsupportedIndex    Wrong Index of structure
 *****************************************************************************/
static OMX_ERRORTYPE EQUALIZER_SetParameter(struct XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    u32                 i;
    XAOMXEqualizer      *pData = (XAOMXEqualizer *) pBase;      /* PRQA S 0310 *//* Confirm casting pointer is correct. Oct 14, 2016 */

    switch (nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...sets OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex < 2, OMX_ErrorBadPortIndex);

        if (param->nPortIndex == pData->sPCM_in.nPortIndex)
        {
            memcpy(&pData->sPCM_in, param, sizeof(*param));     /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

            TRACE(INIT, _b("PCM parameters set"));
            TRACE(INIT, _b("Number of channels to input port: %lu"), pData->sPCM_in.nChannels);
            TRACE(INIT, _b("Sampling rate to input port:      %lu"), pData->sPCM_in.nSamplingRate);
            TRACE(INIT, _b("Sample width to input port:       %lu"), pData->sPCM_in.nBitPerSample);
        }
        else
        {
            memcpy(&pData->sPCM_out, param, sizeof(*param));    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
            
            TRACE(INIT, _b("PCM parameters set"));
            TRACE(INIT, _b("Number of channels to output port: %lu"), pData->sPCM_out.nChannels);
            TRACE(INIT, _b("Sampling rate to output port:      %lu"), pData->sPCM_out.nSamplingRate);
            TRACE(INIT, _b("Sample width to output port:       %lu"), pData->sPCM_out.nBitPerSample);
        }

        break;
    }
    case XAOMX_IndexParamAudioEqualizer:        /* PRQA S 1460 *//* Confirm extension enum is correct. Oct 14, 2016 */
    {
        XAOMX_AUDIO_PARAM_EQUALIZER   *param = (XAOMX_AUDIO_PARAM_EQUALIZER *) pParam;
        
        memcpy(&pData->sEQU, param, sizeof(*param));            /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        TRACE(INIT, _b("Equalizer parameters set"));
        TRACE(INIT, _b("Equalizer type:         %ld"), pData->sEQU.Eqz_type);

        for (i = 0; i < 9; i++)
        {
            TRACE(INIT, _b("Filter type %d:                 %ld"), i, pData->sEQU.stEqCoef.Type[i]);
            TRACE(INIT, _b("Filter %d's frequency center:   %ld"), i, pData->sEQU.stEqCoef.FreqCenter[i]);
            TRACE(INIT, _b("Filter %d's gain:               %ld"), i, pData->sEQU.stEqCoef.Gain[i]);
            TRACE(INIT, _b("Filter %d's band width:         %ld"), i, pData->sEQU.stEqCoef.BandWidth[i]);
            TRACE(INIT, _b("Filter %d's gain base:          %ld"), i, pData->sEQU.stEqCoef.GainBase[i]);
        }

        for (i = 0; i < 5; i++)
        {
            TRACE(INIT, _b("Graphic gain %d:                %ld"), i, pData->sEQU.stEqGCoef.Gain_g[i]);
        }

        break;
    }
    case OMX_IndexParamCompBufferSupplier:
    {
        /* ...gets OMX_PARAM_BUFFERSUPPLIERTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_BUFFERSUPPLIERTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort < 2, OMX_ErrorBadPortIndex);

        memcpy(&pData->base.sSupplier[nPort], pParam, sizeof(OMX_PARAM_BUFFERSUPPLIERTYPE));    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        TRACE(INIT, _b("Buffer supplier [%d]: %d"), nPort, pData->base.sSupplier[nPort].eBufferSupplier);

        break;
    }
    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        EQUALIZER_ComponentDeInit 

    \param[in]      hComponent                   Pointer to Equalizer component handle
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
static OMX_ERRORTYPE EQUALIZER_ComponentDeInit(OMX_HANDLETYPE hComponent)
{
    OMX_COMPONENTTYPE   *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXEqualizer      *pData = (XAOMXEqualizer *) pComp->pComponentPrivate;

    /* ...destroy base component */
    XAOMX_CHK_API(XAOMX_ComponentDeInit(hComponent));

    /* ...destroy private data */
    free(pData);        /* PRQA S 5118 *//* Confirm free memory is correct. Oct 14, 2016 */

    /* ...destroy component data itself (component ceases to exist) */
    free(pComp);        /* PRQA S 5118 *//* Confirm free memory is correct. Oct 14, 2016 */

    TRACE(INIT, _b("Equalizer interface component destroyed"));

    return OMX_ErrorNone;
}

/** **************************************************************************
    \brief        EQUALIZER_ComponentInit 

    \param[in]      *proxy                       OpenMAX interface proxy
    \param[in]      hComponent                   Pointer to Equalizer component handle
    \param[in]      pAppData                     Pointer to pAppData of Equalizer component 
    \param[in]      *pCallbacks                  Pointer to Callbacks of Equalizer component 
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
static OMX_ERRORTYPE EQUALIZER_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE   *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXEqualizer      *pData = (XAOMXEqualizer *)pComp->pComponentPrivate;
    u32                 i;

    /* ...initialize base codec interface */
    XAOMX_CHK_API(XAOMX_ComponentInit(proxy, hComponent, pAppData, pCallbacks, "audio_processor.pcm.equalizer", "equalizer"));

    /* ...set codec-specific callbacks */
    pData->base.pComponentName = "OMX.RENESAS.AUDIO.DSP.EQUALIZER";
    pData->base.SetParameter = &EQUALIZER_SetParameter;         /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.GetParameter = &EQUALIZER_GetParameter;         /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecSetup = &EQUALIZER_Setup;                  /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecRuntimeInit = &EQUALIZER_RuntimeInit;      /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecGetParam = &EQUALIZER_GetParam;            /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */
    pData->base.CodecTimeStamp = &EQUALIZER_TimeStamp;          /* PRQA S 1334 *//* Confirm function mapping is correct. Oct 14, 2016 */

    /* ...override component interface */
    pComp->ComponentDeInit = &EQUALIZER_ComponentDeInit;

    /* ...initialize the audio parameters for input port */
    pData->base.sPortDef[0].nBufferCountActual = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferCountMin = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferSize = INPUT_BUFFER_LENGTH;
    pData->base.sPortDef[0].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[0].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[0].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[0].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[0].format.audio.bFlagErrorConcealment = OMX_FALSE;

    /* ...initialize the compression format for input port */
    pData->base.sPortFormat[0].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[0].eEncoding = OMX_AUDIO_CodingPCM;

    /* ...initialize the audio parameters for output port */
    pData->base.sPortDef[1].nBufferCountMin = NUM_OUTPUT_BUFFERS;
    pData->base.sPortDef[1].nBufferCountActual = NUM_OUTPUT_BUFFERS;
    pData->base.sPortDef[1].nBufferSize = OUTPUT_BUFFER_LENGTH;
    pData->base.sPortDef[1].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[1].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[1].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[1].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[1].format.audio.bFlagErrorConcealment = OMX_FALSE;

    /* ...initialize the compression format for output port */
    pData->base.sPortFormat[1].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[1].eEncoding = OMX_AUDIO_CodingPCM;

    /* ...PCM format defaults */
    XAOMX_INIT_STRUCT(&pData->sPCM_in, OMX_AUDIO_PARAM_PCMMODETYPE);
    pData->sPCM_in.nPortIndex = 0;
    pData->sPCM_in.nChannels = 2;
    pData->sPCM_in.nSamplingRate = 44100;
    pData->sPCM_in.nBitPerSample = 16;
    pData->sPCM_in.eNumData = OMX_NumericalDataSigned;
    pData->sPCM_in.eEndian = OMX_EndianLittle;
    pData->sPCM_in.bInterleaved = OMX_TRUE;
    pData->sPCM_in.ePCMMode = OMX_AUDIO_PCMModeLinear;
    pData->sPCM_in.eChannelMapping[0] = OMX_AUDIO_ChannelLF;
    pData->sPCM_in.eChannelMapping[1] = OMX_AUDIO_ChannelRF;

    XAOMX_INIT_STRUCT(&pData->sPCM_out, OMX_AUDIO_PARAM_PCMMODETYPE);
    pData->sPCM_out.nPortIndex = 1;
    pData->sPCM_out.nChannels = 2;
    pData->sPCM_out.nSamplingRate = 44100;
    pData->sPCM_out.nBitPerSample = 16;
    pData->sPCM_out.eNumData = OMX_NumericalDataSigned;
    pData->sPCM_out.eEndian = OMX_EndianLittle;
    pData->sPCM_out.bInterleaved = OMX_TRUE;
    pData->sPCM_out.ePCMMode = OMX_AUDIO_PCMModeLinear;
    pData->sPCM_out.eChannelMapping[0] = OMX_AUDIO_ChannelLF;
    pData->sPCM_out.eChannelMapping[1] = OMX_AUDIO_ChannelRF;

    XAOMX_INIT_STRUCT(&pData->sEQU, XAOMX_AUDIO_PARAM_EQUALIZER);
    pData->sEQU.Eqz_type = XA_REL_EQZ_TYPE_PARAMETRIC;
    for(i = 0; i < 9; i++)
    {
        /* ...centre frequencies */
        pData->sEQU.stEqCoef.FreqCenter[i] = 15000;
        pData->sEQU.stEqCoef.Type[i] = XA_REL_EQZ_TYPE_THROUGH;
        pData->sEQU.stEqCoef.BandWidth[i] = 0x05a8279a;
        pData->sEQU.stEqCoef.Gain[i] = 0x10000000;
        pData->sEQU.stEqCoef.GainBase[i] = 0x10000000;
    }

    for(i = 0; i < 5; i++)
    {
        pData->sEQU.stEqGCoef.Gain_g[i] = 0x050f44d8;
    }

    TRACE(INIT, _b("EQUALIZER instantiated"));

    return OMX_ErrorNone;
}

/*******************************************************************************
 * Entry points
 ******************************************************************************/

/** **************************************************************************
    \brief     EQUALIZER_ComponentCreate 

    \param[in]      *proxy                       OpenMAX interface proxy
    \param[in]      *hComponent                  Pointer to Equalizer component handle
    \param[in]      pAppData                     Pointer to pAppData of Equalizer component 
    \param[in]      *pCallbacks                  Pointer to Callbacks of Equalizer component 
    \retval         OMX_ErrorNone                Success
 *****************************************************************************/
OMX_ERRORTYPE EQUALIZER_ComponentCreate(xf_proxy_t *proxy, OMX_HANDLETYPE *hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)  /* PRQA S 1503, 3408 *//* Confirm function is used correctly. Oct 14, 2016 */
{
    OMX_COMPONENTTYPE   *pComp;
    XAOMXEqualizer      *pData;
    OMX_ERRORTYPE       eError = OMX_ErrorInsufficientResources;

    /* ...create the base component */
    pComp = calloc(1, sizeof(*pComp));      /* PRQA S 5118 *//* Confirm memory allocation is correct follow original design. Oct 14, 2016 */
    if (pComp == NULL) {
        goto error;     /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    /* ...set component version */
    XAOMX_INIT_STRUCT(pComp, OMX_COMPONENTTYPE);

    /* ...allocate private memory */
    pData = calloc(1, sizeof(*pData));      /* PRQA S 5118 *//* Confirm memory allocation is correct follow original design. Oct 14, 2016 */
    if (pData == NULL) {
        goto error1;    /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    /* ...set private data handle */
    pComp->pComponentPrivate = (OMX_PTR) pData;

    /* ...initialize component */
    eError = EQUALIZER_ComponentInit(proxy, (OMX_HANDLETYPE)pComp, pAppData, pCallbacks);
    if (eError != OMX_ErrorNone) {
        goto error1;    /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
    }

    TRACE(INIT, _b("EQUALIZER initialized"));

    /* ...return component handle */
    *hComponent = (OMX_HANDLETYPE)pComp;

    return OMX_ErrorNone;

error1:
    /* ...destroy component handle data */
    free(pComp);        /* PRQA S 5118 *//* Confirm free memory usage is correct. Oct 14, 2016 */

error:
    TRACE(INIT, _b("EQUALIZER creation failed: %X"), eError);

    return eError;
}
