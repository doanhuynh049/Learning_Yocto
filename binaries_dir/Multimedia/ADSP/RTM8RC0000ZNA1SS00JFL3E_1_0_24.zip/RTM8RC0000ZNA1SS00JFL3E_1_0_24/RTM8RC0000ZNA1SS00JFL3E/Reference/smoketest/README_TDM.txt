ADSP TDM Smoketest program Usage guideline & Example setting cases
*******************************************************************

"ADSP TDM Smoketest program Help Menu"
			"Command: adsp-omx-tdm-launch [-<command> <value>]"

"Common commands:"
			"-w <value>       : PCM Bit per sample (16/24)"
			"-chmod <value>   : Channel mode ([0] 4 x stereo, [1] 1 x 8 channel, [3] 3 x stereo, [4] 1 x 6 channel)"
			"-l <value>       : Recording time (second)"
			"-card <name>     : Select audio card"
			
			"Example:"
			"----------------------------------------"
			"adsp-omx-tdm-launch -w 16 -l 10 -chmod 0"
			"----------------------------------------"
			
"TDM Capture commands:"
			"-i <ssi1>        : Use TDM Capture"
			"-o1 <name>       : 1st output stream (.pcm)"
			"-o2 <name>       : 2nd output stream (.pcm)"
			"-o3 <name>       : 3rd output stream (.pcm)"
			"-o4 <name>       : 4th output stream (.pcm)"
			"-capfs           : Input sampling frequency  : (48000/0). Set '0' to disable SRC module"
			"-capoutfs        : Output sampling frequency : (32000/44100/48000)"
			"-capdmachannel1  : 1st DMA channel           : (ADMAC_CH00 to ADMAC_CH31)/(ADMACPP_CH00 to ADMACPP_CH28)"
			"-capinsource1    : 1st input device          : (SSI40)/(SCU_SRCI0, SCU_SRCI1, SCU_SRCI3, SCU_SRCI4)"
			"-capdmachannel2  : 2nd DMA channel           : (ADMAC_CH00 to ADMAC_CH31)/(ADMACPP_CH00 to ADMACPP_CH28)"
			"-capinsource2    : 2nd input device          : (SSI40/NONCONFIG). If capinsource1 is 'SSI40', this value must be 'NONCONFIG'"
			"-capvol          : Volume gain               : (0 to 8)/FFFFFFFF. Set 'FFFFFFFF' to disable DVC module"
			"-capframe        : Frame size                : (1024)"
			
			"Example:"
			"-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
			"-i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -o4 out4.pcm -capfs 48000 -capoutfs 48000 -capdmachannel1 ADMACPP_CH01 -capinsource1 SSI40 -capdmachannel2 ADMACPP_CH00 -capinsource2 NONCONFIG -capvol FFFFFFFF -capframe 1024 "
			"-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"

"TDM Renderer commands:"
			"-o <ssi0>        : Use TDM Renderer"
			"-i1 <name>       : 1st input stream (.pcm)"
			"-i2 <name>       : 2nd input stream (.pcm)"
			"-i3 <name>       : 3rd input stream (.pcm)"
			"-i4 <name>       : 4th input stream (.pcm)"
			"-rdrfs           : Input sampling frequency  : (32000/44100/48000)"
			"-rdroutfs        : Output sampling frequency : (48000/0). Set '0' to disable SRC module"
			"-rdrdmachannel1  : 1st DMA channel           : (ADMAC_CH00 to ADMAC_CH31)/(ADMACPP_CH00 to ADMACPP_CH28)"
			"-rdroutsource1   : 1st output device         : (SSI30)/(SCU_SRCI0, SCU_SRCI1, SCU_SRCI3, SCU_SRCI4)"
			"-rdrdmachannel2  : 2nd DMA channel           : (ADMAC_CH00 to ADMAC_CH31)/(ADMACPP_CH00 to ADMACPP_CH28)"
			"-rdroutsource2   : 2nd output device         : (SSI30/NONCONFIG). If rdroutsource1 is 'SSI30', this value must be 'NONCONFIG'"
			"-rdrvol          : Volume gain               : (0 to 8)/FFFFFFFF. Set 'FFFFFFFF' to disable DVC module"
			"-rdrframe        : Frame size                : (1024)"
			
			"Example:"
			"-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
			"-o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -i4 input4.pcm -rdrfs 44100 -rdroutfs 48000 -rdrdmachannel1 ADMACPP_CH01 -rdroutsource1 SSI30 -rdrdmachannel2 ADMACPP_CH00 -rdroutsource2 NONCONFIG -rdrvol FFFFFFFF -rdrframe 1024 "
			"-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"

			
***********************************************************************************

Below command of Smoke-test program based on all use case of TDM Renderer

=================================================================================================================
1.	Normal |
-----------
Ex 1: Memory -> ADMAC -> SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 3 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -rdrfs 32000 -rdrdmachannel1 ADMAC_CH01 -rdroutsource1 SSI30

Ex 2: Memory -> ADMACPP -> SSI, 16 bit 
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 3 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -rdrfs 32000 -rdrdmachannel1 ADMACPP_CH01 -rdroutsource1 SSI30
    
Ex 3: Memory -> ADMAC -> SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 24 -chmod 3 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -rdrfs 32000 -rdrdmachannel1 ADMAC_CH01 -rdroutsource1 SSI30

Ex 4: Memory -> ADMACPP -> SSI, 24 bit 
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 24 -chmod 3 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -rdrfs 32000 -rdrdmachannel1 ADMACPP_CH01 -rdroutsource1 SSI30
=================================================================================================================
2.	Sampling Rate Conversion |
-----------------------------
Ex 1: Memory -> ADMAC -> SRC -> ADMAC -> SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 24 -chmod 0 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -i4 input4.pcm -rdrfs 32000 -rdroutfs 48000 -rdrdmachannel1 ADMAC_CH01 -rdroutsource1 SSI30 -rdrdmachannel2 ADMAC_CH00 -rdroutsource2 NONCONFIG -rdrvol FFFFFFFF

Ex 2: Memory -> ADMAC -> SRC -> ADMACPP -> SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 0 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -i4 input4.pcm -rdrfs 32000 -rdroutfs 48000 -rdrdmachannel1 ADMAC_CH01 -rdroutsource1 SSI30 -rdrdmachannel2 ADMACPP_CH00 -rdroutsource2 NONCONFIG -rdrvol FFFFFFFF

Ex 3: Memory -> ADMACPP -> SRC -> ADMAC -> SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 24 -chmod 0 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -i4 input4.pcm -rdrfs 32000 -rdroutfs 48000 -rdrdmachannel1 ADMACPP_CH01 -rdroutsource1 SSI30 -rdrdmachannel2 ADMAC_CH00 -rdroutsource2 NONCONFIG -rdrvol FFFFFFFF

Ex 4: Memory -> ADMACPP -> SRC -> ADMACPP -> SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 0 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -i4 input4.pcm -rdrfs 32000 -rdroutfs 48000 -rdrdmachannel1 ADMACPP_CH01 -rdroutsource1 SSI30 -rdrdmachannel2 ADMACPP_CH00 -rdroutsource2 NONCONFIG -rdrvol FFFFFFFF

=================================================================================================================
3.	Volume Control |
-------------------
Ex 1: Memory -> ADMAC -> SRC -> ADMAC -> SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 0 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -i4 input4.pcm -rdrfs 32000 -rdroutfs 48000 -rdrdmachannel1 ADMAC_CH01 -rdroutsource1 SCU_SRCI0 -rdrdmachannel2 ADMAC_CH00 -rdroutsource2 SSI30 -rdrvol 1

Ex 2: Memory -> ADMAC -> SRC -> ADMACPP -> SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 0 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -i4 input4.pcm -rdrfs 32000 -rdroutfs 48000 -rdrdmachannel1 ADMAC_CH01 -rdroutsource1 SCU_SRCI0 -rdrdmachannel2 ADMACPP_CH00 -rdroutsource2 SSI30 -rdrvol 1

Ex 3: Memory -> ADMACPP -> SRC -> ADMAC -> SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 0 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -i4 input4.pcm -rdrfs 32000 -rdroutfs 48000 -rdrdmachannel1 ADMACPP_CH01 -rdroutsource1 SCU_SRCI0 -rdrdmachannel2 ADMAC_CH00 -rdroutsource2 SSI30 -rdrvol 1

Ex 4: Memory -> ADMACPP -> SRC -> ADMACPP -> SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 0 -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -i4 input4.pcm -rdrfs 32000 -rdroutfs 48000 -rdrdmachannel1 ADMACPP_CH01 -rdroutsource1 SCU_SRCI0 -rdrdmachannel2 ADMACPP_CH00 -rdroutsource2 SSI30 -rdrvol 1

***********************************************************************************

Below command of Smoke-test program based on all use case of TDM Capture

=================================================================================================================
1.	Normal |
-----------
Ex 1: Memory <- ADMAC <- SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 3 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -capoutfs 44100 -capdmachannel1 ADMAC_CH01 -capinsource1 SSI40

Ex 2: Memory <- ADMACPP <- SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 3 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -capoutfs 44100 -capdmachannel1 ADMACPP_CH01 -capinsource1 SSI40
    
Ex 3: Memory <- ADMAC <- SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 24 -chmod 3 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -capoutfs 44100 -capdmachannel1 ADMAC_CH01 -capinsource1 SSI40

Ex 4: Memory <- ADMACPP <- SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 24 -chmod 3 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -capoutfs 44100 -capdmachannel1 ADMACPP_CH01 -capinsource1 SSI40

=================================================================================================================
2.	Sampling Rate Conversion |
-----------------------------
Ex 1: Memory <- ADMAC <- SRC <- ADMAC <- SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 24 -chmod 0 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -o4 out4.pcm -capfs 48000 -capoutfs 44100 -capdmachannel1 ADMAC_CH01 -capinsource1 SCU_SRCI0 -capdmachannel2 ADMAC_CH00 -capinsource2 SSI40 -capvol FFFFFFFF

Ex 2: Memory <- ADMAC <- SRC <- ADMACPP <- SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 0 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -o4 out4.pcm -capfs 48000 -capoutfs 44100 -capdmachannel1 ADMAC_CH01 -capinsource1 SCU_SRCI0 -capdmachannel2 ADMACPP_CH00 -capinsource2 SSI40 -capvol FFFFFFFF

Ex 3: Memory <- ADMACPP <- SRC <- ADMAC <- SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 24 -chmod 0 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -o4 out4.pcm -capfs 48000 -capoutfs 44100 -capdmachannel1 ADMACPP_CH01 -capinsource1 SCU_SRCI0 -capdmachannel2 ADMAC_CH00 -capinsource2 SSI40 -capvol FFFFFFFF

Ex 4: Memory <- ADMACPP <- SRC <- ADMACPP <- SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 0 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -o4 out4.pcm -capfs 48000 -capoutfs 44100 -capdmachannel1 ADMACPP_CH01 -capinsource1 SCU_SRCI0 -capdmachannel2 ADMACPP_CH00 -capinsource2 SSI40 -capvol FFFFFFFF

=================================================================================================================
3.	Volume Control |
-------------------
Ex 1: Memory <- ADMAC <- SRC <- ADMAC <- SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 24 -chmod 0 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -o4 out4.pcm -capfs 48000 -capoutfs 44100 -capdmachannel1 ADMAC_CH01 -capinsource1 SCU_SRCI0 -capdmachannel2 ADMAC_CH00 -capinsource2 SSI40 -capvol 1

Ex 2: Memory <- ADMAC <- SRC <- ADMACPP <- SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 0 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -o4 out4.pcm -capfs 48000 -capoutfs 44100 -capdmachannel1 ADMAC_CH01 -capinsource1 SCU_SRCI0 -capdmachannel2 ADMACPP_CH00 -capinsource2 SSI40 -capvol 1

Ex 3: Memory <- ADMACPP <- SRC <- ADMAC <- SSI, 24 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 24 -chmod 0 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -o4 out4.pcm -capfs 48000 -capoutfs 44100 -capdmachannel1 ADMACPP_CH01 -capinsource1 SCU_SRCI0 -capdmachannel2 ADMAC_CH00 -capinsource2 SSI40 -capvol 1

Ex 4: Memory <- ADMACPP <- SRC <- ADMACPP <- SSI, 16 bit
    #./adsp-omx-tdm-launch -card plughw:0,1 -w 16 -chmod 0 -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -o4 out4.pcm -capfs 48000 -capoutfs 44100 -capdmachannel1 ADMACPP_CH01 -capinsource1 SCU_SRCI0 -capdmachannel2 ADMACPP_CH00 -capinsource2 SSI40 -capvol 1
